# Shadow Royale — Android-first Flutter project

This project is an Android-first **client-side foundation** for the requested original battle-royale game. It is designed to be uploaded to GitHub from an iPhone and built with GitHub Actions. The project is not a finished commercial 3D battle-royale game yet; see the status section below.

## Included in this source package

- Dark neon mobile lobby and selection UI for six modes: Battle Royale, BR Ranked, Classic, Classic Ranked, Lone Wolf, and Training Ground.
- A lightweight **2D offline arena prototype** with a movable touch joystick, AI practice bots that approach and attack, player health and armor, ammo, reload, healing, weapon switching (assault rifle/shotgun/sniper with distinct prototype ranges/damage), a simulated loot pickup button (armor/ammo/medkit), hit/elimination feedback, a shrinking safe-zone damage loop, match pause/restart, kill count, and victory/elimination states.
- Local mode behavior: Ranked modes can be practiced offline, but local practice progress is not a global/server rank.
- Emote picker UI (LOL, Dance, Laugh, Taunt, Clap, Victory).
- Custom Room UI with local room-code generation, mode/capacity selection, optional password, and local verification (no remote matchmaking).
- Local UI hubs for Rank, Team, Events, Profile, Inventory, a cosmetic shop, offline missions, and fictional map branding (Veylora).
- Device-local persistence for the local UID, match/win/kill/survival stats, XP/coins, cosmetic ownership, mission reward claim, and settings preferences. Settings choices are saved, while actual engine-level audio, haptics, frame-rate, and graphics controls still need engine integration.
- GitHub Actions workflow to generate Android platform files, analyze the Flutter project, build a release APK, and upload it as an artifact.
- `docs/MASTER_FEATURE_CHECKLIST.md`: the full feature plan and backend hand-off list.
- `docs/BACKEND_HANDOFF.md`: the interfaces/services that must be implemented before online launch.

## Build an APK using only an iPhone + GitHub

1. In Safari, create a GitHub repository named `shadow-royale`.
2. Extract this ZIP in the iPhone Files app or another ZIP utility.
3. Upload the files and folders inside the extracted project to the repository root, including `.github/workflows/build-apk.yml`. If GitHub's upload page hides `.github`, create that workflow file using GitHub's web editor.
4. Commit to the `main` branch.
5. Open **Actions** → **Build Shadow Royale APK** → **Run workflow**. A push to `main` also triggers a build.
6. When the workflow succeeds, open its run and download the `shadow-royale-release-apk` artifact. It is a ZIP containing `app-release.apk`.
7. The APK installs on Android, not iPhone. The iPhone is used to upload source and retrieve the artifact.

## Honest implementation status

This is **not yet the full 3D game** described in the feature checklist. The current gameplay arena is a 2D Flutter/Canvas prototype and the bots use simple movement and distance-based attacks; this is not production-grade 3D navigation, shooting physics, or advanced tactical AI. Weapon switching and loot are lightweight prototype mechanics, not world-space pickups or realistic ballistics. Rank, event, team, and custom-room systems remain local foundations; the shop, inventory, basic mission reward, settings, UID, and practice statistics now have device-local behavior. A local room code does not connect remote players.

The following require additional development before a complete launch:

- A 3D game engine and real 3D character/world assets, animation rigging, camera, physics, full weapon/projectile systems, vehicles, parachute, loot, and complete match loop. The current safe-zone is only a simple 2D prototype mechanic.
- Production-quality bot navigation, tactics, fairness tuning, and QA.
- Real online multiplayer networking, matchmaking, authoritative game servers, remote rooms/team codes, reconnect takeover, chat/voice, and player synchronization.
- Backend account identity, global UID, cloud save, server-verified rank, leaderboard, inventory, guilds, live events, purchases, moderation, anti-cheat, and operational monitoring.
- Device testing, performance profiling, release signing, privacy/security review, and store compliance.

No online feature is represented as working until a backend is implemented and tested. Offline practice must remain available without internet; global ranking and remote multiplayer inherently require a server.

## New Godot 4 3D engine starter
The `godot_engine/` folder is a separate Godot 4 project with a procedural 3D arena, player controller, basic bots, loot, a shrinking zone and HUD. Open `godot_engine/project.godot` in Godot 4.3+. It is a starter prototype and has not been compiled in this environment. The existing Flutter project and its APK workflow remain separate; that workflow does not export the Godot project.

## Latest source update (2026-10-24)
The Godot 3D prototype now includes source-level support for three weapon profiles and a mobile touch layout with left-side movement and right-side drag aiming, plus a weapon-cycle button. These changes have not been runtime-verified because the build tools are unavailable in this environment. See `docs/WORK_COMPLETED_THIS_PASS.md` and `godot_engine/docs/ENGINE_ROADMAP.md` for exact scope and remaining work.


### Latest source update (2026-10-24)
The Godot 3D prototype now includes source-level sprint/crouch controls and per-weapon magazine/reserve ammunition. This remains an early offline prototype, not a finished commercial battle royale. Godot is not installed in the authoring environment, so the project has not been parsed, run, or exported to APK here.

## Premium economy blueprint (planned; not live yet)
The economy specification is documented in `docs/ECONOMY_PRIME_AND_TOPUP_BLUEPRINT.md`. Working names are **Eclipse Gems** (premium top-up currency), **Royale Gold** (soft currency), **Rift Tokens** (event currency), and **Shadow Prime I–VIII** (eight-level loyalty progression). These are planning names and the systems are not yet real purchase services. Top-Up must remain non-purchasable until official platform billing, backend receipt verification, transactional currency ledger, refunds, security, and store-policy checks are implemented and tested. Offline matches must not grant verified premium purchases or online Prime progress.


## Implementation audit update (2026-10-24)

- Added a lobby-linked Eclipse Gems / Top-Up / Shadow Prime preview page. It is intentionally **non-purchasable** until official store billing and trusted server receipt verification exist.
- Added all eight proposed Prime tiers and unit tests for threshold mapping. Prime VIII is capped at 200,000 qualifying verified Eclipse Gems; totals above it stay Prime VIII and Prime IX does not exist.
- Flutter Training Ground now uses stationary resettable targets rather than combat bots; match restart also clears armor and movement input.
- CI now runs `flutter test` before analysis and APK packaging.
- See `docs/IMPLEMENTATION_AUDIT_2026-10-24.md` for the source audit and remaining blockers. This pass has not been runtime-verified because Flutter/Dart/Godot tools are not installed in the authoring environment.

## Admin console prototype
Open `admin_console/index.html` in a browser to review the responsive operations-console UI. It contains synthetic sample data only; it has no authentication, backend connection, real sanctions, real economy mutation, or live telemetry. Do not expose it as a production admin panel. See `docs/ADMIN_CONSOLE_IMPLEMENTATION.md` for the required security and backend work.

## Ranked UI and progression audit update (2026-10-25)
- The lobby now shows `UNRANKED` instead of a fabricated `IRON III` label while the trusted online rank service is unavailable.
- The Rank navigation opens a dedicated preview screen with separate Classic Ranked star progression and BR Ranked point tiers.
- `lib/ranked_progression.dart` contains pure display/balance helpers; `test/ranked_progression_test.dart` covers key score/tier boundaries.
- SQL settlement rejects null mode/result payloads and duplicate user IDs in one submitted batch. It remains service-role-only and is not live until deployed and called by a trusted backend.
- These are source-level updates only. Flutter/Dart/Godot/PostgreSQL tools were unavailable during this pass, so run CI and deploy to a test database before treating them as verified runtime behavior.


## Current play availability

**Offline-first development build:** Battle Royale, Classic, Lone Wolf and Training Ground are available as local practice modes. Online multiplayer, BR Ranked and Classic Ranked are explicitly marked **IN MAINTENANCE** in the lobby and cannot be launched as live online queues. Online ranked results are not awarded. The Flutter lobby/practice arena is still a 2D gameplay prototype; the separate Godot 3D prototype is not yet integrated into the shipping mobile flow.

Before calling this a release build, run `flutter test`, `flutter analyze`, `flutter build apk --release`, and test controls/match completion on a real Android device. These checks were not executable in the source-editing environment because the Flutter/Dart SDK is unavailable.
