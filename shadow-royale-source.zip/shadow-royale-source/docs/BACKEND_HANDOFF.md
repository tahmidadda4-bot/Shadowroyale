# Backend hand-off — Shadow Royale

This is the work intentionally reserved for a later backend phase. The client must never pretend that local mock data is a global/online result.

## Required server services
1. Authentication and account linking/recovery.
2. Player profile and persistent UID.
3. Party, friends, invites and presence.
4. Matchmaking queues by mode, region, skill and rank.
5. Authoritative real-time match server with player movement/combat validation.
6. Room service for custom rooms, room ID/password, host rules and spectators.
7. Disconnect detection, temporary AI takeover and secure player rejoin/ownership handoff.
8. Rank/season/leaderboard service with server-calculated points.
9. Inventory, cosmetics, currency, missions, event schedules and reward claims.
10. Chat/voice integration, reports, blocks, moderation and appeals.
11. Analytics, crash reporting, anti-cheat signals, monitoring, backups and operations tools.

## Client/server contract principles
- Every remote operation must have a documented request/response and error state.
- Use authenticated HTTPS APIs for account/inventory/metadata and an appropriate real-time protocol for match state.
- Never embed server secrets in the mobile client.
- The server owns authoritative online match outcomes, currency, rank, purchases and inventory.
- A local offline UID/room code is not a globally unique account/room identifier.
- Offline progress must be labeled local and must not be trusted as ranked online progress without server validation.
- Handle timeout, retry, reconnect, duplicate requests and version mismatch safely.

## Backend completion acceptance criteria
- Two separate Android devices can join the same room and see synchronized movement/combat.
- A disconnected player can rejoin without duplicating their character or corrupting the match.
- Room code/password and team invites work across devices.
- Rank, results, inventory and rewards survive reinstall/login and cannot be edited by the client.
- Server load, latency, abuse, security and recovery tests pass.

## Premium economy / top-up / Prime requirements
- Add a server-controlled currency catalog and balances for Eclipse Gems (premium), Royale Gold (soft currency), and Rift Tokens (event-specific currency); use stable internal IDs.
- Implement an immutable currency ledger, transactional debit/credit operations, idempotency keys, balance reconciliation, and audit logs.
- Verify Google Play Billing purchase tokens (or the official platform billing receipt) on the backend before granting Eclipse Gems. Handle pending, duplicate, rejected, refunded, and charged-back transactions.
- Keep Top-Up product catalog, region pricing metadata, bonuses, eligibility and campaign timing in trusted configuration; use server time.
- Implement Shadow Prime I–VIII using verified lifetime qualifying purchases or a published stable Prime-points formula. Persist level and progress server-side, define refund effects, and grant each tier reward once.
- Implement premium store, Gold Store, event token exchange, event missions, event reward claims, expiry policy and end-of-event settlement.
- Never let the client set currency balances, purchase status, Prime tier, reward eligibility, or event token balances.
- Offline/local progress must not grant premium currency or global Prime/ranked/event rewards. Disable real-money top-up UI until billing verification and store compliance are complete.
- Add metrics and support/admin tools for purchase verification, ledger reconciliation, refunds, suspicious transactions and audited compensation.
