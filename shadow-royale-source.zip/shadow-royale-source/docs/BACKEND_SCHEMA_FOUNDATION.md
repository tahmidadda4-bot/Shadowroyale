# Shadow Royale backend schema foundation — 2026-10-24

Added `supabase/migrations/001_core_schema.sql` as a first-pass PostgreSQL/Supabase schema for:

- player profiles and unique player UIDs;
- friend requests/status;
- party and party-member records;
- Eclipse Gems, Royale Gold and Rift Tokens wallet accounts;
- immutable-style wallet ledger with a unique idempotency key;
- store receipt records and server-derived Shadow Prime tier (capped at VIII at 200,000 qualifying Gems);
- admin role assignments and audit log;
- baseline row-level security (RLS).

## Important status

This is a **schema foundation, not a connected or production-ready backend**. It has not been applied to a live Supabase project or validated by a PostgreSQL runtime in this environment. The Flutter app is not yet wired to these tables. Party create/join RPCs, authenticated Edge Functions, receipt verification with Google Play/App Store, ledger mutation transactions, rate limiting, account deletion/privacy flows, moderation, and deployment secrets are still required. Do not grant client write access to wallet, receipt, role, or audit tables. Review and test the migration in a disposable project before production use.

## Security review before production

- Add transactional server-side functions for friend cap enforcement, duplicate/reverse friendship rules, party capacity/expiry/leader changes, and safe party code redemption.
- Ensure display-name and UID search is rate-limited and does not expose private account metadata.
- Ensure purchase verification is performed against official store APIs by a trusted server; never trust a client purchase callback.
- Harden profile creation/UID generation and ensure the application creates wallet rows only via trusted server logic.
- Add policy tests for every role and authenticated/anonymous access path; test with two users and an administrator.
- Decide how to handle refunds/chargebacks without incorrectly lowering the historical qualifying purchase total; document the policy and implement it server-side.
