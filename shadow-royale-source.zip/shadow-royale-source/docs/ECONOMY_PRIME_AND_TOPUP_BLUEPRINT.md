# Shadow Royale — Premium Currency, Top-Up, Prime, Gold & Event Economy

**Status:** Product specification only. These systems are not implemented as real-money purchase services yet. Any UI shown before backend/store integration must be labeled prototype/demo and must not accept or imply a real payment.

## 1. Original currency names

Use original Shadow Royale names and visual identity; do not copy Free Fire's logos, artwork, UI assets, currency artwork, exact bundle presentation, or proprietary event designs.

- **Eclipse Gems (premium currency):** Purchased through verified top-ups or awarded through specifically approved promotions. Used for premium cosmetics, selected event entries/items, and optional premium pass access. It must not directly buy combat power that makes paid players stronger in ranked matches.
- **Royale Gold (soft currency):** Earned through approved gameplay, missions, achievements, and events. Used in the Gold Store for selected cosmetics, basic supplies for permitted modes, and other balanced non-premium items.
- **Rift Tokens (event currency):** Earned through a named event's missions and event gameplay. Redeemable only in that event's Token Exchange. Expiry, conversion, and carry-over rules must be shown before a player earns or spends them.

Names are working names and can be changed before release, but each currency must have one stable internal ID and a clear icon, color, balance display, and transaction history.

## 2. Top-Up Center

Lobby entry: **Store → Top-Up**. It must include:

1. Current Eclipse Gems balance.
2. Region/currency-aware purchase bundles loaded from trusted store/backend configuration.
3. Each bundle's base gems, bonus gems (if any), total received, price, and eligibility.
4. First-top-up offer only when eligible; clearly show whether it is per account, per product, or per campaign.
5. Limited-time offer end time based on server time, not device clock.
6. Purchase confirmation, platform payment sheet, pending/success/failure states, and retry guidance.
7. Transaction history, restore/reconcile purchases where the platform supports it, and support/report-purchase flow.
8. Clear disclosures for taxes, regional price, bonus conditions, and refund/revocation outcomes as applicable.
9. Age/parental requirements and applicable Google Play/store billing policies.
10. No misleading countdowns, hidden price terms, or pressure tactics.

### Purchase flow

1. Client requests the current catalog from the backend.
2. Player chooses a bundle and confirms.
3. Google Play Billing (or the supported platform's official billing system) processes payment.
4. Client sends the purchase token/receipt to the backend over authenticated HTTPS.
5. Backend verifies the transaction with the platform, checks product ID, account binding, status, and duplicate processing.
6. Backend grants Eclipse Gems in a database transaction and writes an immutable ledger entry.
7. Client refreshes balance from the backend and displays a receipt/result state.
8. Pending transactions are reconciled; refunds/chargebacks revoke or adjust entitlements according to policy.

The client must never grant paid currency solely because a local callback says “success”. Never store service-role keys, billing secrets, or trusted balance logic in the mobile app.

## 3. Bundle configuration

Bundle amounts and prices are **not fixed in this blueprint**; they must be configured after economy balancing, local pricing, store policy review, and testing. The catalog should support:

- Product ID, region, price, base gem amount, bonus amount, sale start/end, purchase limits, first-time eligibility, and active status.
- Versioning and safe rollout/rollback.
- Server-authoritative timestamps.
- No duplicate grants from retries, app restarts, or repeated receipt submissions.
- Separate staging/test products and production products.
- Promotional bonus eligibility rules that are explicit and testable.

## 4. Prime progression — eight levels

Working feature name: **Shadow Prime**. It has eight levels: **Prime I, Prime II, Prime III, Prime IV, Prime V, Prime VI, Prime VII, Prime VIII**. It is an account loyalty progression inspired by the general idea of top-up-based VIP programs, but the thresholds, rewards, names, visuals, and UI must be original to Shadow Royale.

### Qualification rule

- Track **verified lifetime premium purchases/top-ups** as a separate server-side value; do not calculate Prime level from the current gem balance because spending gems must not silently reduce loyalty level.
- Only settled, platform-verified transactions count. Pending, rejected, refunded, or charged-back purchases do not count; policy must define treatment of later refunds.
- Prime thresholds are configuration values, not hardcoded in the client. The exact threshold for each of the eight levels must be set after economy/pricing review.
- Display current Prime level, progress to next level, qualifying total, perks, and reward claim state.
- A Prime level-up must be granted idempotently and recorded in an audit/ledger trail.
- If Prime points are used instead of direct currency totals, the conversion formula must be public and stable for the season/program period.

### Prime reward principles

- Prefer cosmetics, profile frames, emotes, banners, lobby effects, convenience perks that do not affect competitive outcomes, and event/store access where appropriate.
- Do not grant exclusive damage, health, accuracy, recoil, movement, or other ranked combat advantages for spending money.
- Show rewards and qualification requirements before purchase; do not promise rewards that are not configured or available.
- Define whether Prime is permanent, seasonal, or has a versioned program period before launch. The recommended default is permanent lifetime tier with policy-governed transaction reversals, unless product owners decide otherwise.
- Prime VIII is the highest tier. All eight thresholds and reward tables must be populated and tested before the Prime feature is marked complete.

## 5. Stores and spending routes

### Eclipse Store (premium)
- Premium cosmetics, character/outfit skins, weapon skins, emotes, avatar frames, banners, and eligible pass/event access.
- Item preview, rarity, ownership state, price, purchase confirmation, and entitlement sync.
- If a direct gem purchase is used, backend checks balance and item availability, atomically debits gems, grants item, and writes ledger entries.

### Royale Gold Store (soft currency)
- A curated catalog of non-pay-to-win cosmetics, basic unlocks, and mode-permitted supplies.
- Prices balanced against realistic earn rates and expected play time.
- Daily/weekly purchase limits only when explained clearly.
- Gold cannot be converted to real money and is not a substitute for premium purchase entitlement.

### Rift Token Exchange (event shop)
- Event-specific cosmetics, limited rewards, and event collectibles.
- Event page shows objectives, start/end time, token sources, item costs, remaining eligibility, and expiry/conversion policy.
- Token grants and spending are server-validated online; duplicate claims are blocked.
- If tokens expire, show a clear countdown and policy well in advance. Do not silently remove earned tokens without disclosed rules.

## 6. Event economy

Each event needs a configuration record: event ID, name, description, start/end timestamps, eligible modes/regions, missions, token reward table, shop catalog, reward limits, prerequisites, and status.

Supported event types may include:
- Login/check-in rewards.
- Daily/weekly event missions.
- Match-play milestones.
- Community or clan milestones, if safe and supported.
- Limited-time cosmetic collections.
- Event token exchange.
- Event leaderboard only where server-verified results are available.

Every event reward requires eligibility checks, duplicate-claim protection, server time, audit logs, and a defined end-of-event behavior. Offline practice may show local event previews, but it must not create verified online currency or ranked/event leaderboard results.

## 7. Currency ledger and data model

Recommended backend entities:
- `currency_catalog`: stable currency IDs and display metadata.
- `player_currency_balances`: current materialized balances.
- `currency_ledger`: immutable credit/debit entries with transaction ID, player ID, currency ID, amount, reason, source, timestamp, and idempotency key.
- `topup_products`: store product IDs, regions, configured amounts/bonuses, status, and campaign rules.
- `purchase_transactions`: platform transaction identifiers, account binding, status, verification result, and refund/revocation state.
- `prime_progress`: verified qualifying total/points, level, and program version.
- `prime_reward_claims`: level reward and idempotency status.
- `store_catalog` and `store_purchases`: item price, currency, availability, and purchase history.
- `events`, `event_missions`, `event_token_ledger`, `event_shop_items`, and `event_reward_claims`.

All currency-changing operations must be transactional and idempotent. Balance must reconcile to ledger entries. Clients may request actions but cannot set their own balances, Prime tier, reward eligibility, or purchase status.

## 8. Offline rules

- Offline matches can award only explicitly approved local practice rewards and local-only currency, if used.
- Offline data must be clearly labeled local and must not grant Eclipse Gems from real-money top-ups, online Prime progress, verified purchases, or global event leaderboard results.
- Do not merge local soft currency into a server wallet without a defined, exploit-resistant reconciliation policy.
- Offline Store/Top-Up screens must show “Online connection required” or a clearly labeled demo preview; they must not simulate a real successful payment.

## 9. Economy metrics

Track privacy-conscious, aggregated metrics such as:
- Top-up catalog views and checkout starts/completions/failures.
- Purchase verification latency and duplicate receipt attempts.
- Currency earned/spent by source and sink.
- Balance distribution and inactive/stranded currency.
- Store item views, purchases, and ownership rates.
- Prime level distribution and level-up rates.
- Event participation, token earn/spend, and unclaimed rewards.
- Refund/chargeback and suspicious transaction rates.

Use these metrics to balance prices, rewards, earn rates, and event difficulty—not to create deceptive pressure. Access to transaction-level data must be restricted and audited.

## 10. Admin and support tools

- Manage bundle catalog, prices through official platform configuration, bonuses, eligibility, and availability.
- Manage Prime thresholds/rewards with versioning and audit logs.
- Configure events, token earn tables, event shop, and expiry policies.
- Inspect purchase status and receipt verification outcomes.
- Reconcile stuck/pending transactions through controlled workflows.
- Handle refunds/revocations, support tickets, and fraud reviews.
- Grant corrective compensation only through permissioned, audited actions.
- Never provide an unrestricted “edit balance” button without approval, reason, ledger entry, and audit history.

## 11. Acceptance tests / launch gate

- Verified purchase grants exactly once, including retry and app-restart cases.
- Invalid, reused, mismatched-account, pending, and refunded receipts are not treated as successful purchases.
- Store gem spend cannot result in negative balance or duplicate item ownership grants.
- Prime tier is based on verified qualifying purchases, survives spending/reinstall/login, and handles refunds according to published policy.
- All eight Prime levels have valid thresholds and reward tables.
- Event token grants/spending and reward claims are idempotent and respect server time.
- Local/offline actions cannot mint premium currency or alter global Prime/rank.
- Regional catalog and billing policy are verified before release.
- Transaction ledger and materialized balances reconcile.
- Accessibility, pricing disclosure, privacy, support, refund and store compliance reviews pass.

## 12. Release rule

Until platform billing, backend receipt verification, transactional ledger, refund handling, and store compliance tests are complete, Top-Up and paid-currency buttons must remain disabled or clearly marked as a non-purchasable prototype. Never advertise a real-money feature as available before it is operational.


## Client implementation status addendum (2026-10-24)

The Flutter client now has a lobby-linked, non-purchasable preview for the three currency labels and all eight Shadow Prime tiers. The preview shows the proposed threshold values and clearly states that verified lifetime qualifying top-ups are unavailable until a trusted backend is connected. It does not grant Gems, accept payment, or award Prime. A pure threshold helper and unit tests are present, but production Prime decisions must use trusted server-verified totals only. See `IMPLEMENTATION_AUDIT_2026-10-24.md` for outstanding work.
