# Shadow Royale — Full Project Audit & Release Gate

Audit date: 2026-10-25  
Scope: Flutter mobile prototype, Godot 4 gameplay/server prototype, Supabase migrations, CI workflow, docs and automated source audit.

## Executive summary

This repository is a multi-part prototype, not yet a launch-ready online battle royale. The Flutter app is currently the most direct mobile lobby/practice experience; the Godot 4 project is a separate 3D prototype and an online networking test slice. They are not yet one integrated shipped game. The GitHub Actions workflow builds the Flutter APK, not a Godot Android export. Do not enable real-money purchases, global ranked awards, or production online play until the relevant backend and security gates are complete.

## Fixed in this pass

- Switched the lobby to offline-first: removed the online toggle, added a clear maintenance banner, and guarded online ranked modes with a maintenance message. Offline Battle Royale, Classic, Lone Wolf and Training Ground remain selectable.
- Fixed arena pause behavior so pausing no longer masquerades as match completion; added resume support. Added Flutter widget tests for maintenance messaging and launching an offline match (tests authored but not executed here).

- Replaced the lobby's hard-coded `IRON III` with `UNRANKED` so the app no longer implies an unearned/global rank.
- Added a dedicated Ranked preview screen and wired the Rank tab to it.
- Added pure CS-style star / BR point calculations and boundary tests for the Flutter layer.
- Kept rating totals above the top tier threshold instead of clamping the rating itself; only the tier name caps.
- Added SQL checks rejecting null mode/payload and duplicate user IDs within one submitted result batch.
- Updated README, checklist, work report and source audit. Static audit currently reports 137 PASS / 0 FAIL; each refreshed ZIP passes its ZIP integrity check.

## P0 — Required before online ranked can be enabled

1. **Integrate match lifecycle and settlement.** Server must decide match winner, BR placement, kills, survival time, and CS round differential. The client must never submit trusted result facts or calculate global awards.
2. **Deploy and test Supabase migrations.** Apply migrations 001–003 to a disposable project first. Test RLS, service-role-only function execution, concurrent settlement, duplicate retry, malformed payload, and rollback behavior. Keep service-role secrets on a server only.
3. **Real match completion.** Current online server is a movement/combat test slice with respawn; it does not implement the full BR last-team-standing or CS round-based lifecycle. Ranked queues must remain disabled until these exist.
4. **Results UI backed by server response.** Show mode, placement/win, kills, rating before/delta/after, stars/tier promotion/demotion, and errors/retry state. Avoid optimistic local global-rank updates.
5. **Runtime validation.** Run Flutter tests/analyzer and Godot parse/play tests in CI or a machine with the SDKs. None of Flutter, Dart, Godot or PostgreSQL CLI was installed in this authoring environment.

## P1 — Required before multiplayer beta

- Integrate the online client/server into the main game flow, or explicitly choose one engine as the shipping client and document the other as a prototype. Current Flutter and Godot projects are separate.
- Implement auth/session refresh, party membership, ready state, matchmaking, remote room lifecycle, reconnect/rejoin, server shutdown handling and regional server configuration.
- Implement BR squad elimination/win conditions, CS round state, spectating, knock/revive/elimination lifecycle, kill feed and end-of-match cleanup.
- Fix/verify party-based team IDs: current online prototype team assignment is a placeholder based on entity IDs, not a real matchmaking party.
- Add rate limiting, anti-cheat telemetry, authoritative inventory/ammo/equipment, abuse/report/block tools, and operational monitoring.
- Validate low-end Android layout/performance, input latency, thermal/battery use, packet loss, reconnect, and staged multi-client load.

## P2 — Needed for a polished public release

- Real 3D character rigs, animation state machine, original environment/POIs and authored map layouts; current procedural world is a prototype.
- Weapon feel and balance: recoil, spread, ADS, attachments, weapon switch/reload animation, sound, damage indicators and hit reactions.
- Bot navigation/cover/zone rotation, squad tactics and difficulty fairness.
- Account profile, secure cloud save, global leaderboard, friends/guilds, moderation/support, missions/events/season lifecycle and reward claims.
- Signed release configuration, version/update policy, crash reporting, privacy policy, terms, data deletion, store compliance, backups and incident recovery.

## Economy / purchases safety gate

The Eclipse Gems / Top-Up / Shadow Prime UI is preview-only. Do not enable purchases or grant gems/Prime from client events. Required: official Google Play Billing integration, server receipt verification, immutable/idempotent currency ledger, refund/chargeback reconciliation, region catalog, purchase history, restore flow and audited reward claims.

## Test status

- Static source audit: **137 PASS / 0 FAIL**. This checks source markers and expected files, not compiler correctness or runtime behavior.
- ZIP integrity: all three generated archives pass `ZipFile.testzip()`.
- Flutter/Dart tests: **not run** (SDK unavailable here).
- Godot parse/play/export: **not run** (engine unavailable here).
- PostgreSQL/Supabase migration and concurrency tests: **not run** (database not connected; psql unavailable).
- Android device / network load test: **not run**.

## Go/no-go decision

**NO-GO for public online/ranked launch at this time.** The source has useful prototype foundations, but P0 gates above must pass on real tools and a test backend before online Ranked is represented as live. Offline practice is the only enabled play path in this pass, but still must pass Flutter tests/analyzer and real Android gameplay QA before being called release-ready.

## Offline-only decision for the current development phase

Online multiplayer, BR Ranked, and Classic Ranked are intentionally gated as **IN MAINTENANCE** in the Flutter lobby. The online client/server source remains in the repository for later work, but the main app has no online toggle and cannot start those queues. Offline Battle Royale, Classic, Lone Wolf, and Training Ground are the only selectable match modes. The offline arena has pause/resume support and local-only match rewards. This does not mean the offline game has been proven release-ready: Flutter widget tests, static analysis, release APK build, and device gameplay checks must still be run on a machine with Flutter installed.

Latest source-marker audit: **144 PASS / 0 FAIL**. This is not a substitute for compilation or gameplay tests.
