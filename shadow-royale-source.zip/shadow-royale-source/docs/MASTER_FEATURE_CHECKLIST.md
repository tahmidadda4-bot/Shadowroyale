# Shadow Royale — Master Feature Checklist

This checklist records the complete requested product scope. It is a development plan, not a claim that every item is already implemented.

## 1. Product and visual quality
- [ ] Original Shadow Royale identity, logo, lobby, loading screen, responsive UI, settings, error/loading/empty states.
- [ ] Consistent art direction, polished transitions, haptics/audio feedback, accessibility, reduced-motion option.
- [ ] Original assets and names; do not copy proprietary Free Fire art, characters, maps, logos, or sounds.

## 2. Six requested modes
- [x] Mode selection UI: Battle Royale, BR Ranked, Classic, Classic Ranked, Lone Wolf, Training Ground.
- [ ] Full rules, matchmaking and results implemented for every mode.
- [x] Godot offline prototype mode selector for Solo Battle Royale and Training Ground (source-level only; runtime verification pending).
- [ ] Offline versions use bots/local practice; online versions use authoritative servers.
- [x] Training Ground prototype has no enemy bots and disables shrinking-zone damage (runtime verification pending).
- [ ] Separate BR and Classic ranked tracks; offline rank is separate from global rank.

## 3. Offline/online behavior
- [x] Offline practice arena foundation and local bot simulation.
- [x] Local profile/stat persistence (UID, matches, wins, kills, survival, XP/coins) and settings persistence.
- [ ] Online multiplayer, matchmaking, reconnect, remote player synchronization.
- [ ] Disconnect bot takeover with safe ownership transfer and player return/rejoin.
- [ ] Clear UI status for offline/local data vs online/server-synced data.

## 4. Bot AI
- [x] Basic bots move toward player and inflict bounded damage in the prototype.
- [ ] Tactical navigation, cover, looting, weapon selection, zone rotation, squad tactics, revive behavior.
- [ ] Difficulty presets and fairness tests; no hidden impossible accuracy or unfair information.
- [ ] Headshots, reaction times and accuracy tuned per difficulty.

## 5. Maps and match loop
- [x] Fictional Veylora branding and a simple 2D arena backdrop.
- [ ] Large fictional map(s): Veylora, Drakemoor, Nexora Bay, Ashenfall; original POIs, roads, buildings, terrain and landmarks.
- [x] Prototype arena includes four named POI clusters and a simple procedural road cross with approach roads and dashed markings (runtime placement unverified).
- [x] Basic 2D shrinking safe-zone circle and periodic zone damage in the prototype.
- [ ] Plane path, parachute, landing, loot spawns, supply drops, 3D zone behavior, final circle, and complete win/loss results.
- [ ] World streaming/LOD, occlusion and mobile performance optimization.

## 6. Combat and movement
- [x] Prototype movement control, fire/reload/heal controls, health/ammo/armor and bot combat loop.
- [x] Source-level sprint/crouch controls (keyboard plus mobile HUD hold buttons); runtime/device verification still required.
- [x] Prototype weapon cycling (assault rifle, shotgun, sniper) with different range/damage/ammo values.
- [x] Physical prototype pickups spawn in the arena and grant armor, ammo, or medkit on player overlap (runtime unverified).
- [ ] Full 3D locomotion: run, sprint, jump, crouch, prone, vault, climb, swim/fall rules as designed.
- [x] Prototype weapon slots: AR, SMG, shotgun, sniper and pistol with separate basic damage/range/cooldown/magazine/reserve values (runtime unverified).
- [ ] Melee, grenades, recoil/spread, attachments/scopes, polished reload animations, balanced ammo economy and authoritative hit validation.
- [ ] Armor, helmets, healing, knockdown, revive, elimination, kill feed, damage indicators, hit reactions, kill cam/replay if feasible.
- [ ] Vehicles, passenger seats, handling, damage and fuel if included in launch scope.

## 7. Characters, pets and emotes
- [x] Emote picker UI with LOL, Dance, Laugh, Taunt, Clap and Victory labels.
- [ ] Original 3D characters, rigged animations, skills/abilities, outfits, skins, pets/companions.
- [ ] Real animated emote wheel, animation cancellation rules, sound and victory animation.

## 8. Rank and progression
- [x] Local rank/profile UI foundation.
- [ ] Rank tiers (e.g. Iron/Bronze/Silver/Gold/Platinum/Diamond/Master/Legend), points, promotion/demotion, seasons, rewards and resets.
- [ ] Separate BR Ranked and Classic Ranked rules; server validation for online rank.
- [ ] Local practice stats vs global leaderboard clearly separated.

## 9. UID, social and teams
- [x] Persistent device-local player ID display and Team/Custom Room UI foundations.
- [x] Local friend list, invite markers, Prime preview and generated team code now persist on device (not cross-device and not a real player directory).
- [ ] Persistent account UID, player search, friend requests, invites, online status and block list.
- [ ] Duo/Squad, party leader, ready status, team code, remote room code and team synchronization.
- [ ] Guild/clan, roles, guild missions, text/quick chat, optional voice chat, mute/report/moderation.

## 10. Custom Room
- [x] Local room code generator, join-code validation, mode/capacity selection and optional local password check.
- [ ] Remote room creation/join, synchronized passwords, solo/duo/squad party state, host controls, kick/lock, spectator permissions.
- [ ] Offline custom match with bots and local settings.

## 11. Events, missions, shop and economy
- [x] Local UI entry points for events, missions, rewards and season progression.
- [ ] Daily/weekly missions, login streaks, achievements, events calendar, limited-time modes, battle pass.
- [x] Local coins/XP, cosmetic placeholder shop, local inventory ownership and one-time local mission reward.
- [ ] Full currency balancing, duplicate handling, server-backed cosmetic shop, reward expiry and anti-fraud validation.
- [ ] If monetization is added: server-verified purchases, restore/refund, fraud controls, store-policy compliance and pay-to-win avoidance.

## 12. Controls, audio and accessibility
- [x] Settings screen UI: aim sensitivity, left-handed toggle, auto-reload toggle, vibration toggle, audio sliders, graphics/FPS preference chips, reduced-motion toggle.
- [x] Persist settings locally on device.
- [ ] Connect controls to actual engine settings; add remappable controls, ADS sensitivity, gyro, aim-assist tuning, auto-pickup, subtitles, colorblind indicators and text scaling.
- [ ] Footsteps by surface/distance, directional audio, weapon sounds, lobby/music/emote/victory sound design.

## 13. Account and data
- [ ] Guest account, secure login/linking, recovery, profile, cloud save, inventory sync and multi-device conflict handling.
- [ ] Account deletion, privacy policy, terms, age-appropriate safety controls and support flow.
- [ ] Offline save format and safe reconciliation of local progress after reconnect.

## 14. Backend, security and operations
- [ ] Authentication/API, database, authoritative match servers, matchmaking, room service and player presence.
- [ ] Server-side rank/currency/inventory/result validation; rate limiting, abuse prevention and session security.
- [ ] Anti-cheat telemetry, suspicious-result detection, report/review/ban/appeal workflow.
- [ ] Event configuration, notifications, analytics, crash reporting, monitoring, backups and disaster recovery.
- [ ] Capacity/load scaling, regional servers, latency monitoring and maintenance/status messages.

## 15. Quality assurance and launch
- [ ] Unit/integration tests, offline QA, multi-device online QA, disconnect/reconnect tests and custom-room tests.
- [ ] Performance, memory, battery, thermal, packet-loss and low-end Android tests.
- [x] GitHub Actions workflow foundation for Android release APK artifact.
- [ ] Validate workflow build; signed release configuration; versioning/update process; beta testing; store compliance and support readiness.

## Launch gate
Do not call the game launch-ready until all mandatory gameplay, security, backend, device-test and release-signing checks are completed. Features that depend on servers remain unavailable until the backend is connected and tested.

## Offline prototype status update (2026-10-24)

The Godot prototype source now includes basic bot safe-zone awareness, randomized movement/attack decisions, a short obstacle probe with sidestep behaviour, bot zone damage, and HUD touch input routed through `_unhandled_input`. These are prototype-level implementations and still require Godot runtime validation. Do not mark full navigation AI, full six-mode gameplay, or Android QA complete based on these additions.


## Recent prototype progress
- [x] Procedural POI building shells with doorway gaps and wall collision (basic interiors; runtime verification pending).
- [ ] Furnished interiors, loot rooms, stairs, multiple floors and building-specific cover layouts.

## 16. Premium currency, top-up, Prime and multi-currency economy
- [ ] Original premium currency: **Eclipse Gems** (working name), with clear balance, transaction history, and premium cosmetic/event uses.
- [ ] Official store-backed Top-Up Center with region-aware products, base amount/bonus display, first-top-up eligibility rules, confirmation, pending/success/failure handling, purchase history, restore/reconcile, refund/revocation handling, and support flow.
- [ ] Server-side platform receipt verification; client callback alone must never grant premium currency.
- [ ] Original eight-tier loyalty progression: **Shadow Prime I–VIII**, based on verified lifetime qualifying purchases or a documented stable Prime-points formula; current gem balance must not determine tier.
- [ ] Configurable Prime thresholds, progress UI, level-up grants, reward table for all eight tiers, idempotent claims, audit history, and documented refund/chargeback policy.
- [ ] **Royale Gold** soft currency with gameplay earn sources, balanced sinks, and a Gold Store.
- [ ] **Rift Tokens** event currency with event-specific earn tables, Event Token Exchange, expiry/carry-over disclosure, and validated spending.
- [ ] Eclipse Store, Royale Gold Store, and event-specific token exchange with item previews, prices, eligibility, ownership state, and confirmation.
- [ ] Event configuration for login rewards, missions, match milestones, limited cosmetics, token shop, server-time schedule, and end-of-event behavior.
- [ ] Currency ledger, transactional balance updates, idempotency, purchase reconciliation, duplicate receipt prevention, refund/revocation handling, and anti-fraud monitoring.
- [ ] Offline mode must never mint verified premium currency, online Prime progress, real purchase entitlements, or global event leaderboard results.
- [ ] No pay-to-win combat advantages tied to top-ups/Prime; competitive balance remains fair.
- [ ] Admin tools for catalog, Prime thresholds/rewards, events, transaction investigation, audited compensation, and fraud/support workflows.
- [ ] Metrics: checkout funnel, verification latency/failures, currency earn/spend, Prime distribution, event token flow, refunds, and suspicious transaction patterns.
- [ ] Store policy, regional pricing, age/parental requirements, privacy, refund disclosures, and billing compliance review before launch.
- [ ] Until verified billing and backend tests pass, Top-Up UI must remain disabled or explicitly labeled as a non-purchasable prototype.


## Implementation audit addendum — 2026-10-24

- [x] Lobby entry to Eclipse Gems / Top-Up / Shadow Prime preview.
- [x] Eight Prime tier definitions and pure qualifying-total mapping helper.
- [x] Prime VIII cap at 200,000 qualifying Eclipse Gems; no Prime IX.
- [x] Prime threshold unit tests added and CI configured to run `flutter test`.
- [x] Flutter Training Ground stationary target reset behavior and restart-state reset.
- [ ] Real purchase catalog, official platform billing, server receipt verification, immutable ledger, refunds/chargebacks and server-authoritative Prime rewards.
- [ ] Production backend, online multiplayer, global progression, release-grade 3D content, device performance QA and store compliance.
- Source-level status is not runtime verification. See `docs/IMPLEMENTATION_AUDIT_2026-10-24.md`.


## 16. Admin panel and live operations (Blueprint section 23)
- [x] Responsive standalone admin console front-end scaffold (`admin_console/index.html`).
- [x] Navigation surfaces for overview, players/sanctions, match inspection, economy ledger, content/store, events/seasons, support/reports, server health, audit log and roles/access.
- [x] Prime I–VIII reference thresholds included; Prime VIII is 200,000+ qualifying verified cumulative Eclipse Gems; no Prime IX.
- [x] Demo CSV export, sample-table search and visible non-production safety labels.
- [ ] Admin identity provider, MFA, secure sessions and server-enforced RBAC.
- [ ] Production API integration, real records, immutable audit logs and approvals.
- [ ] Live player sanctions, transaction investigation, verified reward grants, publishing and incident actions.
- [ ] Real telemetry, alerting, backups, restore drills and incident response.

**Important:** checked items above mean front-end scaffolding exists, not that the corresponding production service is live.


## Social UI implementation addendum — 2026-10-24
- [x] Team tab opens a dedicated Friends & Team screen instead of generic placeholder tiles.
- [x] Search-by-name/UID interaction against a clearly labelled synthetic local directory.
- [x] Local friend-add preview with a Prime-tier capacity preview (Prime I 100, then configurable increments to Prime VIII 200). Values are proposed and must be approved as product rules before release.
- [x] Local six-character team-code generation and join-code format validation.
- [x] Party invite UI for locally added demo friends, with squad preview capped at four.
- [ ] Real UID/name lookup, request/accept/reject/block/report, online state and cross-device friend synchronization.
- [ ] Server-issued unique team codes, party membership, invite delivery, join permissions, reconnect and matchmaking integration.
- [ ] Knocked/downed teammate state, bleed-out timer, revive interaction/animation, interruption rules and server-authoritative validation. Current Godot prototype is solo versus bots and has no teammate revive loop.
- These checked items are local UI/demo behavior only, not online services. Flutter/Dart runtime tests were not available in the working environment.


## Squad / revive gameplay pass — 2026-10-24
- [x] Godot offline Squad Battle Royale mode selector with three AI squadmates and 12 enemy bots.
- [x] Squadmate AI follows the player and can be damaged by enemy bots; downed state starts a 35-second bleed-out timer.
- [x] Revive HUD action; nearest downed teammate within 2.8 metres can be revived over 4 seconds; leaving range or losing the player cancels the revive.
- [x] Revived squadmate returns at 45 HP; bleed-out expiry eliminates the teammate.
- [ ] Runtime validation in Godot 4.3+, gameplay balance, teammate pathfinding/cover/combat, player-down/revive rules, and online authoritative squad replication.
- Important: this is a local AI squad mechanic, not online human-team revive. No Godot executable is available in the build environment, so syntax and in-engine behavior are not runtime-verified.

## 2026-10-24 additional implementation

- Added device-local persistence for the Social Hub friend set, invite markers, Prime-cap preview and generated team code. This improves persistence after app restart but does not turn sample profiles into real accounts or enable remote invites/team joins.
- Added an initial Supabase schema migration for profiles, friendships, parties, wallets/ledger, store receipt records, Prime tier calculation, admin roles/audit and baseline RLS. It is not connected to the client and has not been applied to a live database.
- Static audit checks cover these source artifacts; they do not validate Flutter compilation, SQL execution, RLS behavior, online functionality, or Android device behavior.

## Multiplayer implementation status — 2026-10-25

- [x] Dedicated ENet server foundation with 50-peer cap and Supabase Auth token verification source.
- [x] Standalone visual network test client for server-owned position snapshots and rate-limited movement input.
- [x] Static source audit: 69 checks pass (not an engine runtime test).
- [ ] Integrate the online test client with the existing main gameplay scene.
- [ ] Move shooting, damage, loot, zone, revive, and win determination to authoritative server logic.
- [ ] Add party/matchmaking, persistent results, reconnection, abuse controls, and server health monitoring.
- [ ] Run Godot parser/import checks, two-device integration tests, and staged 2/4/10/25/50-client load tests.


## Online test-slice status update
- [x] Server-owned static ammo and medkit pickup state
- [x] Server validates alive state and pickup distance
- [x] Pickup inventory/reward values are assigned by server
- [x] Loot presence and player inventory counters replicate in snapshots
- [ ] Integrate network slice with the main Veylora gameplay scene
- [ ] Connect ammo reserve to weapon magazine/reload logic
- [ ] Add real networked squad revive and match result persistence
- [ ] Run Godot parse/play tests and a 50-client load test

## Online test weapon loop status (2026-10-25)
- [x] Server-owned 30-round magazine and per-shot ammo consumption
- [x] Server-side empty-magazine/reload-state shot rejection
- [x] Server-validated 1.8-second reload using reserve ammo
- [x] Snapshot replication of magazine, reserve ammo, and reload state
- [x] Client `R` key reload request and HUD result feedback
- [ ] Integrate network client and authoritative weapon loop into main Veylora gameplay
- [ ] Add visual weapon/projectile effects, reload animation, and weapon switching
- [ ] Persist completed match results and validate 50-player load in a running server



### Online test-slice revive
- [x] Server validates target identity, distance, active downed window, revive duration, and restored HP.
- [x] Online test client exposes F-key nearest-downed-player revive request.
- [ ] Restrict revive to squadmates and add animation/progress UI.
- [ ] Verify with Godot runtime and multiple connected clients.


## Android touch-control follow-up — 2026-10-25
- [x] Online test client on-screen four-way movement pad.
- [x] Online test client touch FIRE, REVIVE, RELOAD, and PICK UP controls.
- [x] Touch movement uses the existing server-authoritative movement request.
- [x] Touch fire has a mobile aim fallback; desktop controls remain available.
- [ ] Integrate the online client controls into the main Veylora gameplay scene.
- [ ] Run Godot editor/runtime checks and test the layout on a real Android phone.
- [x] Online test-client touch-control layout scales/repositions based on viewport size changes (static check only)
- [ ] Verify mobile touch controls on actual Android portrait and landscape devices

## Follow-up status — 2026-10-25
- [x] Prototype squad ID replicated from server (groups of four; temporary assignment only)
- [x] Server prevents friendly fire within the assigned squad
- [x] Server rejects revive attempts against players outside the same squad
- [x] Mobile auto-aim and revive target selection skip/filter squadmates
- [x] Disconnect cleanup cancels revive target references
- [ ] Integrate real party/matchmaking squad IDs
- [ ] Persist match results securely on backend and show a final results screen
- [ ] Validate Godot runtime, Android touch behavior, and 50-player server load

## Ranked progression foundation — 2026-10-25
- [x] Added a server-oriented, pure rank calculator for CS-style ranked points/stars and Battle Royale placement/kills/survival points.
- [x] CS-style tiers: Rookie → Bronze → Silver → Gold → Platinum → Diamond → Elite → Heroic → Master → Grandmaster; 100 points per star, five stars per tier.
- [x] BR-style tiers: Bronze (0), Silver (200), Gold (450), Platinum (800), Diamond (1,250), Crown (1,800), Heroic (2,400), Master (3,200), Grandmaster (4,200).
- [x] BR point table: 1st +80, 2nd +60, 3rd–5th +40, 6th–10th +20, 11th–20th +5, 21st+ −20; +8 per kill (up to 5), +1 per 2 minutes survived (up to 10); match delta capped at −30/+130.
- [x] CS-style match delta: win +25 / loss −15, ±2 per round differential (clamped to five rounds), +1 per kill (max 10); final delta clamped −25/+40.
- [x] Added Supabase schema for per-mode ranked profiles and immutable-per-match result rows, with own-row read-only RLS and no client writes.
- [ ] Wire ranked mode selection into real matchmaking, track full match placement/round outcome, settle rating only once on the trusted server, and show end-of-match rank delta UI.
- [ ] Add a trusted backend writer with idempotent transaction settlement and deploy/test migration 002 against a Supabase test project.
- Important: these are proposed Shadow Royale balance defaults, not official Counter-Strike or Free Fire rules. Rank calculator and schema are foundations; live rank points are not yet persisted or awarded by the current match server.

## Ranked progression hardening — 2026-10-25
- [x] Add trusted SQL settlement function for CS-style and BR ranked result point deltas.
- [x] Make rank settlement transactional and idempotent per match/user; service-role execution only.
- [x] Expose star/tier progress-to-next-threshold values in the rank calculator.
- [ ] Apply migration 003 to a test Supabase project and verify policies/function grants with read-only SQL checks.
- [ ] Call settlement only after the authoritative match server has a real, complete end-of-match result.
- [ ] Build the live ranked results screen, promotion/demotion feedback, season lifecycle and leaderboard after backend integration.
- Important: the online server currently remains a movement/combat test slice; this migration does not itself make ranked awards live.

## Full-project audit update (2026-10-25, follow-up pass)
- [x] Replace the misleading hard-coded `IRON III` lobby rank with `UNRANKED` until trusted server sync exists.
- [x] Add a dedicated Ranked screen that clearly separates Classic Ranked star progression from BR Ranked point tiers.
- [x] Add Flutter pure ranking helpers and unit tests for score boundaries, top-tier behavior, placement bands, and caps.
- [x] Keep point totals above the top tier threshold instead of silently clamping rating totals; top-tier rank is capped, rating is not.
- [x] Harden settlement SQL against null mode/result payloads and duplicate user IDs within a single submitted match result batch.
- [ ] Run `flutter test` and `flutter analyze` in CI; these tools are not installed in the current authoring environment.
- [ ] Parse/run the Godot project and validate GDScript/scene references using Godot 4.3+.
- [ ] Connect the dedicated server's match lifecycle to the trusted settlement endpoint; do not grant ranked points from the client.
- [ ] Implement real BR last-team-standing completion and CS round-based match completion before enabling ranked queue buttons.
- [ ] Add server-sourced results screen with before/after points, stars/tier promotion or demotion, placement, kills, and season summary.
- [ ] Deploy migrations 001-003 to a disposable Supabase project and test RLS, service-role-only settlement, duplicate retries, malformed payloads, and concurrent settlements.
- [ ] Complete account auth, party matchmaking, remote lobby, reconnect/rejoin, result persistence, leaderboard, season reset/reward policy, moderation, and ops monitoring.
- [ ] Complete Android device testing (low-end device, touch layout, orientation/resize, memory/thermal/battery), packet-loss/reconnect tests, and staged multi-client load tests.
- [ ] Review release workflow output, signing, privacy/terms, store compliance, and crash reporting before any public release.


## Offline-first release pass (2026-10-25)
- [x] Remove the lobby's online ON/OFF switch; app starts in offline-first mode.
- [x] Mark online multiplayer and both online ranked queues as maintenance/unavailable in the lobby.
- [x] Guard unavailable ranked modes with a maintenance dialog and an offline-play route.
- [x] Keep offline Battle Royale, Classic, Lone Wolf and Training Ground available.
- [x] Separate match pause/resume from match completion in the offline arena.
- [x] Add widget tests for maintenance messaging and launching an offline match.
- [ ] Run Flutter tests/analyzer and Android-device gameplay validation in a Flutter-enabled environment.
