# Shadow Royale multiplayer server foundation

Date: 2026-10-25

## Added source

- `godot_engine/server/dedicated_server.gd`: separate headless ENet server entry point, 50-peer cap, 20 Hz snapshot tick, monotonic input sequence checks, bounded movement input, world bounds, disconnect cleanup, duplicate account-in-match prevention, and Supabase Auth token validation through `GET /auth/v1/user`.
- `godot_engine/server/server.tscn`: dedicated server scene.
- `godot_engine/scripts/network_client.gd` and `godot_engine/server/network_client.tscn`: standalone 3D online movement-test client with procedural player capsules, WASD input at 20 Hz, snapshot rendering, camera follow, status HUD, and Supabase token handshake.
- `supabase/migrations/001_core_schema.sql`: previously added persistent-data schema foundation.

## Local run (after installing Godot 4.3+)

1. Create/use a disposable Supabase project and configure Auth.
2. In the shell used to launch Godot, set `SUPABASE_URL` and `SUPABASE_ANON_KEY`. These are server environment variables; do not add service-role keys to the client. The anon/publishable key is not a secret, but token verification still relies on the user's access token.
3. Optionally set `GAME_PORT` (default `2456`). Allow inbound UDP on that port in your firewall/host.
4. Run the project root scene for local prototype as usual. To start the dedicated server, run from the project directory:

   ```sh
   godot --headless --path godot_engine --scene res://server/server.tscn
   ```

5. Launch the standalone visual client from a second Godot process: `godot --path godot_engine --scene res://server/network_client.tscn`. For a development-only test, set `SUPABASE_ACCESS_TOKEN` to a valid user access token and optionally `MATCH_HOST` before launching. The client auto-connects when the environment token is present. Never commit the token or put it in a shipped build. You can also call `connect_to_match(host, port, supabase_access_token)` from an authenticated app session.

## Honest implementation boundary

This is a **transport/auth/movement prototype**, not a complete online match implementation. It does not yet spawn replicated visual player avatars into the existing `main.tscn`, implement authoritative shooting/hit validation/loot/zone/revive, create matchmaking or allocate servers, write match results to Supabase, or provide reconnect recovery. The existing playable scene still runs locally with bots. The new visual network test scene demonstrates only replicated server-owned positions; it is intentionally separate from the local gameplay scene. Shooting, damage, loot, zone, revive, matchmaking, result persistence, and reconnect still must be integrated before this can be called an online playable match.

The server currently authenticates a Supabase access token using the Supabase Auth user endpoint, then holds the resulting user ID in in-memory match state. A production deployment still needs rate limits, TLS-secured control-plane calls where applicable, token expiry/revalidation, abuse controls, server health checks, structured logging, secrets management, and load tests. Never use the service-role key in the Android client. Do not treat client-reported kills, currency or results as authoritative.

## Free-tier expectations

This server process still needs a host that accepts inbound UDP. Supabase does not host the Godot ENet match process. Free hosting availability and UDP support vary, so local testing can be free but stable public matches may require paid compute. Do not advertise 50-player readiness until 50 clients have passed load and gameplay tests on the chosen host.

## Test status

Source-level audit only. The standalone network client scene now renders remote entities from snapshots and sends bounded-rate movement input, and late auth responses from disconnected peers are ignored. No Godot executable is installed in the current environment, so this code has **not** been parsed or run by the Godot engine. The server/client scripts must pass a Godot import, two-client integration test, and staged 2/4/10/25/50-client load tests before release.


## Next slice: server-authoritative combat prototype (2026-10-25)

The standalone test client now sends mouse-aimed fire requests. The dedicated server applies a 220 ms shot cooldown, validates finite normalized aim, checks a 42-unit range and a narrow forward cone, and applies 25 damage to the nearest eligible player. Eliminations increment server-owned kills/deaths, dead players cannot move, and the server respawns them after five seconds at a randomized test-arena position. Snapshots include health, kills, deaths and respawn countdown.

This is a minimal prototype hit test, not production combat: it does not yet raycast against the game world, respect cover/armor/weapon classes, use lag compensation, or integrate with the existing Veylora gameplay scene. The current match simulation and combat need runtime validation with Godot and multiple clients before any claim of working online gameplay.


## Cover and line-of-sight slice (2026-10-25)

The standalone online test arena now renders seven simple cover blocks. The dedicated server applies axis-separated movement collision against matching rectangular cover volumes and rejects hitscan shots that intersect cover. This is a deterministic test-arena collision approximation, not the production Veylora collision mesh; dimensions must remain synchronized between the server constants and client visual blocks. The network test still does not load the full main gameplay scene, and runtime validation remains required.

## Safe-zone and spawn prototype
The dedicated server now owns a simple circular safe zone centered at world origin. Its radius linearly shrinks from 100 m to 18 m over 180 seconds; living players outside it take 5 HP per second. Snapshot data includes the current radius and remaining shrink time, which the standalone test client displays as a ring and HUD status. Spawn selection makes bounded attempts to avoid cover and active players before using a fallback. These are test-arena rules only and still require Godot runtime validation and later integration with the actual Veylora match/map.
