# Shadow Royale — Ranked progression design

This is an original proposed ruleset for Shadow Royale, inspired by familiar star/tier progression. It does **not** claim to reproduce official Counter-Strike or Free Fire ranking formulas.

## Separate queues

- `cs_ranked`: round-based competitive queue. At match end, apply a bounded rating delta and show star progress. Casual/TDM/training never alter this rating.
- `br_ranked`: large-map Battle Royale queue. At match end, award points from placement, kills, and survival time. Casual and training never alter this rating.

## CS-style points and stars

Default match delta = win `+25`, loss `−15`, plus `2 × round differential` (round differential limited to −5..+5), plus `1 × kills` (maximum 10 kill points). Final match delta is limited to −25..+40. Rating never drops below zero. Every 100 rating points equals one star; five stars advance to the next tier.

Tiers in order: Rookie, Bronze, Silver, Gold, Platinum, Diamond, Elite, Heroic, Master, Grandmaster. The last tier is capped in the initial design.

## BR points

| Placement | Base points |
|---|---:|
| 1st | +80 |
| 2nd | +60 |
| 3rd–5th | +40 |
| 6th–10th | +20 |
| 11th–20th | +5 |
| 21st or lower | −20 |

Add `+8` per kill (up to five kills count) and `+1` per two minutes survived (up to ten survival points). Clamp a match delta to −30..+130. Rating never drops below zero.

BR tiers: Bronze 0, Silver 200, Gold 450, Platinum 800, Diamond 1,250, Crown 1,800, Heroic 2,400, Master 3,200, Grandmaster 4,200.

## Integrity requirements before launch

1. The server determines mode, kills, round result, placement and duration. Never accept these values as client claims.
2. Settle each `(match_id, user_id)` once; use a database transaction and unique key for idempotency.
3. Client may read its own rank profile and match history but cannot write rank points or match results.
4. The existing online prototype currently respawns players and does not have a full BR last-team-standing or CS round lifecycle. Therefore this design is not yet wired to live point awards. Do not advertise ranks as live until matchmaking, match completion, trusted persistence, and runtime tests are implemented.

## Match settlement hardening (2026-10-25)

Migration `003_ranked_match_settlement.sql` adds a `SECURITY DEFINER` settlement function that updates profile points and inserts match results in one database transaction. It uses a per-match/user advisory transaction lock and the unique `(match_id, user_id)` key to avoid duplicate awards. Execute permission is revoked from `public`, `anon`, and `authenticated`, and granted only to `service_role`. The backend must keep the service-role key secret and call this function only after verifying a finished match from trusted server state.

The Godot calculator exposes `points_into_star`, `points_to_next_star`, and `points_to_next_tier` so a results/progression screen can show progress. The SQL migration has not been applied to a live Supabase project and has not been executed against PostgreSQL in this environment. The online server does not yet call settlement at match end; live awards remain gated until the server's complete BR/CS match lifecycle is integrated and tested.

## Familiar competitive progression principles used (original implementation)

- Separate ratings for Classic/CS-style ranked and large-map BR ranked; casual, training and TDM never award ranked points.
- Tier promotion is driven by rating thresholds; CS-style stars are visible progress units, while BR uses tier thresholds.
- Match results must be settled once by trusted server logic; clients only read their own profile and history.
- Season resets, protection cards, leaderboard rewards and promotion animations are future work, not silently simulated in the current prototype.
- These are general genre conventions, not copied Free Fire assets, names, exact formulas or proprietary UI.
