# Squad revive implementation and QA report — 2026-10-24

## Implemented in Godot source
- Added `scripts/squadmate.gd` with health, knockdown, bleed-out countdown, elimination, follow movement, and revive recovery.
- Added an offline `SQUAD BATTLE ROYALE` mode that spawns three AI squadmates and twelve enemy bots.
- Enemy bots can select the nearest living squadmate as their combat target when that teammate is nearer than the player and within 24 metres.
- Added the HUD `REVIVE` action. It selects the nearest downed teammate within 2.8 metres and starts a four-second revive. Moving out of range, the player being eliminated, or the target becoming invalid cancels it.
- Successful revive restores the teammate at 45 HP. Bleed-out duration is 35 seconds.
- Updated the feature checklist, Godot README, and static source audit.

## Verification performed
- Static source audit: all checks passed, including new squad/revive source checks.
- ZIP integrity: verified after packaging.

## Verification not performed
- Godot editor/runtime execution, parser/import validation, Android export, or real device gameplay test: the Godot executable is not installed in this environment.
- Network multiplayer, human teammate state replication, server-authoritative revive, remote party/friend/UID services, or backend persistence are not implemented by this offline AI feature.

## Required next production integration
Use an authoritative multiplayer server to own player health, downed/bleed-out state, revive distance/time checks, revive interruption, and elimination. Client-only revive must not grant a competitive advantage in online matches.
