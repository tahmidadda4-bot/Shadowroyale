# SHADOW ROYALE — MASTER GAME BLUEPRINT

**Document type:** Master Game Design Document (GDD) + Technical Blueprint + Production Roadmap  
**Document version:** 1.0  
**Last updated:** 24 October 2026  
**Status:** Master target specification; not a claim that every feature is implemented.  
**Primary platform:** Android  
**Primary engine target:** Godot 4.x  
**Client technology in current repository:** Flutter UI prototype + separate Godot 3D prototype  
**Project approach:** Complete and validate the offline/client foundation first; add production online/backend systems as a separate verified phase.

---

## 0. How to Use This Document

This is the single source of truth for the intended Shadow Royale game. When this file is provided in a future conversation, use it to understand the game scope, feature rules, architecture, currency names, Prime thresholds, acceptance criteria, and remaining work. Do not treat a listed feature as implemented merely because it appears here.

Every feature must have one status:
- **Planned** — scope is described but implementation has not been confirmed.
- **In progress** — implementation is underway.
- **Implemented — not verified** — code/assets exist but runtime/device tests have not passed or have not been run.
- **Verified** — acceptance tests passed and evidence is recorded.
- **Deferred** — intentionally excluded from the current milestone, with reason recorded.

A feature is **Complete** only when its specification, implementation, integration, tests, failure handling, performance/security checks where relevant, and documentation are all satisfied. Any test that has not actually been run must remain unverified.

## 1. Game Vision and Pillars

**Shadow Royale** is an original 3D tactical survival shooter/battle royale game. The target experience includes one large connected island map, six distinct game modes, offline Bot gameplay, online multiplayer in a later phase, character and weapon customization, progression, social features, events, stores, premium top-up, and a secure eight-tier Prime loyalty system.

### Core pillars
1. Offline gameplay that works without an internet connection.
2. A readable, navigable, combat-ready 3D world with accessible building interiors.
3. Fair weapon handling, responsive touch controls, understandable combat feedback.
4. Bots that navigate terrain and buildings without unfair perception or impossible accuracy.
5. Six modes with genuinely distinct rules, objectives, scoring, HUD, and results.
6. Clear separation between local/offline progress and verified online progress.
7. Original Shadow Royale names, visual identity, UI, content, and economy. General genre inspiration is acceptable; do not copy another game's proprietary art, assets, exact UI, or branding.
8. Modular content and configuration so new weapons, missions, events, and rewards do not require rewriting unrelated systems.
9. Mobile-first performance and accessibility.
10. Secure server-authoritative handling of competitive results, paid currency, purchases, and online rewards.

### Scope principles
- The existing repository is a prototype, not a finished commercial game.
- Current source features must be checked against the repository and tested before being called complete.
- Online multiplayer requires an authoritative game-server architecture; a database/backend alone is not sufficient for a real-time shooter.
- Offline practice cannot create verified online ranked results, premium purchases, Prime progress, or global event results.
- Monetization must not grant direct ranked combat advantages such as extra damage, health, accuracy, or movement speed.

## 2. Product and Platform

- **Primary platform:** Android phones and tablets.
- **Engine target:** Godot 4.x 3D game runtime.
- **Existing client code:** Flutter app shell/prototype and a separate Godot prototype. Final integration/export architecture must be explicitly validated rather than assumed.
- **Input:** Touchscreen controls; optional keyboard/gamepad support for development and testing where practical.
- **Offline:** Local profile, local save, Training Ground, Bot matches, local settings, and approved local practice progress.
- **Online (later phase):** Authenticated account, matchmaking, authoritative matches, verified rank, inventory, store, social systems, and global statistics.
- **Release formats:** APK for direct QA/install testing; AAB for Google Play distribution if selected.

## 3. Full Screen and Navigation Architecture

### Startup flow
1. Splash / logo.
2. Startup checks, asset/config validation, and local save load.
3. Offline/online availability check without blocking offline play.
4. Optional account sign-in or guest/local profile.
5. Main lobby.

### Main lobby
- Top bar: avatar, display name, level, UID, Eclipse Gems, Royale Gold, notifications, mail, settings, connection/server status.
- Center: 3D character preview, equipped outfit, weapon skin, pet/companion, idle animation, rotate/zoom.
- Play panel: mode, map/region where applicable, Solo/Duo/Squad, ranked/unranked, start button, party state.
- Navigation: Loadout, Inventory, Profile, Missions, Events, Season Pass, Store, Top-Up, Friends, Clan, Leaderboards, Achievements, Custom Room, News, Support, Settings.
- All buttons must navigate to real screens/actions or be explicitly marked as unavailable/coming later. No fake-success buttons.

### Required screens
- Splash/startup.
- Guest/login/account-linking (online phase).
- Main lobby.
- Mode selection and team size.
- Map/region selection where applicable.
- Match loading and pre-match state.
- Gameplay HUD and pause menu.
- Inventory/loot screen.
- Map/minimap and squad status.
- Match results and rewards.
- Profile and statistics.
- Rank and season.
- Missions, achievements, events, rewards.
- Loadout, character, cosmetics, pet, emotes.
- Eclipse Store, Royale Gold Store, Rift Token Exchange, Top-Up Center.
- Friends, party, clan, chat, custom rooms.
- Settings/accessibility/help.
- Mail/notifications, support/report, privacy/account deletion.

## 4. Six Main Game Modes

Each mode must have its own configuration, eligibility rules, spawn logic, HUD, scoring, win condition, rewards, match-history classification, and tests. Merely showing six mode buttons does not count as implementing six modes.

### Mode 1 — Battle Royale (BR)
- Main survival mode on the island map.
- Solo, Duo, and Squad queues are target options where player population and server capacity support them.
- Deployment/spawn phase, looting, combat, safe-zone phases, zone damage, elimination and last-player/team-standing victory.
- Placement, kills, assists, damage, survival time, and match result summary.
- Offline variant uses local Bots and local-only results.

### Mode 2 — BR Ranked
- BR rules with verified rank points, divisions/tiers, season leaderboard, matchmaking rating, and season rewards.
- Server-authoritative placement and results.
- AFK, disconnect, abandonment, boosting, and suspicious-result rules.
- Offline practice may imitate the rules but must never modify global rank.

### Mode 3 — Classic
- Casual survival mode with configurable match length, loot density, Bot count, zone timing, and reward rates.
- Intended to reduce competitive pressure while preserving a survival loop.
- Offline and online variants must use explicit configuration differences.

### Mode 4 — Classic Ranked
- Competitive Classic variant with its own rating and season handling.
- Clear score/rank change explanation after each match.
- Server validation, matchmaking restrictions, abandonment rules, and leaderboard.

### Mode 5 — Lone Wolf 1v1
- One player against one opponent, in a small arena or designated combat area.
- Round timer, score target/round limit, spawn protection, weapon/loadout rules, tie handling, disconnect handling, and rematch option.
- Offline Bot opponent; real opponent in online version.
- Optional separate duel rating must be explicitly enabled and configured.

### Mode 6 — Training Ground
- No ranked penalty or matchmaking requirement.
- Static and moving targets, weapon switching, ammo options, recoil practice, aim/sensitivity calibration, grenade practice, Bot combat, damage numbers, hit-rate and reaction exercises.
- Target reset and Bot spawn controls.
- Practice stats are local or clearly labeled practice data.

### Mode rules matrix
| System | BR | BR Ranked | Classic | Classic Ranked | Lone Wolf | Training |
|---|---|---|---|---|---|---|
| Safe zone | Yes | Yes | Configurable | Configurable | Usually no | No |
| Local Bots | Offline | Offline practice only | Offline | Offline practice only | Offline opponent | Optional |
| Global rank changes | No offline | Online verified only | No | Online verified only | Only if duel rating is configured | No |
| Results/rewards | Mode-approved | Server verified | Mode-approved | Server verified | Mode-approved | Limited/local |
| Real players | Online version | Online version | Online version | Online version | Online version | Optional future feature |

## 5. One Large Map — Veylora Island

The target is one large, connected island map, not six separate full maps. The six modes may reuse it; Lone Wolf can use a small dedicated arena and Training Ground can use a restricted practice area.

### Target regions / POIs
1. **Veylora Outpost** — small buildings, garages, watchtower, supply rooms; accessible beginner/medium-risk loot.
2. **Ashen Depot** — warehouses, cargo crates, industrial interiors; close-range combat and cover.
3. **Nexora Relay** — communication towers, control rooms, roof access where designed; mid/long-range engagements.
4. **Drakemoor Camp** — barracks, storage, compounds; squad looting and defense.
5. **Central City** — multi-storey buildings, shops, roads, interiors; high-risk/high-reward combat.
6. **Coastal Port** — containers, docks, warehouses; long sightlines and container cover.
7. **Forest Belt** — trees, rocks, uneven terrain; stealth and rotation.
8. **Mountain Ridge** — elevation, cliffs, viewpoints; long-range combat.
9. **River and Bridge Network** — crossings, choke points, water rules.
10. **Airfield** — runway, hangars, control tower; exposed traversal.
11. **Ruins** — broken structures and covered routes; ambush/exploration.
12. **Safehouse Compounds** — smaller compounds for regrouping and basic loot.

Names and target roles are part of the design. Exact coordinates, scale, routes, and visual layout are to be built and validated.

### Map/world requirements
- Terrain heightmap/mesh, slopes, rocks, trees, bushes, water, coastline, cliffs, bridges, tunnels, and map boundaries.
- Main/secondary roads, junctions, lane markings, bridges, and collision.
- Buildings with floors, roofs, walls, doorways, windows, stairs, and valid collision.
- Furnished interiors where gameplay requires them; not every exterior shell needs an interior.
- Loot spawn sockets and cover placement anchors.
- Indoor/outdoor minimap representation.
- Navigation meshes and connections for terrain, rooms, stairs, floors, and doorways.
- Lighting, shadows, fog/weather variants if included, environment ambience, and performance LODs.
- Sound occlusion and indoor/outdoor gunshot behavior.
- Out-of-bounds prevention, fall rules, and accessible spawn points.
- Optional destructible objects/vehicles only if the scope and performance budget support them.

### Map acceptance tests
- No spawn inside walls, below the terrain, outside bounds, or in inaccessible locations.
- Loot is reachable and not embedded in collision.
- Bots can enter/exit designated buildings and traverse stairs/bridges.
- Zone cannot end in an invalid or unreachable location.
- Player cannot fall out of the world or get permanently stuck in map geometry.
- All POIs are profiled on target Android devices.

## 6. Building Interiors, Loot, and Cover

- Building prefabs have clear entry/exit routes, collision, navigation, lighting, and interior/exterior transitions.
- Multi-floor buildings require valid stairs/ladders or explicitly blocked floors.
- Loot tables support weapon, ammo, healing, armor, utility, cosmetic/event item previews where appropriate, and rarity weights.
- Loot is placed using approved spawn anchors, not blind random coordinates inside walls.
- Cover includes crates, concrete barriers, furniture, containers, and designated walls.
- Cover objects have collision and optional cover-height/penetration metadata.
- Bot cover selection considers distance to enemy, health, incoming fire, and available routes.
- Loot pickup is idempotent: one item cannot grant multiple times from duplicate collision callbacks.
- Inventory full, inaccessible item, expired item, and concurrent pickup cases have explicit outcomes.
- If destructible cover is included, define health, damage, debris, replication, and performance rules.

## 7. Player Characters, Animation, and Cosmetics

### Character content
- Base rigged character models and consistent skeletons.
- Face/body/hair options only where supported by the art pipeline.
- Outfits, jackets, pants, shoes, helmets, backpacks, character skins, profile frames, titles, banners, and emotes.
- Pet/companion models and idle/follow animations if retained in scope.
- Cosmetic items must not create unfair ranked combat advantages.

### Required animation states
- Idle, walk, run, sprint, strafe, turn.
- Jump, fall, land, crouch; prone/vault/climb/swim only if implemented in the final movement design.
- Hip-fire, ADS, fire, reload, weapon switch, weapon inspect.
- Hit reaction, stagger, death, victory/defeat.
- Loot pickup, heal, grenade throw, door interaction, revive if the mode includes revive.
- Lobby idle, emotes, and character preview animations.
- Bot patrol, investigate, chase, attack, take cover, retreat, reload, and death.

### Animation technical requirements
- Rig/skeleton and bone hierarchy standards.
- State machine/blend spaces and animation layering.
- Weapon socket and hand-grip alignment.
- Aim offsets and upper-body layers.
- IK for hand/foot alignment where needed.
- Hitbox/hurtbox alignment to gameplay skeleton.
- Reload/fire/weapon-switch cancellation rules.
- Animation LOD and bone-count budgets for mobile.
- Character preview and gameplay models must use consistent item/skin IDs.

## 8. Weapons, Attachments, Inventory, and Combat

### Weapon categories
- Assault rifles (AR).
- Submachine guns (SMG).
- Shotguns.
- Sniper rifles.
- DMRs if included in the final arsenal.
- Pistols.
- Melee weapons.
- Grenades and tactical utility.

### Weapon data definition
Each weapon must have a stable ID and data for damage, fire rate, range, falloff, magazine size, reserve ammo, reload time, spread, recoil curve, firing mode, projectile/hitscan behavior, sound/VFX, animation references, rarity, attachments, and allowed modes.

### Attachments
- Sights/scopes, muzzle, foregrip, magazine, stock, and other approved categories.
- Compatibility table and clear UI indicators.
- Stat changes applied through data/config, not duplicated hard-coded logic.
- Inventory pickup/equip/remove behavior.
- Attachment effects must be balanced and tested.

### Recoil and shooting
- Per-weapon vertical/horizontal recoil curves.
- Weapon model kick and camera recoil.
- ADS transitions and hip-fire spread.
- Moving, jumping, crouching modifiers as designed.
- First-shot/burst/automatic behavior.
- Bullet travel or hitscan rules, range falloff, and head/body/limb multipliers.
- Reload timing, ammo synchronization, empty-mag feedback, and interruption rules.
- Muzzle flash, impact effects, sound, hit markers, headshot feedback, and damage indicators.
- Server validates online fire rate, ammo, damage, and hit claims.

### Grenades
- Throwable inventory slot and input.
- Aim arc/trajectory preview if chosen by design.
- Throw animation, projectile physics, bounce/roll, collision, fuse timer.
- Blast radius, line-of-sight/occlusion, damage falloff, self/friendly-fire policy.
- Indoor/outdoor behavior, audio/VFX, cleanup, and out-of-bounds rules.
- Online authority and anti-exploit validation.

### Inventory and equipment
- Primary weapon slots 1 and 2.
- Secondary weapon, melee, ammo, attachments, healing, armor, grenades/utility.
- Backpack capacity/slot limits if used.
- Auto-pickup settings and quick-use controls.
- Drop, swap, discard, equip, compare, and full-inventory behavior.
- Death/drop rules per mode.
- UI sorting, touch targets, and item detail descriptions.

### Health and combat loop
- Health, armor, healing, damage, death, elimination, spectator policy, knock/revive if included.
- Kill feed, assists, damage indicators, hit reactions, victory/defeat.
- Kill cam/replay only if feasible and explicitly scoped.
- Vehicles are optional future scope; if added, define handling, passenger seats, damage, fuel, spawn rules, and mobile controls.

## 9. Bot AI and Navigation

### AI states
Spawn/initialize → patrol/search → detect target → assess distance/cover/health → navigate or attack → retreat/cover if needed → investigate last known position → resume search.

### Requirements
- Godot NavigationRegion3D/NavigationAgent3D or a validated equivalent.
- Terrain navigation mesh and indoor navigation for rooms, corridors, stairs, doorways, and floors.
- Dynamic obstacle avoidance and collision handling.
- Spawn validation and recovery when outside navigation.
- Stuck detection, alternate route attempts, and safe fallback.
- Vision cone, distance, obstruction, last-known-position, and hearing (gunshots/footsteps) where scoped.
- Cover scoring and route selection.
- Weapon-appropriate engagement distance.
- Zone awareness and rotation.
- Difficulty profiles: Easy, Normal, Hard, Expert.
- Difficulty changes reaction time, accuracy, awareness, aggression, and tactical behavior within fair limits.
- Bot ammo/reload/healing/grenade use only where designed and tested.
- Bots must not see through walls, teleport, or use impossible aim accuracy.

### AI tests
- Enter/exit buildings, navigate stairs and narrow passages.
- Traverse bridge, slope, forest, and uneven terrain.
- Lose sight of player and investigate appropriately.
- Avoid all Bots stacking/blocking a doorway.
- Recover from stuck states.
- Take cover and rotate with the zone.
- Spawn, death, loot drop, and performance under maximum Bot count.

## 10. Match Lifecycle and Rules

Match state: Lobby → mode/squad selection → validation → loading → deployment/spawn → loot/combat → end condition → result finalization → reward/stat settlement → results screen → lobby.

Each transition needs validation, timeout handling, cancellation, crash/reconnect policy, and tests. Result settlement must be idempotent; a match cannot grant rewards twice after retries or reconnects.

### BR rules
- Player/team count, deployment, loot, zone phases, warning timer, zone damage, elimination, spectator/rejoin policy, victory condition, timeout/tie-breaker, and results.

### Classic rules
- Define explicit differences from BR using configuration: duration, loot density, zone schedule, Bot count, and reward multipliers. It must not be only a renamed button.

### Lone Wolf rules
- 1v1, rounds/timer, score target, spawn protection, loadout, timeout/tie, disconnect, round reset, rematch, and optional duel rating.

### Training rules
- No ranked penalty, configurable ammo, target reset, Bot controls, recoil/aim exercises, grenade range, sensitivity calibration, and local-only training results.

## 11. Mobile HUD and Controls

### Gameplay HUD target layout
- Top-left: minimap, compass, squad status.
- Top-center: alive count, kills, timer.
- Top-right: map, settings, network status.
- Center: crosshair, hit marker, damage feedback.
- Bottom-left: movement joystick and movement actions.
- Bottom-right: fire, aim, reload, weapon switch, jump/crouch/utility as layout allows.
- Lower-center: health, armor, weapon, ammo.
- Contextual: loot, interact, door, heal, revive.
- Side panel: kill feed, teammate markers, zone warning.

### Control customization
- Left/right-handed layouts.
- Button position, size, and opacity.
- Camera and ADS sensitivity, scope sensitivity.
- Gyroscope only where supported and implemented.
- Aim-assist settings with fair-play constraints.
- Fire behavior, auto-pickup, auto-reload, vibration/haptics.
- Invert Y, FOV/camera distance if supported, reset-to-default.
- Vehicle control layout only if vehicles are in scope.

### HUD feedback
- Low health/ammo, reload progress, hit/headshot, kill/assist, zone timer/damage, squad down/dead, network lag/reconnect, inventory full, pickup confirmation, and errors.
- Notifications must not block critical gameplay unnecessarily.

## 12. Profile, UID, Statistics, Rank, and Progression

### Profile fields
- Avatar/frame, display name, unique UID, level/XP, rank/tier, equipped character/outfit/title/badge.
- Total matches, wins, kills, deaths, K/D, win rate, average placement, damage, survival time, headshot rate.
- Mode-specific stats, recent match history, achievements, showcase items, privacy settings.

### Identity
- Server-generated UID for online accounts.
- Name uniqueness, rename policy/cooldown, profanity validation.
- Local guest ID for offline profile.
- Account link/recovery, logout, deletion, and data retention.
- Never trust a client-provided UID or role as authority.

### Progression
- Account level and XP thresholds.
- Match XP, missions, achievements, daily/weekly milestones.
- XP caps and anti-farming rules.
- Unlocks and level-up rewards.
- Offline practice stats separated from verified online/global stats.

### Rank and seasons
- Rank tiers/divisions, rating gain/loss, matchmaking rating, season start/end, reset policy, promotion rules, leaderboard, and rewards.
- BR Ranked and Classic Ranked use explicit separate rules/configurations.
- Offline results never modify online rank.

### Achievements
Examples: First Match, First Victory, Weapon Specialist, Marksman, Survivor, Squad Support, Grenade Master, Training Milestones, Seasonal Achievements. Every achievement has an ID, condition, progress, reward, claim state, and duplicate-claim protection.

### Season pass
- Free and optional premium tracks.
- Season XP, tiers, reward previews, claim state, expiry, purchase verification, and season-end behavior.

## 13. Currency, Top-Up, Shadow Prime, Stores, and Events

This section is a binding part of the Master Blueprint. Use original Shadow Royale names and visual identity. Do not copy Free Fire artwork, logos, exact UI, proprietary event designs, or branding.

### 13.1 Currency types

**Eclipse Gems — premium currency**
- Purchased through official verified top-up products or granted by specifically approved promotions.
- Used for premium cosmetics, selected event items/access, and optional pass access.
- Cannot grant direct ranked combat advantages.
- Balance and transaction history must be clear.

**Royale Gold — soft currency**
- Earned from approved gameplay, missions, achievements, and events.
- Used in the Royale Gold Store for selected cosmetics, basic unlocks, and mode-permitted supplies.
- Earn/spend rates must be balanced and monitored.
- It is not real money and does not create premium purchase entitlement.

**Rift Tokens — event currency**
- Earned through a specific event's missions and gameplay objectives.
- Redeemed in the event's Token Exchange.
- Event page must show sources, item costs, start/end times, expiry/carry-over policy, and claim requirements before spending/earning.

Each currency has a stable internal ID, icon, display name, balance, history, allowed sources, allowed sinks, and transaction rules.

### 13.2 Top-Up Center
Lobby path: **Store → Top-Up**.
- Current Eclipse Gems balance.
- Region/store-aware bundles loaded from trusted configuration.
- Product ID, base gems, bonus gems, total, price, eligibility, and purchase limits.
- First-top-up offer only if configured and clearly scoped.
- Offer start/end time from server/store configuration, not the device clock.
- Official platform payment sheet, confirmation, pending/success/failure states, retry guidance.
- Purchase history, restore/reconcile support where available, support/report-purchase path.
- Clear regional price/tax/bonus/refund conditions and applicable age/parental disclosures.
- No fake countdowns, hidden price terms, or misleading success screens.
- Offline Top-Up must say “Online connection required” or show an unmistakably non-purchasable demo preview.

### 13.3 Verified purchase flow
1. Client requests active catalog.
2. Player selects bundle and confirms.
3. Google Play Billing or another approved platform billing system processes payment.
4. Client sends purchase token/receipt to authenticated backend.
5. Backend verifies product, platform status, account binding, and duplicate processing.
6. Backend transaction grants Eclipse Gems and writes immutable ledger entry.
7. Client refreshes balance from backend and displays the verified outcome.
8. Pending transactions are reconciled; refunds/chargebacks follow a documented revocation/adjustment policy.

Client-side callback alone must never grant paid currency. Never embed service-role keys, billing secrets, or trusted balance logic in the mobile app.

### 13.4 Bundle configuration
Amounts and real-money prices are configuration, not hardcoded client logic. Catalog supports product ID, region, price, base amount, bonus, sale dates, purchase limits, eligibility, active status, versioning, staged rollout, rollback, and test/production separation.

### 13.5 Shadow Prime — exactly eight tiers
Prime tiers are named:
1. Shadow Prime I
2. Shadow Prime II
3. Shadow Prime III
4. Shadow Prime IV
5. Shadow Prime V
6. Shadow Prime VI
7. Shadow Prime VII
8. Shadow Prime VIII

**Prime VIII qualifying threshold: 200,000 Eclipse Gems.** Once the account reaches **200,000 qualifying Eclipse Gems in cumulative verified top-ups**, the account reaches Shadow Prime VIII. If the qualifying total exceeds 200,000, the account remains at Prime VIII; there is no Prime IX in this specification. The threshold means cumulative qualifying top-up amount, not current wallet balance. Spending Eclipse Gems does not lower the tier.

For Prime I–VII, use configurable ascending thresholds below 200,000. Initial proposed thresholds, to be reviewed before release, are:
- Prime I: 100 qualifying Eclipse Gems
- Prime II: 1,000
- Prime III: 5,000
- Prime IV: 15,000
- Prime V: 30,000
- Prime VI: 60,000
- Prime VII: 100,000
- Prime VIII: 200,000

These are proposed launch configuration values, not a promise that a payment price equals the same number in any local currency. A qualifying total must be based on settled, platform-verified top-ups. Pending, rejected, refunded, or charged-back transactions do not count, subject to a clear and published reversal policy. Do not calculate Prime from current gem balance. Store lifetime qualifying total, program version, current tier, progress to next tier, reward claims, and audit history server-side.

### 13.6 Prime rewards and fairness
- Every tier has a configured reward table and reward-claim state.
- Prefer cosmetics, avatar/profile frames, banners, titles, emotes, lobby effects, and access to clearly described store/event offers.
- No paid tier grants damage, health, accuracy, recoil, movement, or other ranked combat advantage.
- Show qualifying requirements and reward details before purchase.
- Recommended default: lifetime permanent tier, subject to documented verified refund/chargeback policy.
- Prime level-up and reward grants are idempotent and auditable.
- Prime VIII is the maximum tier; higher spend remains Prime VIII.

### 13.7 Stores
**Eclipse Store:** premium cosmetics, character/outfit skins, weapon skins, emotes, frames, banners, and eligible pass/event access. Show preview, rarity, ownership, price, eligibility, and confirmation. For gem purchases, backend atomically checks balance, debits currency, grants item, and writes ledger records.

**Royale Gold Store:** balanced non-pay-to-win cosmetics, basic unlocks, and allowed supplies. Prices must reflect intended earning rates. Limits must be explained.

**Rift Token Exchange:** event-specific cosmetics/collectibles. Show token sources, item costs, event time, limits, expiry/carry-over policy, and eligibility. Spending and reward grants are validated and duplicate claims blocked.

### 13.8 Events
- Login/check-in rewards.
- Daily/weekly/seasonal missions.
- Match-play milestones.
- Limited-time cosmetic collections.
- Event Token Exchange.
- Clan/community milestones if supported safely.
- Event leaderboard only with server-verified results.

Each event has ID, title, description, server start/end timestamps, eligible modes/regions, mission definitions, token tables, shop catalog, limits, prerequisites, claim state, and end-of-event behavior. Offline preview may be shown but cannot grant verified online event results or global leaderboard placement.

### 13.9 Economy ledger and backend data
Recommended entities:
- `currency_catalog`
- `player_currency_balances`
- `currency_ledger` (immutable credits/debits, source, reason, timestamp, transaction ID, idempotency key)
- `topup_products`
- `purchase_transactions`
- `prime_progress` (qualifying total, level, program version)
- `prime_reward_claims`
- `store_catalog`
- `store_purchases`
- `events`, `event_missions`, `event_token_ledger`, `event_shop_items`, `event_reward_claims`

All currency-changing operations must be transactional and idempotent. Balance must reconcile to ledger entries. Client cannot set its own balance, Prime tier, purchase status, or reward eligibility.

### 13.10 Economy metrics
Track privacy-conscious aggregated data:
- Top-up catalog views, checkout starts/completions/failures.
- Receipt verification latency/failures and duplicate attempts.
- Currency earned/spent by source/sink.
- Prime tier distribution and progression.
- Event participation, token earn/spend, unclaimed/expired tokens.
- Store item conversion and purchase failures.
- Refunds/chargebacks and suspicious transaction patterns.
- Premium/soft currency balances and economy inflation.

### 13.11 Economy admin tools
- Configure product catalog, bundle amounts/bonus, regional products, campaign dates, and eligibility.
- Configure Prime thresholds/rewards with versioning and audit history.
- Configure Gold Store, Eclipse Store, events, missions, and token exchange.
- Investigate transactions and process audited compensation/revocation.
- View economy metrics and suspicious transaction alerts.
- Never allow an unlogged admin currency grant or tier change.

## 14. Social, Friends, Party, Clan, Chat, and Custom Rooms

### Friends
- Search by UID, send/accept/reject/cancel requests, remove, block, report, online status and privacy controls, recent teammates, request limits.

### Party and squad
- Solo/Duo/Squad party, leader/transfer, invite/join/leave/kick permissions, privacy modes, mode/region compatibility, ready states, disconnect/reconnect, and ranked party restrictions.

### Clan/Guild
- Create/join/leave, name/tag/emblem/description, owner/leader/officer/member roles, invitations/applications, clan missions/rewards, leaderboard, rename/delete/inactivity policies.

### Chat
- Direct messages, party/squad/clan chat, quick tactical messages, optional voice chat, filtering, rate limits, mute/block/report, retention policy, moderation, and abuse review.

### Custom rooms
- Room creation/join, unique room code, mode/capacity, access/password rules, host controls, kick/lock, spectator permissions, party/team synchronization, and offline Bot room support.
- Local-only room codes must never be presented as remotely joinable online rooms.

## 15. Audio, Music, VFX, and Environment Sound

### Audio buses
- Master, Music, SFX, Weapons, Environment, UI, Voice Chat.

### Content
- Lobby/menu music, character preview themes, event themes.
- Weapon firing/reload/empty-mag/switch sounds.
- Bullet impacts by surface, explosions, grenade bounce, hit/kill confirmation.
- Footsteps by surface and distance.
- Indoor/outdoor gunshot differences and sound occlusion.
- Wind, birds, forest, water, room ambience, weather sounds if supported.
- Vehicle sounds only if vehicles are implemented.
- Muzzle flash, bullet impacts, explosions, zone effects, hit reactions, UI feedback.

### Audio requirements
- Adjustable volumes and mute controls.
- 3D distance attenuation and directionality.
- Indoor occlusion/reverb where performance allows.
- Audio voice limits and priority.
- Pause/background/resume behavior on Android.
- Licensed or original audio only; no unauthorized copyrighted music.
- Audio cues must be consistent with gameplay distance and direction.

## 16. Settings, Accessibility, and Quality of Life

### Graphics
- Device-appropriate Low/Medium/High presets.
- Resolution scale, FPS cap, shadows, textures, effects/particles, anti-aliasing, render distance, frame pacing, battery/performance mode.
- Unsupported options hidden or disabled.
- Thermal/memory pressure fallback and LODs.

### Controls
- Camera/ADS/scope sensitivity, gyroscope if implemented, aim-assist constraints, remappable/custom layout, auto-pickup, auto-reload, vibration, invert Y, FOV/camera distance if supported, reset defaults.

### Accessibility
- Text/UI scaling, readable fonts, colorblind-friendly indicators, subtitles/sound-event indicators where suitable, adjustable button size, reduced screen shake/flash intensity where fair, vibration off, language selection.

### QoL
- Download/resource progress, clear error messages, reconnect, match history, reward summary, inventory comparison, favorite loadouts, confirmation on destructive actions, network status, settings reset, tutorial replay, help/FAQ, support link, report issue, account deletion/privacy controls, explicit offline/online status.

## 17. Offline Architecture and Rules

### Offline features
- Startup and local profile.
- Main menu and character preview.
- Training Ground.
- Offline BR/Classic Bot matches.
- Offline Lone Wolf Bot duel.
- Movement, weapons, recoil, grenades, inventory, loot, health, armor, safe zone, results.
- Local settings and control layouts.
- Local match history and approved practice progression.

### Architecture
Local Profile/Save → Offline Mode Manager → Local Match Manager → Player Controller, Bot AI, World/Loot, Combat/Zone → Local Results → Local Save.

### Offline data restrictions
- No real-money payment success simulated as real.
- No verified Eclipse Gems or online purchase entitlement minted offline.
- No global Prime progression from unverified local data.
- No global ranked or event leaderboard changes.
- Local soft currency must remain clearly local unless a documented exploit-resistant sync policy exists.
- Airplane mode must not block offline gameplay.

### Offline acceptance tests
1. Startup in airplane mode.
2. Start/restart Training Ground.
3. Complete a Bot match.
4. Background/foreground during a match.
5. Force-close and reopen.
6. Missing/corrupt save recovery.
7. Low storage behavior.
8. Change settings without internet.
9. Return from Offline to Online.
10. Confirm local results do not modify global rank, purchases, Prime, or event leaderboard.

## 18. Online Multiplayer and Backend Architecture

Online phase requires:
- Authentication/account linking/recovery.
- Player profile and UID.
- Friends/party/social services.
- Matchmaking and region selection.
- Authoritative match server for real-time combat and results.
- Inventory/cosmetic entitlements.
- Rank/seasons/leaderboards.
- Missions/events/rewards.
- Shop/top-up and purchase verification.
- Match history/results.
- Chat/report/moderation.
- Notifications/support.
- Analytics/monitoring/admin APIs.

### Networking
- Server-authoritative damage/ammo/result.
- Client prediction/reconciliation where needed.
- State interpolation, snapshot replication, network tick/bandwidth budget.
- Lag compensation only after design and security review.
- Reconnect/session recovery.
- Region matchmaking, capacity limits, latency monitoring, crash handling.
- Network jitter and packet loss testing.

### Supabase/backend note
Supabase can be used for account/profile, catalog/configuration, persistence, and related APIs with strict RLS. It is not by itself an authoritative real-time shooter simulation server. A dedicated game-server architecture is needed for competitive real-time movement, combat, matchmaking, and server-verified results.

## 19. Database Blueprint

Logical entities to consider:
- `accounts`, `player_profiles`, `player_settings`, `player_inventory`, `item_catalog`, `player_currency`, `currency_ledger`.
- `matches`, `match_players`, validated `match_events`, `player_statistics`.
- `ranks`, `rank_history`, `seasons`.
- `missions`, `player_missions`, `rewards`, `reward_claims`.
- `friends`, `friend_requests`, `parties`, `party_members`, `clans`, `clan_members`.
- `chat_channels`, `messages`, `reports`.
- `purchases`, `entitlements`, `notifications`, `support_tickets`.
- `analytics_events`, `admin_audit_logs`.
- Economy entities listed in Section 13.

Database rules:
- Primary/foreign keys, unique constraints, indexes, migrations, RLS/access policies.
- Transactional currency changes and idempotency keys.
- Ledger reconciliation and immutable audit history.
- Data retention/deletion policies.
- Backup/restore testing.
- Separate development, staging, and production environments.
- Never trust client-submitted rank, currency, entitlement, result, damage, authoritative position, or admin privilege.

## 20. Security, Anti-Cheat, and Player Safety

- Server-authoritative ammo, fire rate, damage, hit claims, movement sanity, and match results.
- Detect impossible speed/position, suspicious hit-rate/aim patterns, duplicate rewards/currency, boosting, AFK abuse, and unusual purchase flows.
- Rate limits, authenticated sessions, secure token storage, receipt validation, admin least privilege, audit logs, incident response.
- Reports, block/mute, chat moderation, name validation, sanctions and appeals.
- Privacy policy, data minimization, data export/deletion workflows, age-appropriate safeguards and applicable laws/platform policies.
- No service-role key, billing secret, private signing key, or trusted admin credential in client source or repository.

## 21. Metrics and Analytics

### Gameplay metrics
- Match duration/completion, win rate, K/D, damage per match, headshot rate, weapon pick/win contribution, survival time, zone deaths, loot pickup, Bot stuck rate, FPS/frame time.

### Product metrics
- DAU/WAU/MAU, D1/D7/D30 retention, tutorial completion, drop-off, session length, queue wait/cancel rate, reconnect success, crash-free sessions, update/resource failures, support/report rate.

### Progression/economy metrics
- Currency earned/spent, item acquisition/consumption, mission completion, reward claim success, season progress, rank distribution/inflation, shop conversion/failure, refunds/chargebacks, Prime tier distribution, event token flow, suspicious duplication.

### Metrics pipeline
1. Client/server emits versioned events.
2. Validate schema and privacy constraints.
3. Online competitive events are validated server-side.
4. Ingestion stores only necessary data.
5. Dashboards show aggregates/trends.
6. Thresholds create operational alerts.
7. Team investigates and updates code/configuration.
8. Same metric is measured after the fix.

Offline play must not require an analytics endpoint. Local diagnostics can remain local and upload only under the documented privacy/consent policy.

## 22. Content Pipeline and Project Structure

### Content categories
- World/terrain/POIs/buildings/roads.
- Characters/rigs/animations/outfits/pets/emotes.
- Weapons/models/stats/recoil/sounds/icons.
- Loot/items/attachments/spawn tables.
- Cosmetics/store assets.
- Audio/music/ambience/voice.
- UI/icons/fonts/HUD.
- Missions/events/ranks/rewards/mode configs.
- VFX and localization strings.

### Suggested structure
```text
ShadowRoyale/
├── project.godot
├── scenes/ (boot, menus, lobby, gameplay, characters, weapons, loot, buildings, effects)
├── scripts/ (core, player, bots, combat, inventory, modes, world, ui, audio, save, networking, analytics)
├── data/ (weapons, items, modes, loot_tables, missions, ranks, balance, economy, events)
├── assets/ (characters, weapons, environment, animations, audio, textures, ui, vfx)
├── tests/ (unit, integration, gameplay, performance, security)
└── docs/ (MASTER_BLUEPRINT, GDD, TECHNICAL_BLUEPRINT, CONTENT_PIPELINE, QA_PLAN, RELEASE_PLAN)
```

This is a target structure; it does not mean every directory currently exists.

### Asset/content requirements
Each content record should have stable ID, display name/description, asset references, category/rarity, version/licensing metadata, gameplay stats if any, compatibility, thumbnail, localization keys, validation rules, fallback behavior, performance budget, and tests. Use data-driven definitions for items/weapons/modes/events rather than scattering values through code.

## 23. Admin Panel and Live Operations

Admin modules:
- Admin authentication/MFA and role-based permissions.
- Player search by UID and account status.
- Reports/moderation and sanctions.
- Match/result inspection.
- Mission/event/season configuration.
- Content catalog and store configuration.
- Audited reward grants/revocations and transaction investigation.
- News/notifications/maintenance notices.
- Server health, incident dashboard, analytics overview.
- Support tickets, audit logs, and admin action history.

Roles: Super Admin, Game Operations, Moderator, Support, Analyst, Developer/QA. Apply least privilege, audit trail, confirmations, and reversible workflows where possible.

## 24. QA, Performance, and Acceptance

### Test categories
- Unit: damage, recoil, loot weights, rank/economy formulas, inventory limits.
- Integration: pickup→inventory, match→result, reward→ledger, purchase→verified balance.
- Gameplay: all six modes, zone, weapons, Bots, buildings, cover, grenades, restarts.
- Android: touch controls, pause/resume, background/foreground, storage, thermal behavior, FPS.
- Online: multi-client, latency, packet loss, reconnect, server crash, authority checks.
- Security: unauthorized access, duplicate claims, purchase tampering, privilege escalation, result manipulation.
- Release: clean install, upgrade install, signing, versioning, rollback/hotfix.

### Initial performance targets (must be measured, not assumed)
- 30 FPS target on supported low-end devices.
- 60 FPS target on suitable mid/high-end devices.
- Stable frame pacing and controlled spikes.
- Memory/texture/shader budget.
- Load/scene transition budget.
- Network latency/bandwidth budget.
- Graceful reduction under thermal/memory pressure.

### QA checklist
- [ ] All six modes use intended rules.
- [ ] BR zone and victory logic work.
- [ ] Offline results never change online rank.
- [ ] Loot cannot grant twice.
- [ ] Player/Bots can navigate designated interiors.
- [ ] Bot stuck recovery works.
- [ ] Grenade collision/fuse/blast behavior verified.
- [ ] Weapon ammo/reload/recoil consistent.
- [ ] Animation and hitbox alignment checked.
- [ ] Profile/settings save and reload.
- [ ] Offline airplane-mode test passes.
- [ ] Corrupt/missing save recovery tested.
- [ ] Online reconnect/server errors tested.
- [ ] Duplicate reward/purchase claims prevented.
- [ ] UI overflow/touch/accessibility tested.
- [ ] Crash/performance logs reviewed.
- [ ] Android clean install and upgrade tested.
- [ ] Privacy, deletion, support, and release compliance reviewed.

## 25. Build, CI/CD, and Release

Pipeline:
1. Commit/change in source control.
2. Static audit/lint.
3. Automated tests.
4. Godot headless validation where supported.
5. Android export/build.
6. APK/AAB artifact generation.
7. Artifact integrity and version verification.
8. Install on QA devices.
9. Offline/online smoke and functional tests.
10. Release approval and staged rollout.

Channels: Development, Internal QA, Closed Test, Open Test if needed, Production, Emergency Hotfix.

- APK is useful for direct install QA; AAB is used for Google Play distribution if selected.
- Protect signing keys in secure secrets; never commit them.
- Keep version, commit, build logs, known issues, and release notes.
- A successful CI build does not prove gameplay is correct; runtime/device QA remains required.

## 26. Production Roadmap and Exit Criteria

### Phase 0 — Master specification
Complete this document, screen flows, mode rules, map plan, content catalog, schema, acceptance criteria, and test plan.
**Exit:** Every feature has scope, dependency, owning module, status, and test criteria.

### Phase 1 — Core architecture
Scene/state management, local save, content definitions, input, logging, configuration, test harness.
**Exit:** Startup, save/load, scene transitions, configuration loading are stable.

### Phase 2 — Full playable map
Terrain, POIs, buildings/interiors, roads, collision, loot anchors, cover, navigation, boundaries.
**Exit:** Movement, collision, spawn, loot, and navigation tests pass across target areas.

### Phase 3 — Combat and characters
Rig/animations, movement, weapons, attachments, recoil, reload, grenades, inventory, healing/armor, combat feedback.
**Exit:** Weapon/utility acceptance and regression tests pass.

### Phase 4 — Offline AI and modes
NavigationAgent-based AI, indoor movement, tactics, Training Ground, Lone Wolf, Classic, offline BR and results.
**Exit:** Every offline mode can be completed, results generated, local progress saved.

### Phase 5 — UI/profile/progression
Lobby, mode selection, HUD, profile, inventory, rank UI, achievements, missions, audio, settings, accessibility.
**Exit:** Every visible implemented control is connected to a real system and usability tests pass.

### Phase 6 — Backend and online services
Auth, database, profile sync, matchmaking, authoritative servers, social, ranked, rewards, admin APIs.
**Exit:** Multi-client, authority, reconnect, security, and result consistency tests pass.

### Phase 7 — Content/audio/analytics
Final content, VFX, sound, events, economy, analytics dashboards, telemetry, operations tools.
**Exit:** Content/audio validation and metrics correctness verified.

### Phase 8 — QA and optimization
Functional, security, load, network, performance, device compatibility, recovery, regression.
**Exit:** No release-blocking issues; target performance achieved; release checklist approved.

### Phase 9 — Release and live operations
Signed builds, test tracks, rollout monitoring, incident response, patching, balance updates, season operations.
**Exit:** Release artifacts verified, rollout monitored, rollback/hotfix process ready.

## 27. Master Feature Register

Use this register as a summary. Detailed requirements are in the sections above.

### A. Core game
- [ ] Architecture, scenes, game states.
- [ ] Lobby and mode selection.
- [ ] One large connected island map.
- [ ] Six modes with real rules and result handling.
- [ ] Offline save/load and state management.
- [ ] Loading, pause, restart, and results.

### B. World
- [ ] All planned POIs and accessible interiors.
- [ ] Roads, terrain, bridges, buildings, collision.
- [ ] Loot anchors, cover, minimap, zone.
- [ ] Lighting, ambience, LOD/occlusion and performance.

### C. Character/combat
- [ ] Rigged 3D characters and animation states.
- [ ] Movement, jump, sprint, crouch and designed traversal.
- [ ] Weapon catalog, attachments, recoil, ADS, reload.
- [ ] Grenades, healing, armor, inventory, damage/death.
- [ ] Sound/VFX and combat feedback.

### D. AI/modes
- [ ] Indoor/outdoor NavigationAgent/pathfinding.
- [ ] Bot perception, tactics, cover, difficulty.
- [ ] Training targets and all offline mode loops.
- [ ] Correct scoring, victory, timeout and results.

### E. UI/progression
- [ ] HUD and custom touch controls.
- [ ] Profile, UID, statistics, rank, XP, season.
- [ ] Missions, achievements, events, rewards.
- [ ] Stores, inventory, cosmetics, settings, accessibility.

### F. Social/online
- [ ] Auth, profile sync, friends, party, clan, chat.
- [ ] Matchmaking, authoritative servers, reconnect.
- [ ] Online ranked, verified history, reports/moderation.

### G. Economy/Prime
- [ ] Eclipse Gems Top-Up with verified platform billing.
- [ ] Shadow Prime I–VIII; Prime VIII at 200,000 qualifying top-up Gems and remains VIII above that.
- [ ] Royale Gold and Gold Store.
- [ ] Rift Tokens and event exchange.
- [ ] Ledger, idempotency, refunds, purchase reconciliation.
- [ ] Economy analytics and audited admin controls.
- [ ] Offline cannot mint verified premium currency or Prime progress.

### H. Operations/security
- [ ] Backend schema, RLS, migrations, backups.
- [ ] Admin roles, audit logs, event/catalog tools.
- [ ] Anti-cheat, abuse reporting, privacy/deletion.
- [ ] Metrics, monitoring, alerting, incident response.

### I. QA/release
- [ ] Unit/integration/regression tests.
- [ ] Offline and Android device tests.
- [ ] Online security/load/network tests.
- [ ] Performance/thermal/memory profiling.
- [ ] Signed APK/AAB, CI/CD, staged release, rollback.

## 28. Current Project Status and Important Limitations

The repository has contained a Flutter client/UI prototype and a separate Godot 3D offline prototype, with basic movement/combat, Bots, loot, POI/building shells, road generation, HUD feedback, and documentation. Exact current implementation must be re-audited against the current repository before future claims.

Previous development environment did not have Godot/Flutter/Dart runtime toolchains available, so runtime playtesting, `flutter analyze`, and Android APK validation could not be assumed. Source audits and ZIP integrity checks are not substitutes for runtime QA. Do not claim that the complete game, all six modes, full indoor navigation, verified billing, online multiplayer, or release-ready APK exists until the relevant work is implemented and tested.

## 29. Working Rules for Future Development

1. Read this Master Blueprint before making scope decisions.
2. Inspect the actual repository and identify the relevant unfinished sections.
3. Work on a coherent feature slice: code, UI, data, assets, tests, and docs together.
4. Update this document or the feature register when a decision changes.
5. Run available audits/tests and report exact results.
6. Do not mark runtime/device behavior verified without actual runtime/device evidence.
7. Keep Offline and Online data/security boundaries explicit.
8. Preserve the fixed Shadow Prime rule: 200,000 qualifying Eclipse Gems reaches Prime VIII; any qualifying total above 200,000 remains Prime VIII.
9. Deliver updated source/project files when requested and verify archive integrity before sharing.
10. If a new request conflicts with this document, document the change and update the source of truth instead of silently creating contradictory rules.

---

**End of Master Blueprint**
