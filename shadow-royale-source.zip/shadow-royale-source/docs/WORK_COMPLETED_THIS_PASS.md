# Work completed this pass — 2026-10-25

## Ranked progression hardening
- Added `supabase/migrations/003_ranked_match_settlement.sql` with one trusted settlement function for `cs_ranked` and `br_ranked` results.
- Settlement computes point changes inside SQL from the submitted trusted result facts, updates the profile and inserts the match result in the same transaction.
- Added advisory transaction locking and existing unique-key checks to prevent duplicate match/user awards.
- Revoked function execution from `public`, `anon`, and `authenticated`; granted execution only to `service_role`. Keep that key only on a trusted backend.
- Added progress-to-next-star and progress-to-next-tier values to the Godot rank calculator.
- Updated ranked design and master checklist with implementation and remaining live integration gates.
- Static source audit: 130 PASS, 0 FAIL.

## Explicit limitations
- The SQL migration was not applied to a live Supabase database or executed against PostgreSQL here.
- Godot runtime is unavailable in this environment; no engine parse/play test was run.
- The current dedicated server is still an online movement/combat test slice. It does not yet run a full last-team-standing BR lifecycle or round-based CS lifecycle and does not yet call the settlement function at match end. Therefore ranked awards are not live/production-ready.
- Real matchmaking, party membership, results UI, season lifecycle, leaderboards, Android device testing and 50-client load tests remain incomplete.

## Full-project audit follow-up — 2026-10-25
- Replaced the lobby's misleading hard-coded `IRON III` label with `UNRANKED` until online rank sync is available.
- Added `lib/ranked_progression.dart` with testable CS-style star and BR tier/point calculations, including placement, capped kill/survival bonuses, and top-tier rating behavior.
- Added `lib/ranked_page.dart` and routed the Rank navigation to it. The screen explicitly says global rank is not live, separates CS-style and BR tracks, and displays BR thresholds.
- Added `test/ranked_progression_test.dart` covering point bands, caps, rank thresholds, and totals above top-tier thresholds.
- Hardened `003_ranked_match_settlement.sql`: null mode/result payloads are rejected and duplicate user IDs in one submitted batch are rejected before any awards are applied.
- Expanded static source audit from 130 to 137 checks.

### Verification boundary
- Static audit is not a Dart compiler or runtime test. Flutter, Dart, Godot, and PostgreSQL command-line tools are not installed in this environment, so their test/analyze/parse/database execution could not be performed here.
- Ranked UI intentionally remains a preview until a trusted match backend supplies real profile ratings and the live match lifecycle invokes settlement.

## Offline-only / online maintenance pass — 2026-10-25
- Removed the online mode toggle from the main lobby and made offline play the only active route.
- Added a prominent online multiplayer maintenance notice.
- Marked BR Ranked and Classic Ranked as temporarily unavailable; selecting them cannot start a match and gives a maintenance message. Their global rank features remain inactive.
- Kept offline Battle Royale, Classic, Lone Wolf and Training Ground available.
- Corrected pause/resume so pausing the offline arena does not accidentally count as a completed match.
- Added offline lobby widget tests and 7 additional source-audit checks.
- Static source audit: 144 PASS / 0 FAIL. Flutter tests, analyzer, APK build and real-device playtest remain unrun because Flutter/Dart SDKs are not installed in this environment.
