# Shadow Royale — Godot 4 3D Engine Starter

This folder is a separate Godot 4 project intended to replace the earlier 2D-only arena as the foundation for a 3D client. It procedurally generates its environment and requires no imported art assets.

## Included prototype systems
- Godot 4 3D project configuration and main scene
- Procedural ground, cover blocks, trees, lighting and a shrinking safe-zone visual
- Four original named landmark clusters with collision-backed structures and sign labels
- Center crosshair and combat feedback labels
- Third-person player controller and camera
- Basic rifle raycast firing, ammo/reload, health, armor and medkits
- Eight simple AI bots that approach/strafe, check line of sight and attack
- Ammo, medkit and armor pickups
- On-screen HUD buttons for fire, reload, heal and jump
- Match timer, remaining bots, win/lose panel and restart
- Offline mode selector for Solo Battle Royale, Training Ground and Bot Deathmatch; selected mode persists and can be changed from the pause menu
- Training target dummies with health feedback and automatic reset
- Bot Deathmatch prototype with a 20-kill target and player respawn
- Offline Squad Battle Royale prototype with three AI teammates, downed state, bleed-out timer, and 4-second close-range revive action

## Run
1. Install Godot 4.3 or newer on a computer.
2. Open `project.godot` with Godot Project Manager.
3. Press F6/F5 to run the project.

## Important limits
This is a playable 3D starter prototype, not a finished commercial battle royale. It does not yet include production-quality art, character animation, vehicles, parachuting, network play, account services, anti-cheat, voice chat, ranked matchmaking or cloud saves. Android export needs Godot export templates and Android SDK/JDK configured. Training Ground and Bot Deathmatch are prototype implementations and still need gameplay balancing. This project has not been compiled or run in this environment; verify it in Godot before treating it as build-ready.


## Current prototype notes

Bots have lightweight steering, simple obstacle probing, variable attack timing, and basic shrinking-zone awareness. This is not full navigation-mesh pathfinding; test and tune in Godot before treating it as release-ready. HUD touch gestures use unhandled input so visible buttons can consume their own touches.


### Combat feedback update
- Headshot bonus is determined from the actual raycast hit position, not automatically granted to every sniper hit.
- Training targets show a short hit-color change and headshot text feedback.
- These changes are source-level only until tested in Godot 4.


## Latest combat prototype additions
- Six-ray shotgun spread, basic headshot multipliers, hit/damage feedback, and a compact elimination feed.
- Training Ground does not spawn loot and focuses on resettable targets.
- These are source-level changes; run in Godot 4.3 to validate the parser, physics, and balance.


### Recent AI and HUD stability pass
- TDM score stays in the status HUD instead of overwriting temporary messages every frame.
- Bots get unique names and randomized respawn positions; respawns avoid placing a bot too close to the player where possible.
- Bot movement includes a trapped-state timer that changes its sidestep fallback. These are prototype heuristics and need in-engine playtesting.


### Arena navigation visuals
The prototype now creates a procedural asphalt road cross, short POI approach roads, shoulder strips, and dashed centre markings. These are visual-only mesh strips intended as lightweight navigation cues; inspect placement in Godot before treating the map as final.

### Enterable POI buildings

The four procedural POIs now use small room shells assembled from separate wall segments. Front walls have doorway gaps, with a roof and floor slab; wall segments carry collision so the player can walk into the structures. These are simple prototype interiors, not furnished buildings, and still need Godot runtime verification.


### Loot feedback
Loot pickups display world-space labels (AMMO, MEDKIT, ARMOR, WEAPON), guard against duplicate collection callbacks, and notify the HUD when collected. Runtime behavior must still be verified in Godot 4.3.

### Interior loot, cover and combat feedback
Loot placement prioritizes the interiors of the generated POI buildings. Low crates provide collision-backed cover without closing the doorway. The client prototype now includes procedural player arm/weapon meshes, movement bob/lean, per-weapon firing recoil, and a two-grenade supply with timed radial damage and cover/line-of-sight checks. Bots use multi-distance obstacle probes and basic procedural movement feedback. These are lightweight procedural approximations; authored character rigs, real animation clips, and baked navigation remain future work.


### Squad revive prototype
Choose **SQUAD BATTLE ROYALE** in the mode selector. Three green AI squadmates follow the player. Enemy bots can knock them down; approach within 2.8 metres and press **REVIVE**, then remain nearby for four seconds. A teammate bleeds out after 35 seconds and returns with 45 HP after a successful revive. This is an offline AI prototype only; no network synchronization exists. Godot runtime validation remains required.
