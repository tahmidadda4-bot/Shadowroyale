# Shadow Royale — Engine status and remaining work

## Current prototype features (not yet runtime-verified)
- Godot 4 procedural 3D arena, ground, cover props and stylized trees
- Third-person player body/camera and keyboard movement
- Touch movement input on the left half of the screen and touch-look drag on the right half
- Mobile FIRE, RELOAD, HEAL, JUMP, WEAPON, SPRINT, CROUCH and PAUSE buttons
- Camera-relative movement and HUD-to-player touch-control wiring
- Basic pause panel with resume/restart/quit actions; HUD remains active while paused
- HUD weapon, medkit and reload-state readouts
- Five prototype weapon profiles: assault rifle, shotgun, sniper, SMG and pistol (different magazine sizes, ranges, fire rates and damage)
- Hitscan damage, simple armor/health, medkits and reserve ammo
- Eight basic bots with approach/strafe movement, line-of-sight checks and attack cooldowns
- Physical proximity pickups for ammo, medkits and armor
- Shrinking safe-zone damage, HUD status, victory/elimination result and restart

## Still required before calling the client complete
- Run the project in the target Godot version, fix all parse/runtime errors and test on Android hardware
- Original optimized 3D characters, weapons, map assets, animations, audio and VFX
- Large designed maps with buildings/interiors, navigation meshes, terrain, roads and multiple POIs
- Plane/drop phase, parachute, full match spawn/loot tables, supply drops and spectating
- Weapon recoil/spread, attachments/scopes, projectile validation, melee/grenades, head/body hitboxes, hit reactions and kill feed
- Bot cover navigation, looting, zone rotation, difficulty levels and squad behavior
- Vehicle driving, damage and fuel if included in scope
- Character selection, skins, pets, animated emotes, inventory, missions, rank/season, event and shop integration with the actual match loop
- Full responsive safe-area layout, configurable touch zones, sensitivity/ADS/gyro and accessibility settings
- Profiling, memory/thermal/battery checks, automated tests, Android export presets and a verified APK

## Backend deliberately deferred
Real online matchmaking, player synchronization, remote custom rooms, friend/team services, authoritative combat, global ranking, cloud saves, chat/voice, live events, payment verification and server-side anti-cheat all require backend services.

A feature is not marked complete merely because a UI placeholder exists. This project is a development foundation, not a launch-ready commercial battle royale.


## Latest prototype pass — 2026-10-24
- Bot obstacle probes now try both lateral directions before falling back, reducing repeated movement into cover.
- Low-health bots attempt a lateral retreat when their line of sight to the player is blocked. This is a heuristic prototype, not navigation-mesh pathfinding, and requires Godot runtime validation.
