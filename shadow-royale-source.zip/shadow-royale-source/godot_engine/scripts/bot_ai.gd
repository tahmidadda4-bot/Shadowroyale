extends CharacterBody3D

signal died(bot)

var target_player: Node3D
var game
var zone_radius := 58.0
var health := 100.0
var is_dead := false
var speed := 3.2
var preferred_range := 8.0
var decision_timer := 0.0
var current_move := Vector3.ZERO
var attack_timer := 0.0
var strafe_timer := 0.0
var strafe_sign := 1.0
var cover_check_timer := 0.0
var is_seeking_cover := false
var blocked_timer := 0.0
var body_mesh: MeshInstance3D
var rng := RandomNumberGenerator.new()
var animation_clock := 0.0

func _ready() -> void:
    rng.randomize()
    speed = rng.randf_range(2.8, 3.8)
    preferred_range = rng.randf_range(6.5, 11.0)
    add_to_group("bots")
    var cs = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.radius = 0.4
    shape.height = 1.7
    cs.shape = shape
    cs.position.y = 0.85
    add_child(cs)
    body_mesh = MeshInstance3D.new()
    var mesh = CapsuleMesh.new()
    mesh.radius = 0.4
    mesh.height = 1.7
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.85
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.85, 0.23, 0.18)
    body_mesh.material_override = mat
    add_child(body_mesh)

func _physics_process(delta: float) -> void:
    if is_dead or get_tree().paused or not is_instance_valid(target_player):
        return
    var combat_target: Node3D = _nearest_combat_target()
    if not is_instance_valid(combat_target):
        combat_target = target_player
    animation_clock += delta
    attack_timer -= delta
    strafe_timer -= delta
    decision_timer -= delta
    cover_check_timer -= delta
    if cover_check_timer <= 0.0:
        cover_check_timer = rng.randf_range(0.45, 0.8)
        is_seeking_cover = health < 48.0 and not _has_line_of_sight()
    if strafe_timer <= 0.0:
        strafe_timer = rng.randf_range(1.0, 2.4)
        strafe_sign = -strafe_sign
    if decision_timer <= 0.0:
        decision_timer = rng.randf_range(0.35, 0.8)
        current_move = _choose_move()

    var to_player = combat_target.global_position - global_position
    var distance = Vector2(to_player.x, to_player.z).length()
    var outside_zone = Vector2(global_position.x, global_position.z).length() > zone_radius - 2.0
    var move_dir = current_move
    if outside_zone:
        move_dir = Vector3(-global_position.x, 0.0, -global_position.z).normalized()
    elif is_seeking_cover:
        # Low-health bots break line of sight and move laterally instead of charging.
        var away := Vector3(-to_player.x, 0.0, -to_player.z).normalized()
        var lateral := Vector3(-away.z, 0.0, away.x) * strafe_sign
        move_dir = (away * 0.7 + lateral * 0.9).normalized()
    elif distance > preferred_range:
        move_dir = Vector3(to_player.x, 0.0, to_player.z).normalized()
    else:
        var toward = Vector3(to_player.x, 0.0, to_player.z).normalized()
        move_dir = Vector3(-toward.z, 0.0, toward.x) * strafe_sign

    # Multiple probes help bots navigate around cover and avoid getting stuck.
    if move_dir.length() > 0.1 and _movement_blocked(move_dir):
        blocked_timer += delta
        var left := Vector3(-move_dir.z, 0.0, move_dir.x) * strafe_sign
        var right := -left
        if not _movement_blocked(left):
            move_dir = left
        elif not _movement_blocked(right):
            move_dir = right
        else:
            # Change preferred sidestep when trapped instead of repeating the same direction.
            strafe_sign *= -1.0
            move_dir = Vector3(-to_player.x, 0.0, -to_player.z).normalized()
        if blocked_timer > 1.2:
            move_dir = Vector3(-move_dir.z, 0.0, move_dir.x) * -strafe_sign
            blocked_timer = 0.0
    else:
        blocked_timer = 0.0
    velocity.x = move_dir.normalized().x * speed
    velocity.z = move_dir.normalized().z * speed
    if to_player.length() > 0.1:
        look_at(Vector3(combat_target.global_position.x, global_position.y, combat_target.global_position.z), Vector3.UP)
    if not is_on_floor():
        velocity.y -= 22.0 * delta
    move_and_slide()
    if body_mesh:
        var moving := Vector2(velocity.x, velocity.z).length() > 0.35 and is_on_floor()
        body_mesh.position.y = 0.85 + (sin(animation_clock * 9.0) * 0.04 if moving else 0.0)
        body_mesh.rotation.z = lerpf(body_mesh.rotation.z, -move_dir.dot(global_transform.basis.x) * 0.07, delta * 5.0)

    if not is_seeking_cover and not outside_zone and distance < 19.0 and attack_timer <= 0.0 and _has_line_of_sight_to(combat_target):
        attack_timer = rng.randf_range(0.85, 1.5)
        # Slightly imperfect accuracy keeps offline bots challenging but not inhuman.
        if rng.randf() < 0.68:
            var damage = rng.randf_range(4.5, 8.5)
            if rng.randf() < 0.08:
                damage *= 1.5
            if combat_target.has_method("take_damage"):
                combat_target.take_damage(damage, "bot")

func _choose_move() -> Vector3:
    if not is_instance_valid(target_player):
        return Vector3.ZERO
    var offset = target_player.global_position - global_position
    var flat = Vector3(offset.x, 0.0, offset.z)
    if flat.length() < 0.1:
        return Vector3.ZERO
    var direction = flat.normalized()
    var lateral = Vector3(-direction.z, 0.0, direction.x) * strafe_sign
    if rng.randf() < 0.22:
        return lateral
    return (direction * rng.randf_range(0.25, 1.0) + lateral * rng.randf_range(-0.7, 0.7)).normalized()

func _movement_blocked(direction: Vector3) -> bool:
    var start = global_position + Vector3.UP * 0.8
    var ray_direction := direction.normalized()
    for distance in [0.9, 1.5, 2.1]:
        var query = PhysicsRayQueryParameters3D.create(start, start + ray_direction * distance)
        query.exclude = [self]
        var hit = get_world_3d().direct_space_state.intersect_ray(query)
        if not hit.is_empty() and hit.collider != target_player:
            return true
    return false

func _has_line_of_sight() -> bool:
    return _has_line_of_sight_to(target_player)

func _has_line_of_sight_to(target: Node3D) -> bool:
    if not is_instance_valid(target):
        return false
    var start = global_position + Vector3.UP
    var end = target.global_position + Vector3.UP
    var query = PhysicsRayQueryParameters3D.create(start, end)
    query.exclude = [self]
    var hit = get_world_3d().direct_space_state.intersect_ray(query)
    return hit.is_empty() or hit.collider == target

func _nearest_combat_target() -> Node3D:
    var chosen: Node3D = target_player
    if not is_instance_valid(target_player) or not game or not game.has_method("get_squadmates"):
        return chosen
    var best_distance := global_position.distance_to(target_player.global_position)
    for mate in game.squadmates:
        if not is_instance_valid(mate) or mate.is_downed or mate.is_eliminated:
            continue
        var distance := global_position.distance_to(mate.global_position)
        if distance < best_distance and distance < 24.0:
            chosen = mate
            best_distance = distance
    return chosen

func take_damage(amount: float, headshot := false) -> void:
    if is_dead:
        return
    health -= amount * (1.8 if headshot else 1.0)
    if health < 48.0:
        is_seeking_cover = true
    if health <= 0:
        is_dead = true
        died.emit(self)
        queue_free()
