extends CanvasLayer

var player
var game
var virtual_move := Vector2.ZERO
var virtual_look := Vector2.ZERO
var look_touch := -1
var look_last := Vector2.ZERO
var fire_held := false
var sprint_held := false
var crouch_held := false
var status_label: Label
var message_label: Label
var feedback_label: Label
var kill_feed_label: Label
var feedback_timer := 0.0
var crosshair_label: Label
var result_panel: PanelContainer
var pause_panel: PanelContainer
var mode_panel: PanelContainer
var joystick_origin := Vector2.ZERO
var joystick_touch := -1
var joystick_visual: Control

func _process(delta: float) -> void:
    if feedback_timer > 0.0:
        feedback_timer -= delta
        if feedback_timer <= 0.0 and feedback_label:
            feedback_label.text = ""

func _ready() -> void:
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    status_label = Label.new()
    status_label.position = Vector2(24, 20)
    status_label.add_theme_font_size_override("font_size", 22)
    status_label.add_theme_color_override("font_color", Color(0.7, 1.0, 0.85))
    root.add_child(status_label)
    message_label = Label.new()
    message_label.anchor_left = 0.5
    message_label.anchor_right = 0.5
    message_label.position = Vector2(-190, 28)
    message_label.size = Vector2(380, 40)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 19)
    root.add_child(message_label)
    feedback_label = Label.new()
    feedback_label.anchor_left = 0.5
    feedback_label.anchor_right = 0.5
    feedback_label.anchor_top = 0.5
    feedback_label.anchor_bottom = 0.5
    feedback_label.position = Vector2(-120, -62)
    feedback_label.size = Vector2(240, 42)
    feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    feedback_label.add_theme_font_size_override("font_size", 24)
    feedback_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.18))
    root.add_child(feedback_label)
    crosshair_label = Label.new()
    crosshair_label.anchor_left = 0.5
    crosshair_label.anchor_right = 0.5
    crosshair_label.anchor_top = 0.5
    crosshair_label.anchor_bottom = 0.5
    crosshair_label.position = Vector2(-10, -17)
    crosshair_label.size = Vector2(20, 34)
    crosshair_label.text = "+"
    crosshair_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair_label.add_theme_font_size_override("font_size", 28)
    crosshair_label.add_theme_color_override("font_color", Color(0.92, 1.0, 0.92, 0.9))
    crosshair_label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.85))
    crosshair_label.add_theme_constant_override("shadow_offset_x", 1)
    crosshair_label.add_theme_constant_override("shadow_offset_y", 1)
    root.add_child(crosshair_label)
    kill_feed_label = Label.new()
    kill_feed_label.anchor_left = 1.0
    kill_feed_label.anchor_right = 1.0
    kill_feed_label.position = Vector2(-300, 82)
    kill_feed_label.size = Vector2(280, 100)
    kill_feed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    kill_feed_label.add_theme_font_size_override("font_size", 16)
    kill_feed_label.add_theme_color_override("font_color", Color(1.0, 0.88, 0.65))
    root.add_child(kill_feed_label)
    _button(root, "FIRE", Vector2(-145, -145), Vector2(112, 82), Callable(self, "_fire"), Color(0.8,0.17,0.15), true)
    _button(root, "RELOAD", Vector2(-250, -85), Vector2(95, 50), Callable(self, "_reload"), Color(0.13,0.28,0.38), false)
    _button(root, "HEAL", Vector2(-145, -55), Vector2(95, 50), Callable(self, "_heal"), Color(0.12,0.42,0.25), false)
    _button(root, "REVIVE", Vector2(-265, -85), Vector2(95, 50), Callable(self, "_revive"), Color(0.1,0.52,0.42), false)
    _button(root, "GRENADE", Vector2(-145, -5), Vector2(105, 48), Callable(self, "_grenade"), Color(0.52,0.28,0.12), false)
    _button(root, "JUMP", Vector2(-265, -150), Vector2(95, 50), Callable(self, "_jump"), Color(0.24,0.28,0.38), false)
    _button(root, "WEAPON", Vector2(-265, -25), Vector2(95, 50), Callable(self, "_weapon"), Color(0.32,0.25,0.12), false)
    _button(root, "PICKUP INFO", Vector2(-385, -28), Vector2(110, 48), Callable(self, "_pickup_info"), Color(0.22,0.24,0.31), false)
    _button(root, "SPRINT", Vector2(-385, -145), Vector2(100, 48), Callable(self, "_noop"), Color(0.18,0.36,0.27), true, "sprint")
    _button(root, "CROUCH", Vector2(-385, -88), Vector2(100, 48), Callable(self, "_noop"), Color(0.26,0.28,0.35), true, "crouch")
    var help = Label.new()
    help.text = "LEFT: MOVE  •  DRAG RIGHT SIDE TO AIM  •  FIRE / RELOAD / HEAL / WEAPON"
    help.anchor_top = 1
    help.anchor_bottom = 1
    help.position = Vector2(22, -30)
    help.add_theme_color_override("font_color", Color(0.85,0.9,0.95,0.8))
    help.add_theme_font_size_override("font_size", 13)
    root.add_child(help)
    result_panel = PanelContainer.new()
    result_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    result_panel.position = Vector2(-180, -110)
    result_panel.size = Vector2(360, 220)
    result_panel.visible = false
    root.add_child(result_panel)
    _build_pause_panel(root)
    _build_mode_panel(root)
    _button(root, "PAUSE", Vector2(-112, -245), Vector2(90, 44), Callable(self, "_toggle_pause"), Color(0.22,0.25,0.32), false)

func _button(parent: Control, label_text: String, offset: Vector2, button_size: Vector2, action: Callable, color: Color, hold: bool, hold_kind := "fire") -> void:
    var b = Button.new()
    b.text = label_text
    b.size = button_size
    b.anchor_left = 1
    b.anchor_right = 1
    b.anchor_top = 1
    b.anchor_bottom = 1
    b.position = offset
    b.add_theme_font_size_override("font_size", 17)
    b.add_theme_color_override("font_color", Color.WHITE)
    var style = StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = 16
    style.corner_radius_top_right = 16
    style.corner_radius_bottom_left = 16
    style.corner_radius_bottom_right = 16
    b.add_theme_stylebox_override("normal", style)
    b.add_theme_stylebox_override("hover", style)
    parent.add_child(b)
    if hold:
        if hold_kind == "sprint":
            b.button_down.connect(func(): sprint_held = true)
            b.button_up.connect(func(): sprint_held = false)
        elif hold_kind == "crouch":
            b.button_down.connect(func(): crouch_held = true)
            b.button_up.connect(func(): crouch_held = false)
        else:
            b.button_down.connect(func(): fire_held = true)
            b.button_up.connect(func(): fire_held = false)
    else:
        b.pressed.connect(action)

func update_status(hp: float, armor: float, ammo: int, reserve: int, bots: int, seconds: int, zone: float, medkits: int = 0, weapon_name: String = "", reloading: bool = false, mode_name: String = "solo", score: int = 0, score_target: int = 20) -> void:
    if not status_label:
        return
    var reload_label := "  •  RELOADING" if reloading else ""
    var first_line := "HP %03d   ARMOR %03d   AMMO %02d/%03d%s" % [int(hp), int(armor), ammo, reserve, reload_label]
    var second_line := ""
    if mode_name == "training":
        second_line = "%s   MEDKIT %d   TARGET PRACTICE   TIME %02d:%02d" % [weapon_name, medkits, seconds / 60, seconds % 60]
    elif mode_name == "tdm":
        second_line = "%s   MEDKIT %d   KILLS %02d/%02d   TIME %02d:%02d" % [weapon_name, medkits, score, score_target, seconds / 60, seconds % 60]
    else:
        second_line = "%s   MEDKIT %d   BOTS %02d   TIME %02d:%02d   ZONE %dm" % [weapon_name, medkits, bots, seconds / 60, seconds % 60, int(zone)]
    status_label.text = first_line + "\n" + second_line

func show_message(value: String) -> void:
    if message_label:
        message_label.text = value

func show_hit_feedback(headshot: bool, damage: float) -> void:
    if feedback_label:
        feedback_timer = 0.65
        feedback_label.text = ("HEADSHOT  " if headshot else "HIT  ") + str(int(damage))
        feedback_label.add_theme_color_override("font_color", Color(1.0, 0.32, 0.18) if headshot else Color(1.0, 0.88, 0.25))

func show_damage_feedback(amount: float) -> void:
    if feedback_label:
        feedback_timer = 0.65
        feedback_label.text = "-%d HP" % int(ceil(amount))
        feedback_label.add_theme_color_override("font_color", Color(1.0, 0.25, 0.25))

func show_kill_feed(text_value: String) -> void:
    if not kill_feed_label:
        return
    var lines := kill_feed_label.text.split("\n", false)
    lines.push_front(text_value)
    while lines.size() > 4:
        lines.pop_back()
    kill_feed_label.text = "\n".join(lines)

func show_result(won: bool, kills: int, seconds: int) -> void:
    result_panel.visible = true
    for child in result_panel.get_children():
        child.queue_free()
    var col = VBoxContainer.new()
    result_panel.add_child(col)
    var title = Label.new()
    title.text = "VICTORY" if won else "ELIMINATED"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 28)
    col.add_child(title)
    var stats = Label.new()
    var profile = game.profile if game else {"matches": 0, "wins": 0, "kills": 0}
    stats.text = "KILLS: %d\nSURVIVED: %02d:%02d\nLOCAL CAREER: %d MATCHES • %d WINS • %d KILLS" % [kills, seconds / 60, seconds % 60, int(profile["matches"]), int(profile["wins"]), int(profile["kills"])]
    stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(stats)
    var retry = Button.new()
    retry.text = "PLAY AGAIN"
    retry.pressed.connect(func(): game.restart_match())
    col.add_child(retry)


func _build_mode_panel(root: Control) -> void:
    mode_panel = PanelContainer.new()
    mode_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    mode_panel.position = Vector2(-200, -160)
    mode_panel.size = Vector2(400, 320)
    mode_panel.visible = false
    root.add_child(mode_panel)
    var col = VBoxContainer.new()
    mode_panel.add_child(col)
    var title = Label.new()
    title.text = "SELECT OFFLINE MODE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 23)
    col.add_child(title)
    var note = Label.new()
    note.text = "Choose a local mode to start a fresh match."
    note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(note)
    var solo = Button.new()
    solo.text = "SOLO BATTLE ROYALE • 8 BOTS"
    solo.pressed.connect(func(): _select_mode("solo"))
    col.add_child(solo)
    var training = Button.new()
    training.text = "TRAINING GROUND • TARGET PRACTICE"
    training.pressed.connect(func(): _select_mode("training"))
    col.add_child(training)
    var squad = Button.new()
    squad.text = "SQUAD BATTLE ROYALE • 3 AI TEAMMATES"
    squad.pressed.connect(func(): _select_mode("squad"))
    col.add_child(squad)
    var tdm = Button.new()
    tdm.text = "BOT DEATHMATCH • FIRST TO 20"
    tdm.pressed.connect(func(): _select_mode("tdm"))
    col.add_child(tdm)
    var cancel = Button.new()
    cancel.text = "CANCEL"
    cancel.pressed.connect(func(): _close_mode_selector())
    col.add_child(cancel)

func show_mode_selector() -> void:
    if mode_panel:
        mode_panel.visible = true
        get_tree().paused = true

func _select_mode(mode: String) -> void:
    if game:
        game.set_game_mode(mode)

func _close_mode_selector() -> void:
    if mode_panel:
        mode_panel.visible = false
    get_tree().paused = false

func _build_pause_panel(root: Control) -> void:
    pause_panel = PanelContainer.new()
    pause_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    pause_panel.position = Vector2(-150, -125)
    pause_panel.size = Vector2(300, 250)
    pause_panel.visible = false
    root.add_child(pause_panel)
    var col = VBoxContainer.new()
    pause_panel.add_child(col)
    var title = Label.new()
    title.text = "MATCH PAUSED"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 24)
    col.add_child(title)
    var resume = Button.new()
    resume.text = "RESUME"
    resume.pressed.connect(_resume_game)
    col.add_child(resume)
    var restart = Button.new()
    restart.text = "RESTART MATCH"
    restart.pressed.connect(func(): game.restart_match())
    col.add_child(restart)
    var change_mode = Button.new()
    change_mode.text = "CHANGE GAME MODE"
    change_mode.pressed.connect(func(): game.open_mode_selector())
    col.add_child(change_mode)
    var quit = Button.new()
    quit.text = "QUIT GAME"
    quit.pressed.connect(func(): get_tree().quit())
    col.add_child(quit)

func _toggle_pause() -> void:
    if not game or game.match_over:
        return
    var should_pause = not get_tree().paused
    get_tree().paused = should_pause
    pause_panel.visible = should_pause

func _resume_game() -> void:
    pause_panel.visible = false
    get_tree().paused = false

func _fire() -> void:
    if player: player.fire()

func _reload() -> void:
    if player: player.reload_weapon()

func _heal() -> void:
    if player: player.heal()

func _revive() -> void:
    if game and game.has_method("start_revive_nearest"):
        game.start_revive_nearest()

func _grenade() -> void:
    if player and player.has_method("throw_grenade"):
        player.throw_grenade()

func _jump() -> void:
    if player and player.is_on_floor():
        player.velocity.y = 7.5

func _unhandled_input(event: InputEvent) -> void:
    var viewport_size = get_viewport().get_visible_rect().size
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x < viewport_size.x * 0.48:
            joystick_touch = event.index
            joystick_origin = event.position
            virtual_move = Vector2.ZERO
        elif event.pressed and event.position.x >= viewport_size.x * 0.48:
            look_touch = event.index
            look_last = event.position
            virtual_look = Vector2.ZERO
        elif not event.pressed and event.index == joystick_touch:
            joystick_touch = -1
            virtual_move = Vector2.ZERO
        elif not event.pressed and event.index == look_touch:
            look_touch = -1
            virtual_look = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        virtual_move = ((event.position - joystick_origin) / 85.0).limit_length(1.0)
    elif event is InputEventScreenDrag and event.index == look_touch:
        var delta_pos = event.position - look_last
        virtual_look = delta_pos
        look_last = event.position

func _weapon() -> void:
    if player:
        player.cycle_weapon()
        show_message("WEAPON: " + player.weapon_names[player.weapon_index])

func _pickup_info() -> void:
    show_message("Walk over glowing loot: ammo, medkit, armor")

func _noop() -> void:
    pass
