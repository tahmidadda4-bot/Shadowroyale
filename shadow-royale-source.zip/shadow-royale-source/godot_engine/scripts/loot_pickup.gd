extends Area3D

var kind := "ammo"
var spin := 0.0
var bob_time := 0.0
var base_y := 0.45
var pickup_label: Label3D
var collected := false

func _ready() -> void:
    base_y = position.y
    monitoring = true
    monitorable = true
    collision_layer = 0
    collision_mask = 1
    var mesh = MeshInstance3D.new()
    var box = BoxMesh.new()
    box.size = Vector3(0.65, 0.65, 0.65)
    mesh.mesh = box
    var mat = StandardMaterial3D.new()
    match kind:
        "ammo": mat.albedo_color = Color(1.0, 0.72, 0.12)
        "medkit": mat.albedo_color = Color(0.15, 0.95, 0.42)
        "armor": mat.albedo_color = Color(0.1, 0.72, 1.0)
        "weapon": mat.albedo_color = Color(0.92, 0.25, 0.95)
    mat.emission_enabled = true
    mat.emission = mat.albedo_color * 0.25
    mesh.material_override = mat
    add_child(mesh)
    # A small world-space label makes loot type readable on mobile without opening a menu.
    pickup_label = Label3D.new()
    pickup_label.position = Vector3(0.0, 0.72, 0.0)
    pickup_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    pickup_label.font_size = 32
    pickup_label.outline_size = 6
    pickup_label.modulate = mat.albedo_color
    pickup_label.text = _display_name(kind)
    add_child(pickup_label)
    var cs = CollisionShape3D.new()
    var sphere = SphereShape3D.new()
    sphere.radius = 1.35
    cs.shape = sphere
    add_child(cs)
    body_entered.connect(_on_body_entered)

func _display_name(value: String) -> String:
    match value:
        "ammo": return "AMMO"
        "medkit": return "MEDKIT"
        "armor": return "ARMOR"
        "weapon": return "WEAPON"
        _: return value.to_upper()

func _process(delta: float) -> void:
    if collected:
        return
    spin += delta
    bob_time += delta
    rotation.y = spin
    position.y = base_y + sin(bob_time * 2.2) * 0.12
    if has_overlapping_bodies():
        for body in get_overlapping_bodies():
            _on_body_entered(body)

func _on_body_entered(body: Node3D) -> void:
    if collected or not is_instance_valid(body):
        return
    if body.is_in_group("player"):
        collected = true
        # Disable the pickup immediately so overlapping callbacks cannot grant it twice.
        monitoring = false
        monitorable = false
        if body.has_method("collect"):
            body.collect(kind)
        queue_free()
