extends Node3D

const PlayerScript = preload("res://scripts/player_controller.gd")
const BotScript = preload("res://scripts/bot_ai.gd")
const PickupScript = preload("res://scripts/loot_pickup.gd")
const HudScript = preload("res://scripts/game_hud.gd")
const TargetScript = preload("res://scripts/training_target.gd")
const SquadmateScript = preload("res://scripts/squadmate.gd")

var player
var hud
var zone_radius := 58.0
var zone_timer := 0.0
var match_time := 0.0
var bots_alive := 8
var match_over := false
var bot_nodes: Array[Node] = []
var zone_mesh: MeshInstance3D
var loot_rng := RandomNumberGenerator.new()
var profile := {"matches": 0, "wins": 0, "kills": 0}
var game_mode := "solo"
var team_score := 0
var tdm_kill_target := 20
var player_respawn_timer := 0.0
var mode_selected := false
var bot_spawn_serial := 0
var squadmates: Array[Node] = []
var revive_target: Node = null
var revive_progress := 0.0
var revive_duration := 4.0
var revive_active := false

func _ready() -> void:
    randomize()
    loot_rng.randomize()
    _load_local_profile()
    _load_game_mode()
    _make_environment()
    _make_ground()
    _make_roads()
    _make_cover()
    _make_points_of_interest()
    _make_zone()
    _spawn_player()
    if game_mode == "squad":
        _spawn_squadmates(3)
    _spawn_bots(0 if game_mode == "training" else (12 if game_mode == "squad" else 8))
    if game_mode == "training":
        _spawn_training_targets(8)
    _spawn_loot(0 if game_mode == "training" else (22 if game_mode == "solo" else 34))
    hud = CanvasLayer.new()
    hud.set_script(HudScript)
    # Keep HUD controls usable when the game world is paused for results/pause menu.
    hud.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(hud)
    hud.player = player
    hud.game = self
    player.hud_ref = hud
    hud.show_message("VEY LORA • " + ("TRAINING GROUND" if game_mode == "training" else ("BOT DEATHMATCH" if game_mode == "tdm" else ("SQUAD BATTLE ROYALE" if game_mode == "squad" else "SOLO BATTLE ROYALE"))) + " | LOCAL ONLY")
    if not mode_selected:
        hud.show_mode_selector()

func _process(delta: float) -> void:
    if match_over:
        return
    match_time += delta
    zone_timer += delta
    if game_mode == "solo" and zone_timer >= 18.0 and zone_radius > 12.0:
        zone_timer = 0.0
        zone_radius = maxf(12.0, zone_radius - 5.0)
        if hud: hud.show_message("SAFE ZONE SHRINKING!")
    if player:
        var distance = Vector2(player.global_position.x, player.global_position.z).length()
        if game_mode == "solo" and distance > zone_radius:
            player.take_damage(5.0 * delta, "zone")
    _update_zone_visual()
    _update_bots()
    _update_revive(delta)
    if hud:
        hud.update_status(player.health, player.armor, player.ammo, player.reserve_ammo, bots_alive, int(match_time), zone_radius, player.medkits, player.weapon_names[player.weapon_index], player.is_reloading, game_mode, team_score, tdm_kill_target)
    if player and player.health <= 0:
        if game_mode == "tdm":
            player_respawn_timer += delta
            if player_respawn_timer >= 2.5:
                _respawn_player()
        elif game_mode != "training":
            finish_match(false)
    else:
        player_respawn_timer = 0.0
    if game_mode in ["solo", "squad"] and bots_alive <= 0:
        finish_match(true)
    elif game_mode == "tdm" and team_score >= tdm_kill_target:
        finish_match(true)

func _make_environment() -> void:
    var world = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.46, 0.56, 0.68)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world.environment = env
    add_child(world)
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    add_child(sun)

func _material(color: Color, roughness := 0.9) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _make_ground() -> void:
    var ground = StaticBody3D.new()
    ground.name = "Ground"
    var mesh = MeshInstance3D.new()
    var plane = PlaneMesh.new()
    plane.size = Vector2(140, 140)
    mesh.mesh = plane
    mesh.material_override = _material(Color(0.16, 0.24, 0.19))
    ground.add_child(mesh)
    var collision = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = Vector3(140, 1, 140)
    collision.shape = shape
    collision.position.y = -0.5
    ground.add_child(collision)
    add_child(ground)


func _make_roads() -> void:
    # Original low-cost road network connecting the four POIs.
    var asphalt := _material(Color(0.105, 0.12, 0.13))
    var shoulder := _material(Color(0.28, 0.30, 0.25))
    var lane_paint := _material(Color(0.88, 0.78, 0.43))
    _add_road_strip(Vector3(-54, 0.025, 0), Vector3(54, 0.025, 0), 5.2, asphalt)
    _add_road_strip(Vector3(0, 0.026, -54), Vector3(0, 0.026, 54), 5.2, asphalt)
    _add_road_strip(Vector3(-29, 0.027, 5), Vector3(-29, 0.027, 0), 4.0, asphalt)
    _add_road_strip(Vector3(29, 0.027, 4), Vector3(29, 0.027, 0), 4.0, asphalt)
    _add_road_strip(Vector3(0, 0.027, -27), Vector3(0, 0.027, -54), 4.0, asphalt)
    _add_road_strip(Vector3(0, 0.027, 30), Vector3(0, 0.027, 54), 4.0, asphalt)

    # Narrow shoulders keep roads visually separated from the grass.
    _add_road_strip(Vector3(-54, 0.018, -3.0), Vector3(54, 0.018, -3.0), 0.35, shoulder)
    _add_road_strip(Vector3(-54, 0.018, 3.0), Vector3(54, 0.018, 3.0), 0.35, shoulder)
    _add_road_strip(Vector3(-3.0, 0.019, -54), Vector3(-3.0, 0.019, 54), 0.35, shoulder)
    _add_road_strip(Vector3(3.0, 0.019, -54), Vector3(3.0, 0.019, 54), 0.35, shoulder)

    # Dashed centre markings, separated into short segments for a road-like look.
    for x in range(-50, 51, 8):
        _add_road_strip(Vector3(float(x), 0.052, 0), Vector3(float(x) + 3.4, 0.052, 0), 0.12, lane_paint)
    for z in range(-50, 51, 8):
        _add_road_strip(Vector3(0, 0.053, float(z)), Vector3(0, 0.053, float(z) + 3.4), 0.12, lane_paint)

func _add_road_strip(start: Vector3, finish: Vector3, width: float, material: Material) -> void:
    var midpoint := (start + finish) * 0.5
    var length_xz := Vector2(finish.x - start.x, finish.z - start.z).length()
    if length_xz < 0.05:
        return
    var road := MeshInstance3D.new()
    var slab := BoxMesh.new()
    slab.size = Vector3(length_xz, 0.025, width)
    road.mesh = slab
    road.material_override = material
    road.position = midpoint
    road.rotation.y = -atan2(finish.z - start.z, finish.x - start.x)
    add_child(road)

func _make_cover() -> void:
    var rng = RandomNumberGenerator.new()
    rng.randomize()
    for i in range(42):
        var body = StaticBody3D.new()
        var box = MeshInstance3D.new()
        var size = Vector3(rng.randf_range(1.5, 4.0), rng.randf_range(1.4, 3.8), rng.randf_range(1.5, 4.0))
        var bm = BoxMesh.new()
        bm.size = size
        box.mesh = bm
        box.material_override = _material([Color(0.27,0.31,0.32), Color(0.31,0.25,0.19), Color(0.18,0.29,0.25)][i % 3])
        body.add_child(box)
        var cs = CollisionShape3D.new()
        var bs = BoxShape3D.new()
        bs.size = size
        cs.shape = bs
        body.add_child(cs)
        var x = rng.randf_range(-48, 48)
        var z = rng.randf_range(-48, 48)
        if Vector2(x,z).length() < 9:
            x += 18
        body.position = Vector3(x, size.y/2, z)
        add_child(body)
        if i % 5 == 0:
            _add_tree(Vector3(x + 4, 0, z + 3), rng.randf_range(0.8, 1.4))

func _add_tree(pos: Vector3, scale_value: float) -> void:
    var tree = Node3D.new()
    tree.position = pos
    tree.scale = Vector3.ONE * scale_value
    var trunk = MeshInstance3D.new()
    var cyl = CylinderMesh.new()
    cyl.top_radius = 0.25
    cyl.bottom_radius = 0.42
    cyl.height = 2.8
    trunk.mesh = cyl
    trunk.position.y = 1.4
    trunk.material_override = _material(Color(0.25,0.16,0.09))
    tree.add_child(trunk)
    var crown = MeshInstance3D.new()
    var cone = SphereMesh.new()
    cone.radius = 1.55
    cone.height = 2.7
    crown.mesh = cone
    crown.position.y = 3.1
    crown.material_override = _material(Color(0.08,0.27,0.16))
    tree.add_child(crown)
    add_child(tree)


func _make_points_of_interest() -> void:
    # Small original landmarks make the prototype arena easier to navigate.
    _make_poi("VEYLORA OUTPOST", Vector3(0, 0, -27), Color(0.25, 0.42, 0.48), 0)
    _make_poi("ASHEN DEPOT", Vector3(29, 0, 4), Color(0.48, 0.31, 0.22), 1)
    _make_poi("NEXORA RELAY", Vector3(-29, 0, 5), Color(0.27, 0.38, 0.31), 2)
    _make_poi("DRAKEMOOR CAMP", Vector3(0, 0, 30), Color(0.40, 0.38, 0.24), 3)

func _make_poi(poi_name: String, center: Vector3, tint: Color, variant: int) -> void:
    var poi := Node3D.new()
    poi.name = poi_name.replace(" ", "_")
    poi.position = center
    add_child(poi)

    # Low platform / plaza marker.
    var platform := MeshInstance3D.new()
    var platform_mesh := BoxMesh.new()
    platform_mesh.size = Vector3(12.0, 0.22, 9.0)
    platform.mesh = platform_mesh
    platform.position.y = 0.11
    platform.material_override = _material(tint.darkened(0.45))
    poi.add_child(platform)

    var platform_body := StaticBody3D.new()
    platform_body.position.y = 0.11
    var platform_collision := CollisionShape3D.new()
    var platform_shape := BoxShape3D.new()
    platform_shape.size = platform_mesh.size
    platform_collision.shape = platform_shape
    platform_body.add_child(platform_collision)
    poi.add_child(platform_body)

    # Three small enterable structures with actual wall segments and doorway gaps.
    # Each structure is built from cheap box meshes to keep the prototype mobile-friendly.
    for i in range(3):
        var x_offset := [-3.25, 3.25, 0.0][i]
        var z_offset := [0.0, 0.0, -5.0][i]
        var building_tint := tint.lightened(0.12 if i == 2 else 0.0)
        var building_size := Vector3(4.6 if i != 2 else 3.6, 3.1 + float((variant + i) % 2) * 0.35, 4.0 if i != 2 else 3.2)
        _make_enterable_building(poi, Vector3(x_offset, 0.0, z_offset), building_tint, building_size.x, building_size.z, building_size.y)
        # Crate-height interior cover is positioned off the doorway line.
        _make_cover_crate(poi, Vector3(x_offset + (1.0 if i % 2 == 0 else -1.0), 0.0, z_offset - 0.55), Vector3(0.9, 1.05, 0.75), tint.darkened(0.3))

    var sign := Label3D.new()
    sign.text = poi_name
    sign.position = Vector3(0, 4.8, -4.0)
    sign.font_size = 30
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sign.modulate = Color(0.88, 0.96, 1.0)
    poi.add_child(sign)


func _make_enterable_building(parent: Node3D, center: Vector3, tint: Color, width: float, depth: float, height: float) -> void:
    var building := Node3D.new()
    building.name = "Enterable_Building"
    building.position = center
    parent.add_child(building)
    var wall_material := _material(tint)
    var interior_material := _material(tint.darkened(0.22))
    var wall_thickness := 0.24
    var door_width := 1.25
    var side_length := (width - door_width) * 0.5

    # Front wall split into two pieces so the doorway remains open.
    _add_wall_segment(building, Vector3(-(door_width + side_length) * 0.5, height * 0.5, depth * 0.5), Vector3(side_length, height, wall_thickness), wall_material)
    _add_wall_segment(building, Vector3((door_width + side_length) * 0.5, height * 0.5, depth * 0.5), Vector3(side_length, height, wall_thickness), wall_material)
    # Rear and side walls create a walk-in shell instead of a solid block.
    _add_wall_segment(building, Vector3(0, height * 0.5, -depth * 0.5), Vector3(width, height, wall_thickness), wall_material)
    _add_wall_segment(building, Vector3(-width * 0.5, height * 0.5, 0), Vector3(wall_thickness, height, depth), wall_material)
    _add_wall_segment(building, Vector3(width * 0.5, height * 0.5, 0), Vector3(wall_thickness, height, depth), wall_material)
    # Roof and interior floor are visual-only slabs; walls carry the collision.
    var roof := MeshInstance3D.new()
    var roof_mesh := BoxMesh.new()
    roof_mesh.size = Vector3(width + 0.12, 0.18, depth + 0.12)
    roof.mesh = roof_mesh
    roof.position.y = height + 0.06
    roof.material_override = interior_material
    building.add_child(roof)
    var floor := MeshInstance3D.new()
    var floor_mesh := BoxMesh.new()
    floor_mesh.size = Vector3(width - 0.3, 0.08, depth - 0.3)
    floor.mesh = floor_mesh
    floor.position.y = 0.05
    floor.material_override = _material(Color(0.30, 0.29, 0.24))
    building.add_child(floor)
    # A contrasting lintel helps players identify the entrance at a glance.
    _add_wall_segment(building, Vector3(0, height - 0.28, depth * 0.5), Vector3(door_width, 0.56, wall_thickness), interior_material)

func _make_cover_crate(parent: Node3D, local_position: Vector3, size: Vector3, tint: Color) -> void:
    var body := StaticBody3D.new()
    body.name = "Interior_Cover_Crate"
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.material_override = _material(tint)
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    body.position = local_position + Vector3.UP * size.y * 0.5
    parent.add_child(body)

func _add_wall_segment(parent: Node3D, local_position: Vector3, size: Vector3, material: Material) -> void:
    var body := StaticBody3D.new()
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.material_override = material
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    body.position = local_position
    parent.add_child(body)

func _make_zone() -> void:
    zone_mesh = MeshInstance3D.new()
    var cylinder = CylinderMesh.new()
    # A unit-radius disc is scaled to the current safe-zone radius below.
    cylinder.top_radius = 1.0
    cylinder.bottom_radius = 1.0
    cylinder.height = 0.025
    zone_mesh.mesh = cylinder
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.1, 0.75, 1.0, 0.18)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    zone_mesh.material_override = mat
    zone_mesh.position.y = 0.08
    add_child(zone_mesh)
    _update_zone_visual()

func _update_zone_visual() -> void:
    if zone_mesh:
        zone_mesh.scale = Vector3(zone_radius, 1, zone_radius)

func _spawn_player() -> void:
    player = PlayerScript.new()
    player.name = "Player"
    player.position = Vector3(0, 1.2, 0)
    add_child(player)

func _spawn_bots(count: int) -> void:
    for i in range(count):
        var bot = BotScript.new()
        bot_spawn_serial += 1
        bot.name = "Bot_%03d" % bot_spawn_serial
        # Spread spawns around the arena and avoid dropping respawns right beside the player.
        var angle := randf_range(0.0, TAU)
        var radius := randf_range(26.0, 43.0)
        var spawn_position := Vector3(cos(angle) * radius, 1.0, sin(angle) * radius)
        if is_instance_valid(player) and Vector2(spawn_position.x - player.global_position.x, spawn_position.z - player.global_position.z).length() < 18.0:
            spawn_position = -spawn_position.normalized() * randf_range(30.0, 42.0)
            spawn_position.y = 1.0
        bot.position = spawn_position
        bot.target_player = player
        bot.game = self
        bot.zone_radius = zone_radius
        bot.died.connect(_on_bot_died)
        add_child(bot)
        bot_nodes.append(bot)

func get_squadmates() -> Array[Node]:
    return squadmates

func _spawn_squadmates(count: int) -> void:
    for i in range(count):
        var mate = SquadmateScript.new()
        mate.name = "Squadmate_%02d" % (i + 1)
        mate.slot = i + 1
        var angle := TAU * float(i) / float(maxi(1, count))
        mate.position = Vector3(cos(angle) * 4.0, 1.0, sin(angle) * 4.0)
        mate.player = player
        mate.game = self
        add_child(mate)
        squadmates.append(mate)

func start_revive_nearest() -> void:
    if game_mode != "squad" or not is_instance_valid(player):
        if hud: hud.show_message("REVIVE IS AVAILABLE IN SQUAD MODE")
        return
    if revive_active:
        revive_active = false
        revive_progress = 0.0
        revive_target = null
        if hud: hud.show_message("REVIVE CANCELLED")
        return
    var nearest: Node = null
    var nearest_distance := 2.8
    for mate in squadmates:
        if not is_instance_valid(mate) or not mate.is_downed or mate.is_eliminated:
            continue
        var distance := player.global_position.distance_to(mate.global_position)
        if distance <= nearest_distance:
            nearest = mate
            nearest_distance = distance
    if nearest == null:
        if hud: hud.show_message("NO DOWNED TEAMMATE NEARBY • GET WITHIN 2.8M")
        return
    revive_target = nearest
    revive_progress = 0.0
    revive_active = true
    if hud: hud.show_message("REVIVING • STAY CLOSE AND DON'T TAKE DAMAGE")

func _update_revive(delta: float) -> void:
    if not revive_active:
        return
    if not is_instance_valid(player) or not is_instance_valid(revive_target) or player.health <= 0.0 or not revive_target.is_downed:
        revive_active = false
        revive_progress = 0.0
        revive_target = null
        return
    if player.global_position.distance_to(revive_target.global_position) > 2.8:
        revive_active = false
        revive_progress = 0.0
        revive_target = null
        if hud: hud.show_message("REVIVE INTERRUPTED • TOO FAR AWAY")
        return
    revive_progress += delta
    if hud:
        hud.show_message("REVIVING %d%%" % int(minf(1.0, revive_progress / revive_duration) * 100.0))
    if revive_progress >= revive_duration:
        var target = revive_target
        revive_active = false
        revive_progress = 0.0
        revive_target = null
        if is_instance_valid(target) and target.revive():
            if hud: hud.show_message("TEAMMATE BACK IN THE FIGHT")

func _spawn_training_targets(count: int) -> void:
    for i in range(count):
        var target = TargetScript.new()
        target.name = "TrainingTarget_%02d" % i
        var angle = TAU * float(i) / count
        target.position = Vector3(cos(angle) * 12.0, 0.0, sin(angle) * 12.0)
        add_child(target)

func _respawn_player() -> void:
    if not is_instance_valid(player) or game_mode != "tdm":
        return
    player.health = 100.0
    player.armor = 35.0
    player.global_position = Vector3(randf_range(-5.0, 5.0), 1.2, randf_range(-5.0, 5.0))
    player.velocity = Vector3.ZERO
    player_respawn_timer = 0.0
    if hud:
        hud.show_message("RESPAWNED • TEAM KILLS %d/%d" % [team_score, tdm_kill_target])

func _spawn_loot(count: int) -> void:
    # Prioritize reachable building interiors, then plazas and roadside cover.
    var anchors: Array[Vector3] = []
    var poi_centers := [Vector3(0, 0, -27), Vector3(29, 0, 4), Vector3(-29, 0, 5), Vector3(0, 0, 30)]
    for center in poi_centers:
        anchors.append(center + Vector3(-3.25, 0.45, -0.35))
        anchors.append(center + Vector3(3.25, 0.45, -0.35))
        anchors.append(center + Vector3(0.0, 0.45, -5.0))
        anchors.append(center + Vector3(0.0, 0.45, 2.2))
    for i in range(count):
        var loot = PickupScript.new()
        var base: Vector3
        if i < anchors.size():
            base = anchors[i]
            base.x += loot_rng.randf_range(-0.45, 0.45)
            base.z += loot_rng.randf_range(-0.35, 0.35)
        else:
            var angle := loot_rng.randf_range(0.0, TAU)
            var radius := loot_rng.randf_range(12.0, 46.0)
            base = Vector3(cos(angle) * radius, 0.45, sin(angle) * radius)
        loot.position = base
        loot.kind = ["ammo", "medkit", "armor", "weapon"][i % 4]
        add_child(loot)

func _update_bots() -> void:
    var alive := 0
    for bot in bot_nodes:
        if is_instance_valid(bot) and not bot.is_dead:
            bot.zone_radius = zone_radius
            var bot_distance = Vector2(bot.global_position.x, bot.global_position.z).length()
            if bot_distance > zone_radius:
                bot.take_damage(3.5 * get_process_delta_time(), false)
            if is_instance_valid(bot) and not bot.is_dead:
                alive += 1
    bots_alive = alive

func _on_bot_died(bot) -> void:
    if player:
        player.kills += 1
    if hud:
        hud.show_kill_feed("ELIMINATION  •  %d KILLS" % player.kills if player else "BOT ELIMINATED")
    if game_mode == "tdm" and not match_over:
        team_score += 1
        if team_score < tdm_kill_target:
            _spawn_bots(1)
    # Eliminated bots can drop a useful item, keeping combat tied to the loot loop.
    if is_instance_valid(bot) and loot_rng.randf() < 0.78:
        var loot = PickupScript.new()
        var kinds = ["ammo", "medkit", "armor", "weapon"]
        loot.kind = kinds[loot_rng.randi_range(0, kinds.size() - 1)]
        loot.position = Vector3(bot.global_position.x, 0.45, bot.global_position.z)
        add_child(loot)

func _load_game_mode() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://shadow_royale_settings.cfg") == OK:
        var saved_mode = str(cfg.get_value("game", "mode", "solo"))
        game_mode = saved_mode if saved_mode in ["training", "solo", "tdm"] else "solo"
        mode_selected = bool(cfg.get_value("game", "mode_selected", false))

func set_game_mode(value: String) -> void:
    game_mode = value if value in ["training", "solo", "tdm"] else "solo"
    mode_selected = true
    var cfg := ConfigFile.new()
    cfg.load("user://shadow_royale_settings.cfg")
    cfg.set_value("game", "mode", game_mode)
    cfg.set_value("game", "mode_selected", true)
    cfg.save("user://shadow_royale_settings.cfg")
    restart_match()

func open_mode_selector() -> void:
    mode_selected = false
    var cfg := ConfigFile.new()
    cfg.load("user://shadow_royale_settings.cfg")
    cfg.set_value("game", "mode_selected", false)
    cfg.save("user://shadow_royale_settings.cfg")
    restart_match()

func _load_local_profile() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://shadow_royale_profile.cfg") == OK:
        profile["matches"] = int(cfg.get_value("profile", "matches", 0))
        profile["wins"] = int(cfg.get_value("profile", "wins", 0))
        profile["kills"] = int(cfg.get_value("profile", "kills", 0))

func _save_match_result(won: bool) -> void:
    profile["matches"] = int(profile["matches"]) + 1
    profile["wins"] = int(profile["wins"]) + (1 if won else 0)
    profile["kills"] = int(profile["kills"]) + (player.kills if player else 0)
    var cfg := ConfigFile.new()
    cfg.set_value("profile", "matches", profile["matches"])
    cfg.set_value("profile", "wins", profile["wins"])
    cfg.set_value("profile", "kills", profile["kills"])
    cfg.save("user://shadow_royale_profile.cfg")

func finish_match(won: bool) -> void:
    if match_over:
        return
    match_over = true
    _save_match_result(won)
    if hud:
        hud.show_result(won, player.kills, int(match_time))
    get_tree().paused = true

func restart_match() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
