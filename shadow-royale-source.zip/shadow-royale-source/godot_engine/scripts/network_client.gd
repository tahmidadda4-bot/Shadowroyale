extends Node3D
## Standalone online movement test client. This is deliberately separate from the
## local bot prototype until authoritative combat is integrated and tested.

signal connected_to_match(entity_id: int)
signal connection_failed(reason: String)
signal snapshot_received(snapshot: Array)

const SEND_RATE := 20.0
const AVATAR_HEIGHT := 1.8
const SHOT_SEND_COOLDOWN := 0.22

@export var server_host := "127.0.0.1"
@export_range(1024, 65535) var server_port := 2456
var input_sequence := 0
var local_entity_id := -1
var access_token := ""
var send_accumulator := 0.0
var shot_accumulator := 0.0
var avatars: Dictionary = {} # entity_id -> MeshInstance3D
var health_labels: Dictionary = {}
var status_label: Label
var info_label: Label
var camera: Camera3D
var floor_node: MeshInstance3D
var zone_ring: MeshInstance3D
var displayed_zone_radius := 100.0
var loot_nodes: Dictionary = {} # loot_id -> Node3D
var pickup_key_was_down := false
var reload_key_was_down := false
var revive_key_was_down := false
var latest_snapshot: Array = []
var pickup_request_cooldown := 0.0
# Touch controls for Android. Desktop keyboard/mouse controls remain available.
var touch_move := Vector2.ZERO
var touch_directions: Dictionary = {}
var touch_fire_held := false
var last_aim_direction := Vector2.UP
var mobile_controls_root: Control
var mobile_dpad: GridContainer
var mobile_actions: VBoxContainer

func _ready() -> void:
    _build_test_arena()
    _build_hud()
    _build_mobile_controls()
    multiplayer.connected_to_server.connect(_on_connected)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)
    # Development-only convenience. Production should obtain the access token
    # from the app's authenticated Supabase session, never from a hard-coded key.
    var env_host := OS.get_environment("MATCH_HOST")
    if not env_host.is_empty():
        server_host = env_host
    var env_token := OS.get_environment("SUPABASE_ACCESS_TOKEN")
    if not env_token.is_empty():
        access_token = env_token
        call_deferred("connect_to_match", server_host, server_port, access_token)
    else:
        status_label.text = "Not connected — set SUPABASE_ACCESS_TOKEN for dev test"

func _build_test_arena() -> void:
    var world := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.58, 0.66, 0.78)
    environment.ambient_light_energy = 0.8
    world.environment = environment
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52.0, -28.0, 0.0)
    sun.light_energy = 1.1
    add_child(sun)

    floor_node = MeshInstance3D.new()
    var floor_mesh := PlaneMesh.new()
    floor_mesh.size = Vector2(520.0, 520.0)
    floor_node.mesh = floor_mesh
    var floor_mat := StandardMaterial3D.new()
    floor_mat.albedo_color = Color(0.12, 0.19, 0.21)
    floor_mat.roughness = 0.95
    floor_node.material_override = floor_mat
    add_child(floor_node)
    _build_cover_obstacles()
    zone_ring = MeshInstance3D.new()
    var ring_mesh := TorusMesh.new()
    ring_mesh.inner_radius = 0.985
    ring_mesh.outer_radius = 1.0
    ring_mesh.rings = 96
    ring_mesh.ring_segments = 8
    zone_ring.mesh = ring_mesh
    var ring_material := StandardMaterial3D.new()
    ring_material.albedo_color = Color(0.2, 0.65, 1.0, 0.75)
    ring_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ring_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    zone_ring.material_override = ring_material
    zone_ring.position.y = 0.06
    add_child(zone_ring)

    camera = Camera3D.new()
    camera.position = Vector3(0.0, 34.0, 28.0)
    camera.rotation_degrees = Vector3(-48.0, 0.0, 0.0)
    camera.current = true
    add_child(camera)


func _build_cover_obstacles() -> void:
    # Keep dimensions and centers synchronized with dedicated_server.gd COVER_RECTS.
    var covers := [
        Vector4(-8.0, -4.0, 4.0, 1.6),
        Vector4(7.0, 3.0, 1.6, 6.0),
        Vector4(0.0, 11.0, 6.4, 1.6),
        Vector4(14.0, -12.0, 4.8, 2.0),
        Vector4(-16.0, 9.0, 2.0, 5.0),
        Vector4(19.0, 7.0, 4.0, 1.6),
        Vector4(-21.0, -15.0, 5.6, 1.6)
    ]
    for i in range(covers.size()):
        var cover: Vector4 = covers[i]
        var block := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(cover.z, 1.8, cover.w)
        block.mesh = mesh
        block.position = Vector3(cover.x, 0.9, cover.y)
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.24, 0.29, 0.32) if i % 2 == 0 else Color(0.34, 0.25, 0.18)
        material.roughness = 0.92
        block.material_override = material
        add_child(block)

func _build_hud() -> void:
    var canvas := CanvasLayer.new()
    add_child(canvas)
    var panel := PanelContainer.new()
    panel.position = Vector2(16.0, 16.0)
    panel.custom_minimum_size = Vector2(390.0, 78.0)
    canvas.add_child(panel)
    var column := VBoxContainer.new()
    panel.add_child(column)
    status_label = Label.new()
    status_label.text = "Shadow Royale — Online Movement Test"
    column.add_child(status_label)
    info_label = Label.new()
    info_label.text = "WASD / arrows move • click/hold fire • cover blocks shots • zone shrinks"
    column.add_child(info_label)
    var pickup_hint := Label.new()
    pickup_hint.text = "Desktop: E pickup • F revive • R reload • Click fire | Android: touch buttons"
    column.add_child(pickup_hint)

func _build_mobile_controls() -> void:
    var canvas := get_node_or_null("CanvasLayer") as CanvasLayer
    if canvas == null:
        return
    mobile_controls_root = Control.new()
    mobile_controls_root.name = "MobileControls"
    mobile_controls_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mobile_controls_root.mouse_filter = Control.MOUSE_FILTER_PASS
    canvas.add_child(mobile_controls_root)

    # Simple four-way touch pad: reliable on small screens and does not depend on keyboard keys.
    var dpad := GridContainer.new()
    mobile_dpad = dpad
    dpad.columns = 3
    dpad.anchor_left = 0.0
    dpad.anchor_top = 1.0
    dpad.anchor_right = 0.0
    dpad.anchor_bottom = 1.0
    dpad.offset_left = 18.0
    dpad.offset_top = -174.0
    dpad.offset_right = 198.0
    dpad.offset_bottom = -18.0
    dpad.add_theme_constant_override("h_separation", 5)
    dpad.add_theme_constant_override("v_separation", 5)
    mobile_controls_root.add_child(dpad)
    _add_dpad_spacer(dpad)
    _add_direction_button(dpad, "▲", Vector2.UP)
    _add_dpad_spacer(dpad)
    _add_direction_button(dpad, "◀", Vector2.LEFT)
    _add_direction_button(dpad, "▼", Vector2.DOWN)
    _add_direction_button(dpad, "▶", Vector2.RIGHT)

    var actions := VBoxContainer.new()
    mobile_actions = actions
    actions.anchor_left = 1.0
    actions.anchor_top = 1.0
    actions.anchor_right = 1.0
    actions.anchor_bottom = 1.0
    actions.offset_left = -150.0
    actions.offset_top = -286.0
    actions.offset_right = -16.0
    actions.offset_bottom = -16.0
    actions.add_theme_constant_override("separation", 8)
    mobile_controls_root.add_child(actions)

    var fire_button := _make_touch_button("FIRE", Vector2(126.0, 58.0))
    fire_button.button_down.connect(func(): touch_fire_held = true)
    fire_button.button_up.connect(func(): touch_fire_held = false)
    actions.add_child(fire_button)
    var revive_button := _make_touch_button("REVIVE", Vector2(126.0, 48.0))
    revive_button.pressed.connect(_request_touch_revive)
    actions.add_child(revive_button)
    var reload_button := _make_touch_button("RELOAD", Vector2(126.0, 48.0))
    reload_button.pressed.connect(func():
        if local_entity_id >= 0:
            rpc_id(1, "request_reload")
    )
    actions.add_child(reload_button)
    var pickup_button := _make_touch_button("PICK UP", Vector2(126.0, 48.0))
    pickup_button.pressed.connect(_request_touch_pickup)
    actions.add_child(pickup_button)
    _layout_mobile_controls()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_SIZE_CHANGED and is_inside_tree():
        call_deferred("_layout_mobile_controls")

func _layout_mobile_controls() -> void:
    if mobile_controls_root == null or mobile_dpad == null or mobile_actions == null:
        return
    var viewport_size := get_viewport().get_visible_rect().size
    if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
        return
    # Scale controls for compact portrait phones while preserving larger thumb targets
    # on landscape phones/tablets. Keep the left and right control groups separated.
    var scale_factor := clampf(minf(viewport_size.x / 430.0, viewport_size.y / 390.0), 0.68, 1.0)
    mobile_dpad.scale = Vector2.ONE * scale_factor
    mobile_actions.scale = Vector2.ONE * scale_factor
    mobile_dpad.offset_left = 14.0
    mobile_dpad.offset_top = -174.0 * scale_factor
    mobile_dpad.offset_right = 194.0 * scale_factor
    mobile_dpad.offset_bottom = -14.0
    mobile_actions.offset_left = -150.0 * scale_factor
    mobile_actions.offset_top = -286.0 * scale_factor
    mobile_actions.offset_right = -14.0
    mobile_actions.offset_bottom = -14.0

func _make_touch_button(label_text: String, button_size: Vector2) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = button_size
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", 17)
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)
    return button

func _add_dpad_spacer(parent: GridContainer) -> void:
    var spacer := Control.new()
    spacer.custom_minimum_size = Vector2(55.0, 48.0)
    parent.add_child(spacer)

func _add_direction_button(parent: GridContainer, label_text: String, direction: Vector2) -> void:
    var button := _make_touch_button(label_text, Vector2(55.0, 48.0))
    button.button_down.connect(func(): _set_touch_direction(direction, true))
    button.button_up.connect(func(): _set_touch_direction(direction, false))
    parent.add_child(button)

func _set_touch_direction(direction: Vector2, is_down: bool) -> void:
    touch_directions[direction] = is_down
    var combined := Vector2.ZERO
    for direction_variant in touch_directions.keys():
        if bool(touch_directions[direction_variant]):
            combined += direction_variant
    touch_move = combined.limit_length(1.0)

func _request_touch_revive() -> void:
    if local_entity_id < 0:
        return
    var target_entity_id := _nearest_downed_entity_id()
    if target_entity_id >= 0:
        rpc_id(1, "request_revive", target_entity_id)
        info_label.text = "REVIVE • stay close for 4 seconds"
    else:
        info_label.text = "REVIVE • no downed player nearby"

func _request_touch_pickup() -> void:
    if local_entity_id < 0:
        return
    var nearby_loot := _nearest_loot_id()
    if not nearby_loot.is_empty():
        rpc_id(1, "request_pickup", nearby_loot)
    else:
        info_label.text = "PICK UP • no loot nearby"

func connect_to_match(host: String, port: int, supabase_access_token: String) -> Error:
    server_host = host.strip_edges()
    server_port = clampi(port, 1024, 65535)
    access_token = supabase_access_token.strip_edges()
    if server_host.is_empty() or access_token.is_empty():
        connection_failed.emit("missing_host_or_login_token")
        return ERR_INVALID_PARAMETER
    if multiplayer.multiplayer_peer != null and multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_DISCONNECTED:
        return ERR_ALREADY_IN_USE
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(server_host, server_port)
    if err != OK:
        connection_failed.emit("connect_failed_%d" % err)
        return err
    multiplayer.multiplayer_peer = peer
    status_label.text = "Connecting to %s:%d ..." % [server_host, server_port]
    return OK

func _process(delta: float) -> void:
    if local_entity_id < 0 or multiplayer.multiplayer_peer == null:
        return
    send_accumulator += delta
    shot_accumulator = maxf(0.0, shot_accumulator - delta)
    pickup_request_cooldown = maxf(0.0, pickup_request_cooldown - delta)
    var pickup_down := Input.is_key_pressed(KEY_E)
    if pickup_down and not pickup_key_was_down and pickup_request_cooldown <= 0.0:
        var nearby_loot := _nearest_loot_id()
        if not nearby_loot.is_empty():
            rpc_id(1, "request_pickup", nearby_loot)
            pickup_request_cooldown = 0.45
    pickup_key_was_down = pickup_down
    var reload_down := Input.is_key_pressed(KEY_R)
    if reload_down and not reload_key_was_down:
        rpc_id(1, "request_reload")
    reload_key_was_down = reload_down
    var revive_down := Input.is_key_pressed(KEY_F)
    if revive_down and not revive_key_was_down:
        var target_entity_id := _nearest_downed_entity_id()
        if target_entity_id >= 0:
            rpc_id(1, "request_revive", target_entity_id)
        else:
            info_label.text = "REVIVE • no downed player nearby"
    revive_key_was_down = revive_down
    if (Input.is_action_pressed("fire") or touch_fire_held) and shot_accumulator <= 0.0:
        var aim := _get_aim_direction()
        if aim.length() > 0.8:
            rpc_id(1, "submit_shot", aim.x, aim.y)
            shot_accumulator = SHOT_SEND_COOLDOWN
    if send_accumulator < 1.0 / SEND_RATE:
        return
    send_accumulator = 0.0
    var move := (Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    ) + touch_move).limit_length(1.0)
    if move.length() > 0.1:
        last_aim_direction = move.normalized()
    input_sequence += 1
    rpc_id(1, "submit_movement", input_sequence, move.x, move.y)

func _nearest_downed_entity_id() -> int:
    var my_item: Dictionary = {}
    for item_variant in latest_snapshot:
        if item_variant is Dictionary and int(item_variant.get("entity_id", -1)) == local_entity_id:
            my_item = item_variant
            break
    if my_item.is_empty():
        return -1
    var my_pos_data: Variant = my_item.get("position", [])
    if not my_pos_data is Array or my_pos_data.size() < 3:
        return -1
    var my_pos := Vector2(float(my_pos_data[0]), float(my_pos_data[2]))
    var nearest_id := -1
    var nearest_distance := 2.8
    for item_variant in latest_snapshot:
        if not item_variant is Dictionary or int(item_variant.get("entity_id", -1)) == local_entity_id:
            continue
        if float(item_variant.get("health", 100.0)) > 0.0 or int(item_variant.get("respawn_in_ms", 0)) <= 0:
            continue
        if int(item_variant.get("team_id", -1)) != int(my_item.get("team_id", -2)):
            continue
        var pos_data: Variant = item_variant.get("position", [])
        if not pos_data is Array or pos_data.size() < 3:
            continue
        var distance := my_pos.distance_to(Vector2(float(pos_data[0]), float(pos_data[2])))
        if distance <= nearest_distance:
            nearest_distance = distance
            nearest_id = int(item_variant["entity_id"])
    return nearest_id

func _local_team_id() -> int:
    for item_variant in latest_snapshot:
        if item_variant is Dictionary and int(item_variant.get("entity_id", -1)) == local_entity_id:
            return int(item_variant.get("team_id", -1))
    return -1

func _get_aim_direction() -> Vector2:
    if camera == null:
        return last_aim_direction
    if touch_fire_held:
        var auto_aim := _nearest_living_enemy_direction()
        if auto_aim.length() > 0.1:
            last_aim_direction = auto_aim
            return auto_aim
        return last_aim_direction
    var mouse := get_viewport().get_mouse_position()
    var ray_origin := camera.project_ray_origin(mouse)
    var ray_direction := camera.project_ray_normal(mouse)
    if absf(ray_direction.y) < 0.001:
        return Vector2.ZERO
    var distance_to_ground := -ray_origin.y / ray_direction.y
    if distance_to_ground < 0.0:
        return Vector2.ZERO
    var target := ray_origin + ray_direction * distance_to_ground
    var local_position := Vector2.ZERO
    if avatars.has(local_entity_id):
        var avatar: MeshInstance3D = avatars[local_entity_id]
        local_position = Vector2(avatar.position.x, avatar.position.z)
    var direction := Vector2(target.x, target.z) - local_position
    return direction.normalized() if direction.length() > 0.1 else Vector2.ZERO

func _nearest_living_enemy_direction() -> Vector2:
    var my_pos := Vector2.ZERO
    if avatars.has(local_entity_id):
        var mine: MeshInstance3D = avatars[local_entity_id]
        my_pos = Vector2(mine.position.x, mine.position.z)
    var best_direction := Vector2.ZERO
    var best_distance := 42.0
    for item_variant in latest_snapshot:
        if not item_variant is Dictionary or int(item_variant.get("entity_id", -1)) == local_entity_id:
            continue
        if float(item_variant.get("health", 0.0)) <= 0.0 or int(item_variant.get("respawn_in_ms", 0)) > 0:
            continue
        if int(item_variant.get("team_id", -1)) == _local_team_id():
            continue
        var pos_data: Variant = item_variant.get("position", [])
        if not pos_data is Array or pos_data.size() < 3:
            continue
        var offset := Vector2(float(pos_data[0]), float(pos_data[2])) - my_pos
        if offset.length() < best_distance and offset.length() > 0.1:
            best_distance = offset.length()
            best_direction = offset.normalized()
    return best_direction

func _on_connected() -> void:
    status_label.text = "Connected — verifying Supabase session..."
    rpc_id(1, "client_hello", access_token)

func _on_connection_failed() -> void:
    local_entity_id = -1
    status_label.text = "Connection failed. Check host, UDP port and server logs."
    connection_failed.emit("connection_failed")

func _on_server_disconnected() -> void:
    local_entity_id = -1
    status_label.text = "Server disconnected"
    _clear_avatars()

func _make_avatar(entity_id: int) -> MeshInstance3D:
    var avatar := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = AVATAR_HEIGHT
    avatar.mesh = capsule
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.18, 0.9, 0.65) if entity_id == local_entity_id else Color(0.96, 0.45, 0.18)
    material.roughness = 0.65
    avatar.material_override = material
    add_child(avatar)
    return avatar

# Matching RPC declarations keep Godot's RPC configuration consistent on both peers.
@rpc("any_peer", "call_remote", "reliable")
func client_hello(_access_token: String) -> void:
    pass # Server implementation verifies this token.

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_movement(_input_seq: int, _move_x: float, _move_z: float) -> void:
    pass # Server implementation owns authoritative movement.

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_shot(_aim_x: float, _aim_z: float) -> void:
    pass # Server implementation owns hit validation and damage.

@rpc("any_peer", "call_remote", "reliable")
func request_revive(_target_entity_id: int) -> void:
    pass # Server implementation validates range, target state, and revive duration.

@rpc("any_peer", "call_remote", "reliable")
func request_pickup(_loot_id: String) -> void:
    pass # Server implementation validates range and grants the item.

@rpc("any_peer", "call_remote", "reliable")
func request_reload() -> void:
    pass # Server implementation owns reload validation and reserve transfer.

@rpc("authority", "call_remote", "reliable")
func revive_result(success: bool, result: String) -> void:
    info_label.text = "REVIVE • %s" % result.to_upper() if success else "REVIVE BLOCKED • %s" % result.to_upper()

@rpc("authority", "call_remote", "reliable")
func reload_result(success: bool, result: String) -> void:
    info_label.text = "RELOAD • %s" % result.to_upper() if success else "RELOAD BLOCKED • %s" % result.to_upper()

@rpc("authority", "call_remote", "reliable")
func pickup_result(success: bool, result: String) -> void:
    if success:
        info_label.text = "PICKED UP • %s" % result.to_upper()
    else:
        info_label.text = "PICKUP BLOCKED • %s" % result.to_upper()

func _nearest_loot_id() -> String:
    if not avatars.has(local_entity_id):
        return ""
    var local_avatar: MeshInstance3D = avatars[local_entity_id]
    var local_pos := Vector2(local_avatar.position.x, local_avatar.position.z)
    var best_id := ""
    var best_distance := 3.2
    for loot_id_variant in loot_nodes.keys():
        var loot_id := str(loot_id_variant)
        var loot_node: Node3D = loot_nodes[loot_id]
        if not is_instance_valid(loot_node):
            continue
        var distance := local_pos.distance_to(Vector2(loot_node.position.x, loot_node.position.z))
        if distance < best_distance:
            best_distance = distance
            best_id = loot_id
    return best_id

func _sync_loot(items: Array) -> void:
    var seen: Dictionary = {}
    for item_variant in items:
        if not item_variant is Dictionary or not item_variant.has("id") or not item_variant.has("position"):
            continue
        var item: Dictionary = item_variant
        var loot_id := str(item["id"])
        var coords: Variant = item["position"]
        if not coords is Array or coords.size() != 3:
            continue
        seen[loot_id] = true
        if not loot_nodes.has(loot_id):
            var pickup := Node3D.new()
            var mesh_node := MeshInstance3D.new()
            var box := BoxMesh.new()
            box.size = Vector3(0.65, 0.65, 0.65)
            mesh_node.mesh = box
            var material := StandardMaterial3D.new()
            material.albedo_color = Color(0.15, 0.9, 0.35) if str(item.get("kind", "")) == "medkit" else Color(0.95, 0.72, 0.12)
            material.emission_enabled = true
            material.emission = material.albedo_color * 0.35
            mesh_node.material_override = material
            pickup.add_child(mesh_node)
            var label := Label3D.new()
            label.text = "MEDKIT" if str(item.get("kind", "")) == "medkit" else "AMMO"
            label.position.y = 0.65
            label.font_size = 32
            pickup.add_child(label)
            add_child(pickup)
            loot_nodes[loot_id] = pickup
        var pickup_node: Node3D = loot_nodes[loot_id]
        pickup_node.position = Vector3(float(coords[0]), 0.55, float(coords[2]))
    for loot_id_variant in loot_nodes.keys().duplicate():
        if not seen.has(loot_id_variant):
            if is_instance_valid(loot_nodes[loot_id_variant]):
                loot_nodes[loot_id_variant].queue_free()
            loot_nodes.erase(loot_id_variant)

@rpc("authority", "call_remote", "reliable")
func auth_accepted(entity_id: int) -> void:
    local_entity_id = entity_id
    status_label.text = "Authenticated — entity %d" % entity_id
    connected_to_match.emit(entity_id)

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_snapshot(snapshot: Array) -> void:
    latest_snapshot = snapshot.duplicate(true)
    var seen: Dictionary = {}
    if not snapshot.is_empty() and snapshot[0] is Dictionary:
        _sync_loot(snapshot[0].get("loot", []))
    for item in snapshot:
        if not item is Dictionary or not item.has("entity_id") or not item.has("position"):
            continue
        var entity_id := int(item["entity_id"])
        var coords: Variant = item["position"]
        if not coords is Array or coords.size() != 3:
            continue
        seen[entity_id] = true
        if item.has("zone_radius"):
            displayed_zone_radius = maxf(1.0, float(item["zone_radius"]))
            if zone_ring != null:
                zone_ring.scale = Vector3(displayed_zone_radius, 1.0, displayed_zone_radius)
        if not avatars.has(entity_id):
            avatars[entity_id] = _make_avatar(entity_id)
        var avatar: MeshInstance3D = avatars[entity_id]
        avatar.position = Vector3(float(coords[0]), AVATAR_HEIGHT * 0.5, float(coords[2]))
        if entity_id == local_entity_id:
            camera.position = Vector3(avatar.position.x, 34.0, avatar.position.z + 28.0)
            camera.look_at(avatar.position, Vector3.UP)
            status_label.text = "ONLINE • Squad %d • Entity %d • Players %d • Touch controls ready" % [int(item.get("team_id", 0)), entity_id, snapshot.size()]
            info_label.text = "HP %s • Ammo %s/%s%s • Medkits %s • K/D %s/%s • Respawn %ss • Zone %.0fm / %ss" % [str(item.get("health", "?")), str(item.get("magazine", 30)), str(item.get("ammo", 0)), " (RELOADING)" if item.get("reloading", false) else "", str(item.get("medkits", 0)), str(item.get("kills", 0)), str(item.get("deaths", 0)), str(int(ceil(float(item.get("respawn_in_ms", 0)) / 1000.0))), displayed_zone_radius, str(item.get("zone_time_remaining", "?"))]
    for entity_variant in avatars.keys().duplicate():
        if not seen.has(entity_variant):
            avatars[entity_variant].queue_free()
            avatars.erase(entity_variant)
    snapshot_received.emit(snapshot)

@rpc("authority", "call_remote", "reliable")
func auth_rejected(reason: String) -> void:
    local_entity_id = -1
    status_label.text = "Login/server rejected connection: %s" % reason
    connection_failed.emit(reason)

func _clear_avatars() -> void:
    for entity_variant in avatars.keys():
        if is_instance_valid(avatars[entity_variant]):
            avatars[entity_variant].queue_free()
    avatars.clear()
