extends CharacterBody3D

var move_speed := 7.0
var walk_speed := 7.0
var sprint_speed := 10.0
var crouch_speed := 3.8
var is_sprinting := false
var is_crouching := false
var health := 100.0
var armor := 35.0
var ammo := 30
var reserve_ammo := 120
var weapon_index := 0
var weapon_names := ["ASSAULT RIFLE", "SHOTGUN", "SNIPER", "SMG", "PISTOL"]
var weapon_magazines := [30, 8, 5, 36, 12]
var weapon_damage := [34.0, 18.0, 82.0, 19.0, 28.0]
var weapon_ranges := [95.0, 24.0, 180.0, 55.0, 45.0]
var weapon_cooldowns := [0.18, 0.72, 1.05, 0.085, 0.32]
var magazine_ammo := [30, 8, 5, 36, 12]
var reserve_by_weapon := [120, 40, 20, 144, 60]
var kills := 0
var medkits := 2
var fire_cooldown := 0.0
var reload_time := 0.0
var is_reloading := false
var yaw := 0.0
var pitch := -0.18
var camera_pivot: Node3D
var camera: Camera3D
var body_mesh: MeshInstance3D
var hud_ref
var weapon_pivot: Node3D
var weapon_mesh: MeshInstance3D
var arm_mesh: MeshInstance3D
var animation_clock := 0.0
var recoil_pitch := 0.0
var recoil_roll := 0.0
var grenade_count := 2
var grenade_cooldown := 0.0

func _ready() -> void:
    _make_body()
    _make_camera()
    add_to_group("player")

func _physics_process(delta: float) -> void:
    if get_tree().paused:
        return
    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    grenade_cooldown = maxf(0.0, grenade_cooldown - delta)
    animation_clock += delta
    recoil_pitch = move_toward(recoil_pitch, 0.0, delta * 1.8)
    recoil_roll = move_toward(recoil_roll, 0.0, delta * 2.4)
    if is_reloading:
        reload_time -= delta
        if reload_time <= 0:
            var needed = weapon_magazines[weapon_index] - ammo
            var loaded = mini(needed, reserve_by_weapon[weapon_index])
            ammo += loaded
            reserve_by_weapon[weapon_index] -= loaded
            magazine_ammo[weapon_index] = ammo
            reserve_ammo = reserve_by_weapon[weapon_index]
            is_reloading = false
    is_sprinting = Input.is_key_pressed(KEY_SHIFT)
    is_crouching = Input.is_key_pressed(KEY_CTRL)
    if hud_ref:
        is_sprinting = is_sprinting or hud_ref.sprint_held
        is_crouching = is_crouching or hud_ref.crouch_held
    move_speed = crouch_speed if is_crouching else (sprint_speed if is_sprinting else walk_speed)
    var input_vec = Vector2.ZERO
    input_vec.x = float(Input.is_action_pressed("move_right")) - float(Input.is_action_pressed("move_left"))
    input_vec.y = float(Input.is_action_pressed("move_back")) - float(Input.is_action_pressed("move_forward"))
    if hud_ref and hud_ref.virtual_move.length() > 0.1:
        input_vec = hud_ref.virtual_move
    input_vec = input_vec.limit_length(1.0)
    # Move relative to the camera so mobile aiming and movement stay aligned.
    var camera_basis = camera_pivot.global_transform.basis if camera_pivot else global_transform.basis
    var forward = -camera_basis.z
    var right = camera_basis.x
    forward.y = 0.0
    right.y = 0.0
    forward = forward.normalized()
    right = right.normalized()
    var direction = (right * input_vec.x + forward * -input_vec.y).normalized()
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    if not is_on_floor():
        velocity.y -= 22.0 * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = 7.5
    move_and_slide()
    if body_mesh:
        var moving := Vector2(velocity.x, velocity.z).length() > 0.4 and is_on_floor()
        body_mesh.position.y = 0.9 + (sin(animation_clock * (12.0 if is_sprinting else 8.0)) * 0.045 if moving else 0.0)
        body_mesh.rotation.z = lerpf(body_mesh.rotation.z, -input_vec.x * 0.08, delta * 7.0)
    if weapon_pivot:
        var moving_weapon := Vector2(velocity.x, velocity.z).length() > 0.4 and is_on_floor()
        weapon_pivot.position.y = -0.28 + (sin(animation_clock * 10.0) * 0.025 if moving_weapon else 0.0)
        weapon_pivot.rotation.x = recoil_pitch
        weapon_pivot.rotation.z = recoil_roll
    if Input.is_action_just_pressed("grenade"):
        throw_grenade()
    if Input.is_action_pressed("fire") or (hud_ref and hud_ref.fire_held):
        fire()
    if hud_ref and hud_ref.virtual_look.length() > 0.0:
        yaw -= hud_ref.virtual_look.x * 0.006
        pitch = clampf(pitch - hud_ref.virtual_look.y * 0.004, -0.9, 0.35)
        hud_ref.virtual_look = Vector2.ZERO
    if camera_pivot:
        camera_pivot.rotation.y = yaw
        camera_pivot.rotation.x = pitch + recoil_pitch * 0.25

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        yaw -= event.relative.x * 0.003
        pitch = clampf(pitch - event.relative.y * 0.003, -0.9, 0.35)

func _make_body() -> void:
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    var cs = CollisionShape3D.new()
    cs.shape = capsule
    cs.position.y = 0.9
    add_child(cs)
    body_mesh = MeshInstance3D.new()
    var cm = CapsuleMesh.new()
    cm.radius = 0.42
    cm.height = 1.8
    body_mesh.mesh = cm
    body_mesh.position.y = 0.9
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.05, 0.72, 0.95)
    mat.metallic = 0.25
    body_mesh.material_override = mat
    add_child(body_mesh)
    # Lightweight procedural third-person arms and weapon silhouette; no external assets required.
    var arm = MeshInstance3D.new()
    var arm_shape = BoxMesh.new()
    arm_shape.size = Vector3(0.22, 0.22, 0.72)
    arm.mesh = arm_shape
    arm.position = Vector3(0.34, 1.12, -0.34)
    arm.material_override = _make_material(Color(0.08, 0.22, 0.30))
    add_child(arm)
    arm_mesh = arm
    weapon_pivot = Node3D.new()
    weapon_pivot.position = Vector3(0.36, 1.18, -0.52)
    add_child(weapon_pivot)
    weapon_mesh = MeshInstance3D.new()
    var gun_shape = BoxMesh.new()
    gun_shape.size = Vector3(0.14, 0.15, 0.72)
    weapon_mesh.mesh = gun_shape
    weapon_mesh.position.z = -0.26
    weapon_mesh.material_override = _make_material(Color(0.10, 0.12, 0.15))
    weapon_pivot.add_child(weapon_mesh)
    var barrel = MeshInstance3D.new()
    var barrel_shape = CylinderMesh.new()
    barrel_shape.top_radius = 0.035
    barrel_shape.bottom_radius = 0.045
    barrel_shape.height = 0.34
    barrel.mesh = barrel_shape
    barrel.rotation.x = PI * 0.5
    barrel.position.z = -0.68
    barrel.material_override = _make_material(Color(0.32, 0.35, 0.38))
    weapon_pivot.add_child(barrel)

func _make_material(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.metallic = 0.35
    material.roughness = 0.55
    return material

func _make_camera() -> void:
    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0, 1.45, 0)
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.position = Vector3(0, 2.0, 6.5)
    camera.rotation_degrees.x = -12
    camera.current = true
    camera_pivot.add_child(camera)

func fire() -> void:
    if fire_cooldown > 0.0 or is_reloading or ammo <= 0 or health <= 0.0:
        return
    fire_cooldown = weapon_cooldowns[weapon_index]
    # Per-weapon kick: heavier weapons disturb aim more, then recover smoothly.
    var kick := [0.035, 0.075, 0.095, 0.022, 0.03][weapon_index]
    recoil_pitch = maxf(recoil_pitch, kick)
    recoil_roll = randf_range(-kick * 0.45, kick * 0.45)
    if weapon_pivot:
        weapon_pivot.position.z = -0.42
        var tween := create_tween()
        tween.tween_property(weapon_pivot, "position:z", -0.52, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    ammo -= 1
    magazine_ammo[weapon_index] = ammo
    var from: Vector3 = camera.global_position
    var basis: Basis = camera.global_transform.basis
    var pellets := 6 if weapon_index == 1 else 1
    var spread := 0.075 if weapon_index == 1 else 0.0
    var hit_any := false
    for pellet in range(pellets):
        var direction: Vector3 = -basis.z
        if spread > 0.0:
            direction = (direction + basis.x * randf_range(-spread, spread) + basis.y * randf_range(-spread, spread)).normalized()
        var to: Vector3 = from + direction * weapon_ranges[weapon_index]
        var query := PhysicsRayQueryParameters3D.create(from, to)
        query.exclude = [self]
        var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
        if hit.is_empty() or not hit.get("collider"):
            continue
        var collider = hit.collider
        if not collider.is_in_group("bots") and not collider.is_in_group("training_targets"):
            continue
        var damage: float = weapon_damage[weapon_index]
        if weapon_index == 1:
            damage *= randf_range(0.55, 1.0)
        var hit_position: Vector3 = hit.get("position", collider.global_position)
        var headshot_height := 1.35 if collider.is_in_group("bots") else 1.42
        var is_headshot: bool = hit_position.y >= collider.global_position.y + headshot_height
        var applied_damage: float = damage * (1.8 if is_headshot and collider.is_in_group("bots") else (1.5 if is_headshot else 1.0))
        collider.take_damage(damage, is_headshot)
        hit_any = true
        if hud_ref and hud_ref.has_method("show_hit_feedback"):
            hud_ref.show_hit_feedback(is_headshot, applied_damage)
    if not hit_any and hud_ref and weapon_index != 1:
        hud_ref.show_message("SHOT FIRED • NO HIT")

func reload_weapon() -> void:
    var magazine_size: int = weapon_magazines[weapon_index]
    reserve_ammo = reserve_by_weapon[weapon_index]
    if is_reloading or ammo >= magazine_size or reserve_ammo <= 0:
        return
    is_reloading = true
    reload_time = [1.5, 1.9, 2.2, 1.35, 1.25][weapon_index]

func cycle_weapon() -> void:
    magazine_ammo[weapon_index] = ammo
    weapon_index = (weapon_index + 1) % weapon_names.size()
    ammo = magazine_ammo[weapon_index]
    reserve_ammo = reserve_by_weapon[weapon_index]
    is_reloading = false
    fire_cooldown = 0.0

func throw_grenade() -> void:
    if grenade_count <= 0 or grenade_cooldown > 0.0 or health <= 0.0:
        if hud_ref: hud_ref.show_message("NO GRENADE / COOLDOWN")
        return
    grenade_count -= 1
    grenade_cooldown = 1.1
    var grenade := RigidBody3D.new()
    grenade.name = "ThrownGrenade"
    grenade.mass = 0.45
    grenade.position = camera.global_position + (-camera.global_transform.basis.z * 0.9)
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.16
    sphere.height = 0.32
    mesh.mesh = sphere
    mesh.material_override = _make_material(Color(0.25, 0.48, 0.18))
    grenade.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.16
    collision.shape = shape
    grenade.add_child(collision)
    get_tree().current_scene.add_child(grenade)
    grenade.linear_velocity = (-camera.global_transform.basis.z * 12.0) + Vector3.UP * 5.0
    var timer := Timer.new()
    timer.one_shot = true
    timer.wait_time = 1.65
    grenade.add_child(timer)
    timer.timeout.connect(Callable(self, "_explode_grenade").bind(grenade))
    timer.start()
    if hud_ref: hud_ref.show_message("GRENADE THROWN • %d LEFT" % grenade_count)

func _explode_grenade(grenade: RigidBody3D) -> void:
    if not is_instance_valid(grenade):
        return
    var blast_position := grenade.global_position
    var flash := OmniLight3D.new()
    flash.light_color = Color(1.0, 0.42, 0.12)
    flash.light_energy = 3.0
    flash.omni_range = 7.0
    flash.position = blast_position
    get_tree().current_scene.add_child(flash)
    for group_name in ["bots", "training_targets"]:
        for target in get_tree().get_nodes_in_group(group_name):
            if not is_instance_valid(target) or not target.has_method("take_damage"):
                continue
            var distance := blast_position.distance_to(target.global_position)
            if distance > 7.0:
                continue
            var ray := PhysicsRayQueryParameters3D.create(blast_position, target.global_position + Vector3.UP * 0.6)
            ray.exclude = [grenade]
            var hit := get_world_3d().direct_space_state.intersect_ray(ray)
            if hit.is_empty() or hit.get("collider") == target:
                target.take_damage(95.0 * (1.0 - distance / 9.0), false)
    var cleanup := get_tree().create_timer(0.18)
    cleanup.timeout.connect(flash.queue_free)
    grenade.queue_free()
    if hud_ref: hud_ref.show_message("GRENADE DETONATED")

func heal() -> void:
    if medkits > 0 and health < 100:
        medkits -= 1
        health = minf(100.0, health + 45.0)

func take_damage(amount: float, _source := "") -> void:
    if health <= 0.0:
        return
    if hud_ref and hud_ref.has_method("show_damage_feedback"):
        hud_ref.show_damage_feedback(amount)
    if armor > 0:
        var absorbed = minf(armor, amount * 0.55)
        armor -= absorbed
        amount -= absorbed
    health = maxf(0.0, health - amount)

func collect(kind: String) -> void:
    match kind:
        "ammo":
            reserve_by_weapon[0] += 30
            reserve_by_weapon[1] += 10
            reserve_by_weapon[2] += 5
            reserve_by_weapon[3] += 36
            reserve_by_weapon[4] += 12
            reserve_ammo = reserve_by_weapon[weapon_index]
            _notify_pickup("AMMO +30 / +10 / +5")
        "medkit":
            medkits += 1
            _notify_pickup("MEDKIT +1")
        "armor":
            var previous_armor := armor
            armor = minf(100.0, armor + 35.0)
            _notify_pickup("ARMOR +%d" % int(armor - previous_armor))
        "weapon":
            cycle_weapon()
            _notify_pickup("WEAPON: " + weapon_names[weapon_index])

func _notify_pickup(message: String) -> void:
    if is_instance_valid(hud_ref) and hud_ref.has_method("show_message"):
        hud_ref.show_message("PICKED UP • " + message)
