extends RefCounted
## Pure server-side ranking rules. Balance values are Shadow Royale defaults, not copied from another game.

const CS_STARS_PER_TIER := 5
const CS_POINTS_PER_STAR := 100
const CS_TIER_NAMES := ["Rookie", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Elite", "Heroic", "Master", "Grandmaster"]
const BR_THRESHOLDS := [0, 200, 450, 800, 1250, 1800, 2400, 3200, 4200]
const BR_TIER_NAMES := ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Crown", "Heroic", "Master", "Grandmaster"]

static func cs_match_delta(won: bool, round_difference: int, kills: int) -> int:
    var result := 25 if won else -15
    result += clampi(round_difference, -5, 5) * 2
    result += mini(maxi(kills, 0), 10)
    return clampi(result, -25, 40)

static func br_match_delta(placement: int, kills: int, survival_seconds: int) -> int:
    var place_points := 0
    if placement <= 1:
        place_points = 80
    elif placement == 2:
        place_points = 60
    elif placement <= 5:
        place_points = 40
    elif placement <= 10:
        place_points = 20
    elif placement <= 20:
        place_points = 5
    else:
        place_points = -20
    var kill_points := mini(maxi(kills, 0), 5) * 8
    var survival_points := mini(int(maxi(survival_seconds, 0) / 120), 10)
    return clampi(place_points + kill_points + survival_points, -30, 130)

static func cs_tier(points: int) -> Dictionary:
    var safe_points := maxi(points, 0)
    var star_index := int(safe_points / CS_POINTS_PER_STAR)
    var tier_index := mini(int(star_index / CS_STARS_PER_TIER), CS_TIER_NAMES.size() - 1)
    var stars := star_index % CS_STARS_PER_TIER
    var capped := safe_points >= CS_TIER_NAMES.size() * CS_STARS_PER_TIER * CS_POINTS_PER_STAR
    if capped:
        tier_index = CS_TIER_NAMES.size() - 1
        stars = CS_STARS_PER_TIER
    return {"tier": CS_TIER_NAMES[tier_index], "stars": stars, "points": safe_points, "next_star_at": CS_TIER_NAMES.size() * CS_STARS_PER_TIER * CS_POINTS_PER_STAR if capped else (star_index + 1) * CS_POINTS_PER_STAR, "points_into_star": 0 if capped else safe_points % CS_POINTS_PER_STAR, "points_to_next_star": 0 if capped else CS_POINTS_PER_STAR - (safe_points % CS_POINTS_PER_STAR)}

static func br_tier(points: int) -> Dictionary:
    var safe_points := maxi(points, 0)
    var tier_index := 0
    for i in range(BR_THRESHOLDS.size()):
        if safe_points >= BR_THRESHOLDS[i]:
            tier_index = i
    var next_threshold := BR_THRESHOLDS[mini(tier_index + 1, BR_THRESHOLDS.size() - 1)]
    if tier_index == BR_TIER_NAMES.size() - 1:
        next_threshold = BR_THRESHOLDS[BR_THRESHOLDS.size() - 1]
    return {"tier": BR_TIER_NAMES[tier_index], "points": safe_points, "next_tier_at": next_threshold, "points_to_next_tier": maxi(0, next_threshold - safe_points)}
