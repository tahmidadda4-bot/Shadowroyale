extends CharacterBody3D

signal knocked_out(mate)
signal eliminated(mate)

var player: Node3D
var game
var slot := 1
var health := 100.0
var is_downed := false
var is_eliminated := false
var bleedout_seconds := 35.0
var follow_speed := 4.2
var body_mesh: MeshInstance3D
var shot_timer := 0.0
var anim_clock := 0.0

func _ready() -> void:
    add_to_group("squadmates")
    var shape := CapsuleShape3D.new()
    shape.radius = 0.38
    shape.height = 1.7
    var collision := CollisionShape3D.new()
    collision.shape = shape
    collision.position.y = 0.85
    add_child(collision)
    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.38
    mesh.height = 1.7
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.85
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.2, 0.85, 0.52)
    material.metallic = 0.12
    body_mesh.material_override = material
    add_child(body_mesh)

func _physics_process(delta: float) -> void:
    if is_eliminated or get_tree().paused:
        return
    anim_clock += delta
    if is_downed:
        bleedout_seconds -= delta
        velocity.x = move_toward(velocity.x, 0.0, delta * 5.0)
        velocity.z = move_toward(velocity.z, 0.0, delta * 5.0)
        if body_mesh:
            body_mesh.rotation.z = lerpf(body_mesh.rotation.z, 1.25, delta * 4.0)
        move_and_slide()
        if bleedout_seconds <= 0.0:
            eliminate()
        return
    if not is_instance_valid(player):
        return
    shot_timer -= delta
    var offset: Vector3 = player.global_position - global_position
    var flat := Vector3(offset.x, 0.0, offset.z)
    var distance := flat.length()
    if distance > 4.0:
        var direction := flat.normalized()
        velocity.x = direction.x * follow_speed
        velocity.z = direction.z * follow_speed
    else:
        velocity.x = move_toward(velocity.x, 0.0, delta * 7.0)
        velocity.z = move_toward(velocity.z, 0.0, delta * 7.0)
    if distance > 0.2:
        look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z), Vector3.UP)
    if not is_on_floor():
        velocity.y -= 22.0 * delta
    move_and_slide()
    if body_mesh:
        body_mesh.position.y = 0.85 + (sin(anim_clock * 9.0) * 0.035 if Vector2(velocity.x, velocity.z).length() > 0.4 else 0.0)

func take_damage(amount: float, _source := "enemy") -> void:
    if is_downed or is_eliminated:
        return
    health = maxf(0.0, health - amount)
    if health <= 0.0:
        is_downed = true
        bleedout_seconds = 35.0
        velocity = Vector3.ZERO
        knocked_out.emit(self)
        if game and game.hud:
            game.hud.show_message("SQUADMATE DOWN • REVIVE WITHIN 35 SECONDS")

func revive() -> bool:
    if not is_downed or is_eliminated or bleedout_seconds <= 0.0:
        return false
    is_downed = false
    health = 45.0
    bleedout_seconds = 35.0
    if body_mesh:
        body_mesh.rotation.z = 0.0
    if game and game.hud:
        game.hud.show_message("SQUADMATE REVIVED • 45 HP")
    return true

func eliminate() -> void:
    if is_eliminated:
        return
    is_eliminated = true
    eliminated.emit(self)
    queue_free()
