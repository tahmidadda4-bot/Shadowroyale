extends CharacterBody3D

var health := 100.0
var reset_timer := 0.0
var body_mesh: MeshInstance3D
var label: Label3D

func _ready() -> void:
    add_to_group("training_targets")
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.8
    collision.shape = shape
    collision.position.y = 0.9
    add_child(collision)

    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.48
    mesh.height = 1.8
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.9
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(1.0, 0.68, 0.12)
    material.roughness = 0.65
    body_mesh.material_override = material
    add_child(body_mesh)

    label = Label3D.new()
    label.text = "TARGET 100 HP"
    label.position.y = 2.1
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 32
    add_child(label)

func _physics_process(delta: float) -> void:
    if reset_timer > 0.0:
        reset_timer -= delta
        if reset_timer <= 0.0:
            health = 100.0
            visible = true
            collision_layer = 1
            collision_mask = 1
            if label:
                label.text = "TARGET 100 HP"
            if body_mesh:
                var material := body_mesh.material_override as StandardMaterial3D
                material.albedo_color = Color(1.0, 0.68, 0.12)

func take_damage(amount: float, headshot := false) -> void:
    if reset_timer > 0.0:
        return
    health = maxf(0.0, health - amount * (1.5 if headshot else 1.0))
    if label:
        label.text = "HEADSHOT! %d HP" % int(health) if headshot else "TARGET %d HP" % int(health)
    if body_mesh and health > 0.0:
        var material := body_mesh.material_override as StandardMaterial3D
        material.albedo_color = Color(1.0, 0.28, 0.12) if headshot else Color(1.0, 0.82, 0.28)
    if health <= 0.0:
        reset_timer = 2.0
        visible = false
        collision_layer = 0
        collision_mask = 0
