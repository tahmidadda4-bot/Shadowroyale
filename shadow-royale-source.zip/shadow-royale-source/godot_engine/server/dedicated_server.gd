extends Node
## Headless dedicated-server foundation. This is not yet wired into the visual match scene.
## Launch with Godot's --headless --path godot_engine --scene res://server/server.tscn

const DEFAULT_PORT := 2456
const MAX_PLAYERS := 50
const TICK_RATE := 20.0
const MOVE_SPEED := 7.0
const MAP_LIMIT := 250.0
const SHOT_RANGE := 42.0
const SHOT_DAMAGE := 25.0
const SHOT_COOLDOWN_MS := 220
const MAGAZINE_SIZE := 30
const RELOAD_DURATION_MS := 1800
const RESPAWN_DELAY_MS := 5000
const PLAYER_RADIUS := 0.55
const ZONE_START_RADIUS := 100.0
const ZONE_END_RADIUS := 18.0
const ZONE_SHRINK_SECONDS := 180.0
const ZONE_DAMAGE_PER_SECOND := 5.0
const PICKUP_RANGE := 3.2
const REVIVE_RANGE := 2.8
const REVIVE_DURATION_MS := 4000
const REVIVE_HEALTH := 45.0
const LOOT_RESPAWN_MS := 0 # Match loot is one-time pickup in this prototype.
const LOOT_DEFINITIONS := [
    {"id": "medkit_01", "kind": "medkit", "position": Vector3(-4.0, 0.0, -8.0), "amount": 35},
    {"id": "ammo_01", "kind": "ammo", "position": Vector3(5.0, 0.0, -6.0), "amount": 30},
    {"id": "medkit_02", "kind": "medkit", "position": Vector3(12.0, 0.0, 5.0), "amount": 35},
    {"id": "ammo_02", "kind": "ammo", "position": Vector3(-12.0, 0.0, 2.0), "amount": 30},
    {"id": "ammo_03", "kind": "ammo", "position": Vector3(22.0, 0.0, -4.0), "amount": 30}
]
# Shared with the visual test client: [center_x, center_z, half_width, half_depth].
const COVER_RECTS := [
    [-8.0, -4.0, 2.0, 0.8],
    [7.0, 3.0, 0.8, 3.0],
    [0.0, 11.0, 3.2, 0.8],
    [14.0, -12.0, 2.4, 1.0],
    [-16.0, 9.0, 1.0, 2.5],
    [19.0, 7.0, 2.0, 0.8],
    [-21.0, -15.0, 2.8, 0.8]
]

var port := DEFAULT_PORT
var supabase_url := ""
var supabase_anon_key := ""
var tick_accumulator := 0.0
var match_elapsed := 0.0
var zone_damage_accumulator := 0.0
var next_entity_id := 1
var players: Dictionary = {} # peer_id -> server-owned player state
var uid_to_peer: Dictionary = {} # Supabase UID -> peer_id
var pending_auth: Dictionary = {} # peer_id -> HTTPRequest
var loot_items: Dictionary = {} # loot_id -> server-owned pickup state

func _ready() -> void:
    port = _read_port()
    supabase_url = OS.get_environment("SUPABASE_URL").trim_suffix("/")
    supabase_anon_key = OS.get_environment("SUPABASE_ANON_KEY")
    if supabase_url.is_empty() or supabase_anon_key.is_empty():
        push_error("Set SUPABASE_URL and SUPABASE_ANON_KEY environment variables before starting the server.")
        get_tree().quit(2)
        return

    _reset_loot()
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(port, MAX_PLAYERS)
    if err != OK:
        push_error("Could not start ENet server on port %d (error %d)." % [port, err])
        get_tree().quit(3)
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    print("Shadow Royale dedicated server listening on UDP %d; max players=%d" % [port, MAX_PLAYERS])

func _read_port() -> int:
    var raw := OS.get_environment("GAME_PORT")
    if raw.is_valid_int():
        return clampi(int(raw), 1024, 65535)
    return DEFAULT_PORT

func _on_peer_connected(peer_id: int) -> void:
    print("Peer connected, awaiting Supabase token: ", peer_id)
    # Client must call client_hello(access_token) next. It is not accepted as a player yet.

@rpc("any_peer", "call_remote", "reliable")
func client_hello(access_token: String) -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if peer_id <= 0 or not multiplayer.is_server():
        return
    if players.has(peer_id) or pending_auth.has(peer_id):
        _reject_peer(peer_id, "duplicate_auth")
        return
    if access_token.length() < 20 or access_token.length() > 4096:
        _reject_peer(peer_id, "invalid_token_shape")
        return
    if supabase_url.is_empty() or supabase_anon_key.is_empty():
        _reject_peer(peer_id, "auth_unconfigured")
        return

    var req := HTTPRequest.new()
    req.timeout = 8.0
    add_child(req)
    pending_auth[peer_id] = req
    req.request_completed.connect(_on_auth_completed.bind(peer_id, req), CONNECT_ONE_SHOT)
    var headers := PackedStringArray([
        "apikey: " + supabase_anon_key,
        "Authorization: Bearer " + access_token,
        "Accept: application/json"
    ])
    var err := req.request(supabase_url + "/auth/v1/user", headers, HTTPClient.METHOD_GET)
    if err != OK:
        pending_auth.erase(peer_id)
        req.queue_free()
        _reject_peer(peer_id, "auth_request_failed")

func _on_auth_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray, peer_id: int, req: HTTPRequest) -> void:
    pending_auth.erase(peer_id)
    if is_instance_valid(req):
        req.queue_free()
    if multiplayer.multiplayer_peer == null or multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_DISCONNECTED:
        return
    # Ignore late HTTP responses for peers that disconnected while auth was pending.
    if not multiplayer.get_peers().has(peer_id):
        return
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        _reject_peer(peer_id, "auth_rejected")
        return
    var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
    if not parsed is Dictionary or not parsed.has("id"):
        _reject_peer(peer_id, "bad_auth_response")
        return
    var user_id := str(parsed["id"])
    if uid_to_peer.has(user_id):
        _reject_peer(peer_id, "account_already_in_match")
        return
    if players.size() >= MAX_PLAYERS:
        _reject_peer(peer_id, "match_full")
        return

    var entity_id := next_entity_id
    next_entity_id += 1
    players[peer_id] = {
        "entity_id": entity_id,
        # Prototype auto-assigns squads in groups of four. Production matchmaking
        # must replace this with the party/matchmaking service's verified team ID.
        "team_id": int((entity_id - 1) / 4) + 1,
        "user_id": user_id,
        "position": _find_spawn_position(),
        "health": 100.0,
        "kills": 0,
        "deaths": 0,
        "last_shot_at": 0,
        "respawn_at": 0,
        "last_input_seq": -1,
        "last_input_at": Time.get_ticks_msec(),
        "ammo": 0,
        "magazine": MAGAZINE_SIZE,
        "reload_until": 0,
        "medkits": 0,
        "revive_target_peer": -1,
        "revive_started_at": 0
    }
    uid_to_peer[user_id] = peer_id
    rpc_id(peer_id, "auth_accepted", entity_id)
    _send_snapshot_to_all()
    print("Authenticated player joined: entity=%d peer=%d" % [entity_id, peer_id])

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_movement(input_seq: int, move_x: float, move_z: float) -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if not players.has(peer_id):
        return
    var state: Dictionary = players[peer_id]
    if float(state["health"]) <= 0.0 or int(state["respawn_at"]) > 0:
        return
    if input_seq <= int(state["last_input_seq"]):
        return
    if not is_finite(move_x) or not is_finite(move_z):
        return
    var input := Vector2(move_x, move_z)
    if input.length() > 1.05:
        input = input.normalized()
    input = input.limit_length(1.0)
    var now := Time.get_ticks_msec()
    var elapsed := clampf(float(now - int(state["last_input_at"])) / 1000.0, 0.0, 0.1)
    state["last_input_at"] = now
    state["last_input_seq"] = input_seq
    var pos: Vector3 = state["position"]
    var candidate_x := pos.x + input.x * MOVE_SPEED * elapsed
    var candidate_z := pos.z + input.y * MOVE_SPEED * elapsed
    # Resolve each axis independently so players can slide along cover instead of sticking.
    if not _blocked_by_cover(candidate_x, pos.z, PLAYER_RADIUS):
        pos.x = clampf(candidate_x, -MAP_LIMIT, MAP_LIMIT)
    if not _blocked_by_cover(pos.x, candidate_z, PLAYER_RADIUS):
        pos.z = clampf(candidate_z, -MAP_LIMIT, MAP_LIMIT)
    state["position"] = pos
    players[peer_id] = state


@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_shot(aim_x: float, aim_z: float) -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if not players.has(peer_id):
        return
    var shooter: Dictionary = players[peer_id]
    var now := Time.get_ticks_msec()
    if float(shooter["health"]) <= 0.0 or now < int(shooter["respawn_at"]):
        return
    if now - int(shooter["last_shot_at"]) < SHOT_COOLDOWN_MS:
        return
    if int(shooter.get("reload_until", 0)) > now or int(shooter.get("magazine", MAGAZINE_SIZE)) <= 0:
        return
    if not is_finite(aim_x) or not is_finite(aim_z):
        return
    var aim := Vector2(aim_x, aim_z)
    if aim.length() < 0.8 or aim.length() > 1.2:
        return
    aim = aim.normalized()
    shooter["last_shot_at"] = now
    shooter["magazine"] = maxi(0, int(shooter.get("magazine", MAGAZINE_SIZE)) - 1)
    players[peer_id] = shooter

    # Server-side hitscan: nearest living player in a narrow forward cone wins.
    # This is intentionally simple until collision-world/weapon spread is integrated.
    var shooter_pos: Vector3 = shooter["position"]
    var best_peer := -1
    var best_distance := SHOT_RANGE + 1.0
    for target_variant in players.keys():
        var target_peer := int(target_variant)
        if target_peer == peer_id:
            continue
        var target: Dictionary = players[target_peer]
        if float(target["health"]) <= 0.0:
            continue
        # Prevent friendly fire in the prototype's auto-assigned squads.
        if int(target.get("team_id", -1)) == int(shooter.get("team_id", -2)):
            continue
        var target_pos: Vector3 = target["position"]
        var offset := Vector2(target_pos.x - shooter_pos.x, target_pos.z - shooter_pos.z)
        var distance := offset.length()
        if distance < 0.1 or distance > SHOT_RANGE:
            continue
        if aim.dot(offset / distance) < 0.94:
            continue
        if distance < best_distance:
            best_distance = distance
            best_peer = target_peer
    if best_peer < 0:
        return
    var target_state: Dictionary = players[best_peer]
    var target_pos: Vector3 = target_state["position"]
    if _shot_blocked(shooter_pos, target_pos):
        return

    var victim: Dictionary = players[best_peer]
    victim["health"] = maxf(0.0, float(victim["health"]) - SHOT_DAMAGE)
    if float(victim["health"]) <= 0.0:
        victim["deaths"] = int(victim["deaths"]) + 1
        victim["respawn_at"] = now + RESPAWN_DELAY_MS
        shooter["kills"] = int(shooter["kills"]) + 1
        players[peer_id] = shooter
        print("Elimination: attacker=%d victim=%d" % [peer_id, best_peer])
    players[best_peer] = victim
    _send_snapshot_to_all()


@rpc("any_peer", "call_remote", "reliable")
func request_reload() -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if not players.has(peer_id):
        return
    var state: Dictionary = players[peer_id]
    var now := Time.get_ticks_msec()
    if float(state["health"]) <= 0.0 or int(state["respawn_at"]) > 0:
        return
    if int(state.get("reload_until", 0)) > now:
        return
    var magazine := int(state.get("magazine", MAGAZINE_SIZE))
    var reserve := int(state.get("ammo", 0))
    if magazine >= MAGAZINE_SIZE or reserve <= 0:
        rpc_id(peer_id, "reload_result", false, "magazine_full_or_no_reserve")
        return
    state["reload_until"] = now + RELOAD_DURATION_MS
    players[peer_id] = state
    rpc_id(peer_id, "reload_result", true, "reloading")

func _complete_reloads() -> void:
    var now := Time.get_ticks_msec()
    for peer_variant in players.keys():
        var state: Dictionary = players[peer_variant]
        var reload_until := int(state.get("reload_until", 0))
        if reload_until <= 0 or now < reload_until:
            continue
        var needed := maxi(0, MAGAZINE_SIZE - int(state.get("magazine", MAGAZINE_SIZE)))
        var reserve := int(state.get("ammo", 0))
        var loaded := mini(needed, reserve)
        state["magazine"] = int(state.get("magazine", MAGAZINE_SIZE)) + loaded
        state["ammo"] = reserve - loaded
        state["reload_until"] = 0
        players[peer_variant] = state
        rpc_id(int(peer_variant), "reload_result", true, "reload_complete")

@rpc("any_peer", "call_remote", "reliable")
func request_revive(target_entity_id: int) -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if not players.has(peer_id):
        return
    var reviver: Dictionary = players[peer_id]
    if float(reviver["health"]) <= 0.0 or int(reviver["respawn_at"]) > 0:
        return
    var target_peer := -1
    for candidate_peer_variant in players.keys():
        var candidate_peer := int(candidate_peer_variant)
        var candidate: Dictionary = players[candidate_peer]
        if int(candidate.get("entity_id", -1)) == target_entity_id:
            target_peer = candidate_peer
            break
    if target_peer < 0 or target_peer == peer_id:
        rpc_id(peer_id, "revive_result", false, "target_not_found")
        return
    var target: Dictionary = players[target_peer]
    if int(reviver.get("team_id", -1)) != int(target.get("team_id", -2)):
        rpc_id(peer_id, "revive_result", false, "teammates_only")
        return
    var now := Time.get_ticks_msec()
    if float(target["health"]) > 0.0 or int(target["respawn_at"]) <= now:
        return
    var reviver_pos: Vector3 = reviver["position"]
    var target_pos: Vector3 = target["position"]
    if Vector2(reviver_pos.x - target_pos.x, reviver_pos.z - target_pos.z).length() > REVIVE_RANGE:
        return
    reviver["revive_target_peer"] = target_peer
    reviver["revive_started_at"] = now
    players[peer_id] = reviver

func _process_revives() -> void:
    var now := Time.get_ticks_msec()
    for peer_variant in players.keys():
        var reviver_peer := int(peer_variant)
        var reviver: Dictionary = players[reviver_peer]
        var target_peer := int(reviver.get("revive_target_peer", -1))
        var started_at := int(reviver.get("revive_started_at", 0))
        if target_peer < 0 or started_at <= 0:
            continue
        if not players.has(target_peer) or float(reviver["health"]) <= 0.0 or int(reviver["respawn_at"]) > 0:
            reviver["revive_target_peer"] = -1
            reviver["revive_started_at"] = 0
            players[reviver_peer] = reviver
            continue
        var target: Dictionary = players[target_peer]
        var reviver_pos: Vector3 = reviver["position"]
        var target_pos: Vector3 = target["position"]
        var in_range := Vector2(reviver_pos.x - target_pos.x, reviver_pos.z - target_pos.z).length() <= REVIVE_RANGE
        if float(target["health"]) > 0.0 or int(target["respawn_at"]) <= now or not in_range:
            reviver["revive_target_peer"] = -1
            reviver["revive_started_at"] = 0
            players[reviver_peer] = reviver
            continue
        if now - started_at >= REVIVE_DURATION_MS:
            target["health"] = REVIVE_HEALTH
            target["respawn_at"] = 0
            target["reload_until"] = 0
            players[target_peer] = target
            reviver["revive_target_peer"] = -1
            reviver["revive_started_at"] = 0
            players[reviver_peer] = reviver
            rpc_id(reviver_peer, "revive_result", true, "revive_complete")
            rpc_id(target_peer, "revive_result", true, "revived_with_45_hp")
            print("Revive complete: reviver=%d target=%d" % [reviver_peer, target_peer])

@rpc("any_peer", "call_remote", "reliable")
func request_pickup(loot_id: String) -> void:
    var peer_id := multiplayer.get_remote_sender_id()
    if not players.has(peer_id) or not loot_items.has(loot_id):
        return
    var state: Dictionary = players[peer_id]
    if float(state["health"]) <= 0.0 or int(state["respawn_at"]) > 0:
        return
    var loot: Dictionary = loot_items[loot_id]
    var player_pos: Vector3 = state["position"]
    var loot_pos: Vector3 = loot["position"]
    if Vector2(player_pos.x - loot_pos.x, player_pos.z - loot_pos.z).length() > PICKUP_RANGE:
        return
    # All rewards are granted here on the server, never from client-supplied amounts.
    match str(loot["kind"]):
        "medkit":
            if float(state["health"]) >= 100.0:
                rpc_id(peer_id, "pickup_result", false, "health_full")
                return
            state["health"] = minf(100.0, float(state["health"]) + float(loot["amount"]))
            state["medkits"] = int(state["medkits"]) + 1
        "ammo":
            state["ammo"] = mini(999, int(state["ammo"]) + int(loot["amount"]))
        _:
            return
    players[peer_id] = state
    loot_items.erase(loot_id)
    rpc_id(peer_id, "pickup_result", true, str(loot["kind"]))
    _send_snapshot_to_all()

func _reset_loot() -> void:
    loot_items.clear()
    for definition_variant in LOOT_DEFINITIONS:
        var definition: Dictionary = definition_variant
        loot_items[str(definition["id"])] = definition.duplicate(true)


func _blocked_by_cover(x: float, z: float, radius: float) -> bool:
    for rect_variant in COVER_RECTS:
        var rect: Array = rect_variant
        if absf(x - float(rect[0])) <= float(rect[2]) + radius and absf(z - float(rect[1])) <= float(rect[3]) + radius:
            return true
    return false

func _shot_blocked(from_pos: Vector3, to_pos: Vector3) -> bool:
    var start := Vector2(from_pos.x, from_pos.z)
    var finish := Vector2(to_pos.x, to_pos.z)
    var distance := start.distance_to(finish)
    var steps := maxi(1, int(ceil(distance / 0.35)))
    for i in range(1, steps):
        var point := start.lerp(finish, float(i) / float(steps))
        if _point_inside_cover(point.x, point.y):
            return true
    return false

func _point_inside_cover(x: float, z: float) -> bool:
    for rect_variant in COVER_RECTS:
        var rect: Array = rect_variant
        if absf(x - float(rect[0])) <= float(rect[2]) and absf(z - float(rect[1])) <= float(rect[3]):
            return true
    return false

func _process(delta: float) -> void:
    match_elapsed += delta
    tick_accumulator += delta
    if tick_accumulator < 1.0 / TICK_RATE:
        return
    tick_accumulator = 0.0
    _process_respawns()
    _complete_reloads()
    _process_revives()
    _process_shrinking_zone(delta)
    _send_snapshot_to_all()

func _process_respawns() -> void:
    var now := Time.get_ticks_msec()
    var changed := false
    for peer_variant in players.keys():
        var state: Dictionary = players[peer_variant]
        var respawn_at := int(state["respawn_at"])
        if respawn_at > 0 and now >= respawn_at:
            state["position"] = _find_spawn_position()
            state["health"] = 100.0
            state["respawn_at"] = 0
            players[peer_variant] = state
            changed = true
    if changed:
        print("One or more players respawned")

func _find_spawn_position() -> Vector3:
    # Avoid spawning inside cover or directly on top of another active player.
    for attempt in range(40):
        var candidate := Vector3(randf_range(-42.0, 42.0), 0.0, randf_range(-42.0, 42.0))
        if _blocked_by_cover(candidate.x, candidate.z, PLAYER_RADIUS):
            continue
        var occupied := false
        for state_variant in players.values():
            var existing: Dictionary = state_variant
            var existing_pos: Vector3 = existing.get("position", Vector3(9999, 0, 9999))
            if existing_pos.distance_to(candidate) < 3.0 and float(existing.get("health", 0.0)) > 0.0:
                occupied = true
                break
        if not occupied:
            return candidate
    return Vector3(randf_range(-60.0, 60.0), 0.0, randf_range(-60.0, 60.0))

func _current_zone_radius() -> float:
    var progress := clampf(match_elapsed / ZONE_SHRINK_SECONDS, 0.0, 1.0)
    return lerpf(ZONE_START_RADIUS, ZONE_END_RADIUS, progress)

func _process_shrinking_zone(delta: float) -> void:
    zone_damage_accumulator += delta
    if zone_damage_accumulator < 1.0:
        return
    var damage_ticks := int(zone_damage_accumulator)
    zone_damage_accumulator -= float(damage_ticks)
    var radius := _current_zone_radius()
    for peer_variant in players.keys():
        var state: Dictionary = players[peer_variant]
        if float(state["health"]) <= 0.0 or int(state["respawn_at"]) > 0:
            continue
        var pos: Vector3 = state["position"]
        if Vector2(pos.x, pos.z).length() > radius:
            state["health"] = maxf(0.0, float(state["health"]) - ZONE_DAMAGE_PER_SECOND * float(damage_ticks))
            if float(state["health"]) <= 0.0:
                state["deaths"] = int(state["deaths"]) + 1
                state["respawn_at"] = Time.get_ticks_msec() + RESPAWN_DELAY_MS
            players[peer_variant] = state

func _loot_snapshot() -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for loot_variant in loot_items.values():
        var loot: Dictionary = loot_variant
        var pos: Vector3 = loot["position"]
        result.append({"id": loot["id"], "kind": loot["kind"], "position": [pos.x, pos.y, pos.z]})
    return result

func _send_snapshot_to_all() -> void:
    if players.is_empty():
        return
    var snapshot: Array[Dictionary] = []
    for peer_variant in players.keys():
        var state: Dictionary = players[peer_variant]
        var p: Vector3 = state["position"]
        snapshot.append({
            "entity_id": state["entity_id"],
            "team_id": state.get("team_id", 0),
            "position": [p.x, p.y, p.z],
            "health": state["health"],
            "kills": state["kills"],
            "deaths": state["deaths"],
            "ammo": state.get("ammo", 0),
            "magazine": state.get("magazine", MAGAZINE_SIZE),
            "reloading": int(state.get("reload_until", 0)) > Time.get_ticks_msec(),
            "medkits": state.get("medkits", 0),
            "respawn_in_ms": maxi(0, int(state["respawn_at"]) - Time.get_ticks_msec()),
            "zone_radius": _current_zone_radius(),
            "zone_time_remaining": maxi(0, int(ceil(ZONE_SHRINK_SECONDS - match_elapsed))),
            "loot": _loot_snapshot()
        })
    for peer_variant in players.keys():
        rpc_id(int(peer_variant), "receive_snapshot", snapshot)

@rpc("authority", "call_remote", "reliable")
func reload_result(_success: bool, _result: String) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

@rpc("authority", "call_remote", "reliable")
func revive_result(_success: bool, _result: String) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

@rpc("authority", "call_remote", "reliable")
func pickup_result(_success: bool, _result: String) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

@rpc("authority", "call_remote", "reliable")
func auth_accepted(_entity_id: int) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_snapshot(_snapshot: Array) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

@rpc("authority", "call_remote", "reliable")
func auth_rejected(_reason: String) -> void:
    pass # Implemented by the client script; placeholder keeps RPC signature documented.

func _reject_peer(peer_id: int, reason: String) -> void:
    if multiplayer.multiplayer_peer:
        rpc_id(peer_id, "auth_rejected", reason)
        multiplayer.multiplayer_peer.disconnect_peer(peer_id)
    print("Rejected peer %d: %s" % [peer_id, reason])

func _on_peer_disconnected(peer_id: int) -> void:
    if pending_auth.has(peer_id):
        var req: HTTPRequest = pending_auth[peer_id]
        pending_auth.erase(peer_id)
        if is_instance_valid(req):
            req.queue_free()
    if players.has(peer_id):
        var state: Dictionary = players[peer_id]
        uid_to_peer.erase(str(state["user_id"]))
        players.erase(peer_id)
        for other_peer_variant in players.keys():
            var other_peer := int(other_peer_variant)
            var other_state: Dictionary = players[other_peer]
            if int(other_state.get("revive_target_peer", -1)) == peer_id:
                other_state["revive_target_peer"] = -1
                other_state["revive_started_at"] = 0
                players[other_peer] = other_state
        _send_snapshot_to_all()
        print("Player left match: peer=%d" % peer_id)
