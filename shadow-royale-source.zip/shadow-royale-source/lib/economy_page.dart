import 'package:flutter/material.dart';

const _neon = Color(0xFFB8FF39);
const _bg = Color(0xFF080D12);
const _panel = Color(0xFF121B22);

/// Prime thresholds are display/config defaults only. The server must be the
/// source of truth for qualifying verified purchases and reward claims.
const primeTiers = <PrimeTier>[
  PrimeTier('Shadow Prime I', 100, 'Initiate', 'Profile badge'),
  PrimeTier('Shadow Prime II', 1000, 'Veil Walker', 'Profile frame'),
  PrimeTier('Shadow Prime III', 5000, 'Night Stalker', 'Banner cosmetic'),
  PrimeTier('Shadow Prime IV', 15000, 'Eclipse Hunter', 'Emote cosmetic'),
  PrimeTier('Shadow Prime V', 30000, 'Void Vanguard', 'Lobby effect cosmetic'),
  PrimeTier('Shadow Prime VI', 60000, 'Dusk Sovereign', 'Premium title cosmetic'),
  PrimeTier('Shadow Prime VII', 100000, 'Astral Warden', 'Exclusive cosmetic set'),
  PrimeTier('Shadow Prime VIII', 200000, 'Eclipse Eternal', 'Maximum-tier cosmetic bundle'),
];

class PrimeTier {
  const PrimeTier(this.name, this.threshold, this.title, this.rewardPreview);
  final String name;
  final int threshold;
  final String title;
  final String rewardPreview;
}

/// Pure tier mapping for server-side parity and unit tests. Callers must only
/// pass a trusted qualifying total; client input is not purchase evidence.
int primeTierForQualifyingTotal(int total) {
  if (total <= 0) return 0;
  for (var i = primeTiers.length - 1; i >= 0; i--) {
    if (total >= primeTiers[i].threshold) return i + 1;
  }
  return 0;
}

/// A non-purchasable economy preview until authenticated backend + official
/// billing receipt verification are connected.
class EconomyPage extends StatelessWidget {
  const EconomyPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ECONOMY & SHADOW PRIME')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _neon.withValues(alpha: .55)),
                gradient: const LinearGradient(
                  colors: [Color(0xFF2B3A27), Color(0xFF121B22)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.diamond_outlined, color: _neon, size: 36),
                  SizedBox(height: 12),
                  Text('ECLIPSE GEMS', style: TextStyle(color: _neon, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                  SizedBox(height: 6),
                  Text('Top-Up Center', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                  SizedBox(height: 8),
                  Text('Purchase is currently unavailable. Connect official store billing and a trusted verification backend before enabling real-money transactions.', style: TextStyle(color: Colors.white70, height: 1.4)),
                  SizedBox(height: 12),
                  Chip(avatar: Icon(Icons.lock_outline, size: 17), label: Text('PREVIEW ONLY • NO PURCHASES')),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Text('YOUR CURRENCIES', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
            const SizedBox(height: 8),
            const Row(children: [
              Expanded(child: _CurrencyCard(icon: Icons.diamond, name: 'Eclipse Gems', value: 'Server unavailable')),
              SizedBox(width: 8),
              Expanded(child: _CurrencyCard(icon: Icons.monetization_on, name: 'Royale Gold', value: 'Local profile only')),
            ]),
            const SizedBox(height: 8),
            const _CurrencyCard(icon: Icons.token, name: 'Rift Tokens', value: 'Event service unavailable'),
            const SizedBox(height: 22),
            const Text('SHADOW PRIME • 8 TIERS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
            const SizedBox(height: 6),
            const Text('Progress is based on cumulative, settled and platform-verified qualifying top-ups—not the current gem balance. This preview does not calculate or award a live tier.', style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.4)),
            const SizedBox(height: 10),
            ...primeTiers.asMap().entries.map((entry) {
              final index = entry.key;
              final tier = entry.value;
              final isMaximum = index == primeTiers.length - 1;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: _panel,
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: isMaximum ? _neon.withValues(alpha: .7) : Colors.white12),
                ),
                child: Row(children: [
                  Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(color: isMaximum ? _neon.withValues(alpha: .15) : Colors.white10, borderRadius: BorderRadius.circular(10)), child: Icon(isMaximum ? Icons.workspace_premium : Icons.shield_outlined, color: _neon)),
                  const SizedBox(width: 11),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(tier.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text('${tier.title} • ${tier.rewardPreview}', style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    const SizedBox(height: 3),
                    Text('${tier.threshold.toString()} qualifying Eclipse Gems', style: const TextStyle(color: _neon, fontSize: 11, fontWeight: FontWeight.w700)),
                  ])),
                  if (isMaximum) const Icon(Icons.stars, color: _neon),
                ]),
              );
            }),
            const SizedBox(height: 4),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(12)), child: const Text('IMPORTANT: Shadow Prime VIII is the maximum tier at 200,000 qualifying Eclipse Gems. Totals above 200,000 remain Prime VIII; there is no Prime IX. Spending gems does not reduce Prime tier. Refund/chargeback rules must be enforced by the server.', style: TextStyle(fontSize: 12, color: Colors.white70, height: 1.45))),
            const SizedBox(height: 12),
            const Text('Before launch: add Google Play Billing, backend receipt verification, immutable currency ledger, purchase history, refund reconciliation, server-configured regional catalog and audited reward claims. No paid currency or Prime status can be granted by this client.', style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.4)),
          ],
        ),
      );
}

class _CurrencyCard extends StatelessWidget {
  const _CurrencyCard({required this.icon, required this.name, required this.value});
  final IconData icon;
  final String name;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(13), border: Border.all(color: Colors.white10)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: _neon, size: 22),
          const SizedBox(height: 8),
          Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white54, fontSize: 10)),
        ]),
      );
}
