import 'dart:math' as math;
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'economy_page.dart';
import 'ranked_page.dart';

void main() => runApp(const ShadowRoyaleApp());

const neon = Color(0xFFB8FF39);
const bg = Color(0xFF080D12);
const panel = Color(0xFF121B22);

class ShadowRoyaleApp extends StatelessWidget {
  const ShadowRoyaleApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Shadow Royale',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: neon, brightness: Brightness.dark),
          fontFamily: 'Roboto'),
        home: const LobbyPage(),
      );
}

class GameMode {
  const GameMode(this.title, this.subtitle, this.icon, this.onlineOnly);
  final String title, subtitle;
  final IconData icon;
  final bool onlineOnly;
}

const modes = <GameMode>[
  GameMode('BATTLE ROYALE', 'Survive until the end', Icons.public, false),
  GameMode('BR RANKED', 'Competitive rank climb', Icons.workspace_premium, true),
  GameMode('CLASSIC', 'Casual battle', Icons.sports_esports, false),
  GameMode('CLASSIC RANKED', 'Competitive classic', Icons.military_tech, true),
  GameMode('LONE WOLF', '1 vs 1 arena duel', Icons.person, false),
  GameMode('TRAINING GROUND', 'Practice aim and movement', Icons.gps_fixed, false),
];

class LobbyPage extends StatefulWidget {
  const LobbyPage({super.key});
  @override
  State<LobbyPage> createState() => _LobbyPageState();
}

class _LobbyPageState extends State<LobbyPage> {
  int selectedMode = 0;
  int tab = 0;
  String uid = 'SR-LOADING';

  @override
  void initState() {
    super.initState();
    _loadLocalIdentity();
  }

  Future<void> _loadLocalIdentity() async {
    final prefs = await SharedPreferences.getInstance();
    var savedUid = prefs.getString('sr_local_uid');
    if (savedUid == null) {
      savedUid = 'SR-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
      await prefs.setString('sr_local_uid', savedUid);
    }
    if (mounted) setState(() => uid = savedUid!);
  }

  void _start() {
    final mode = modes[selectedMode];
    if (mode.onlineOnly) {
      showDialog<void>(context: context, builder: (context) => AlertDialog(
        backgroundColor: panel,
        icon: const Icon(Icons.build_circle_outlined, color: neon, size: 38),
        title: const Text('ONLINE MODE IN MAINTENANCE'),
        content: Text('${mode.title} is temporarily unavailable. Online play, matchmaking and global ranked points are disabled while offline gameplay is being completed.', style: const TextStyle(color: Colors.white70)),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('GOT IT')), FilledButton(onPressed: () { Navigator.pop(context); setState(() => selectedMode = 0); }, child: const Text('PLAY OFFLINE'))],
      ));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ArenaPage(mode: mode.title)));
  }

  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Stack(children: [
        const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF172A30), bg, bg])))),
        ListView(padding: const EdgeInsets.fromLTRB(16, 10, 16, 100), children: [
          Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: neon, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.shield_moon, color: bg, size: 28)),
            const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('SHADOW ROYALE', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.4, color: neon)), Text('SURVIVE • ADAPT • DOMINATE', style: TextStyle(fontSize: 9, letterSpacing: 1.3, color: Colors.white70))])),
            IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsPage())), icon: const Icon(Icons.settings_outlined)),
          ]),
          const SizedBox(height: 16),
          _heroCard(),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: _stat('UID', uid, Icons.badge_outlined)), const SizedBox(width: 8), Expanded(child: _stat('RANK', 'UNRANKED', Icons.military_tech))]),
          const SizedBox(height: 18),
          Row(children: [const Expanded(child: Text('CHOOSE OFFLINE MODE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 15))), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: const Color(0xFF25331D), borderRadius: BorderRadius.circular(20), border: Border.all(color: neon.withValues(alpha: .5))), child: const Row(children: [Icon(Icons.wifi_off, size: 13, color: neon), SizedBox(width: 5), Text('OFFLINE ONLY', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: neon))]))]),
          const SizedBox(height: 10),
          GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: modes.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 1.55), itemBuilder: (context, i) {
            final m = modes[i]; final active = selectedMode == i; final unavailable = m.onlineOnly;
            return InkWell(borderRadius: BorderRadius.circular(14), onTap: () { if (unavailable) { _message('${m.title} is in maintenance. Choose an offline mode to play.'); } else { setState(() => selectedMode = i); } }, child: AnimatedContainer(duration: const Duration(milliseconds: 160), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: active ? const Color(0xFF26351B) : panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: active ? neon : (unavailable ? const Color(0xFF7B6332) : Colors.white12), width: active ? 1.5 : 1)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Row(children: [Icon(m.icon, color: unavailable ? const Color(0xFFFFD27A) : (active ? neon : Colors.white70), size: 23), const Spacer(), if (unavailable) const Icon(Icons.build_circle_outlined, color: Color(0xFFFFD27A), size: 16)]), Text(m.title, maxLines: 2, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: unavailable ? const Color(0xFFFFD27A) : (active ? neon : Colors.white))), Text(unavailable ? 'TEMPORARILY UNAVAILABLE' : m.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, color: Colors.white60))])));
          }),
          const SizedBox(height: 14),
          SizedBox(height: 54, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: neon, foregroundColor: bg, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), onPressed: _start, icon: const Icon(Icons.play_arrow_rounded, size: 29), label: const Text('START OFFLINE MATCH', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0))),),
          const SizedBox(height: 10),
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF2A2117), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF6A5427))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.build_circle_outlined, color: Color(0xFFFFD27A), size: 20), SizedBox(width: 9), Expanded(child: Text('ONLINE MULTIPLAYER IS IN MAINTENANCE. Matchmaking, online ranked and remote rooms are switched off for now. Offline modes remain available.', style: TextStyle(color: Color(0xFFFFD98B), fontSize: 11, height: 1.35)))])),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CustomRoomPage())), icon: const Icon(Icons.groups_2_outlined), label: const Text('CUSTOM ROOM'))), const SizedBox(width: 9), Expanded(child: OutlinedButton.icon(onPressed: () => _showEmotes(context), icon: const Icon(Icons.emoji_emotions_outlined), label: const Text('EMOTES')))]),
          const SizedBox(height: 9),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EconomyPage())),
            icon: const Icon(Icons.diamond_outlined, color: neon),
            label: const Text('ECLIPSE GEMS • TOP-UP • SHADOW PRIME'),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Color(0xFF526B3A)), padding: const EdgeInsets.symmetric(vertical: 14)),
          )),
          const SizedBox(height: 18),
          const Text('WORLD OF VEYLORA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
          const SizedBox(height: 8),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)), child: const Row(children: [Icon(Icons.landscape, size: 36, color: neon), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('VEYLORA ISLAND', style: TextStyle(fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Fictional island • forests • coast • industrial zone • hidden loot', style: TextStyle(fontSize: 11, color: Colors.white60))])), Icon(Icons.chevron_right)])),
          const SizedBox(height: 18),
          const Text('FEATURES', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)), const SizedBox(height: 9),
          Wrap(spacing: 7, runSpacing: 7, children: const [FeatureChip('Character Skills'), FeatureChip('Weapons & Skins'), FeatureChip('Pets'), FeatureChip('Events'), FeatureChip('Missions'), FeatureChip('Season Pass'), FeatureChip('Guilds'), FeatureChip('Leaderboard'), FeatureChip('Supply Drops'), FeatureChip('Squad / Duo')]),
        ]),
        Positioned(left: 0, right: 0, bottom: 0, child: Container(decoration: const BoxDecoration(color: Color(0xF20B1117), border: Border(top: BorderSide(color: Colors.white12))), padding: const EdgeInsets.symmetric(vertical: 9), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [ _nav(Icons.home_filled, 'HOME', 0), _nav(Icons.workspace_premium, 'RANK', 1), _nav(Icons.people_alt_outlined, 'TEAM', 2), _nav(Icons.event, 'EVENTS', 3), _nav(Icons.person_outline, 'PROFILE', 4)])))
      ])),
    );
  }

  Widget _heroCard() => Container(height: 155, padding: const EdgeInsets.all(16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: neon.withValues(alpha: .5)), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF30442A), Color(0xFF142329), Color(0xFF10151B)])), child: Stack(children: [const Positioned(right: 2, top: 4, child: Icon(Icons.shield_moon, size: 105, color: Color(0x334DFF61))), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('SEASON 01', style: TextStyle(color: neon, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('RISE FROM\nTHE SHADOWS', style: TextStyle(fontSize: 23, height: 1.0, fontWeight: FontWeight.w900)), const Spacer(), Row(children: [const Icon(Icons.circle, size: 8, color: neon), const SizedBox(width: 6), const Text('OFFLINE MODE READY', style: const TextStyle(fontSize: 10, color: Colors.white70)), const Spacer(), const Text('01 / 08', style: TextStyle(fontSize: 10, color: Colors.white54))])]) ]));

  Widget _stat(String title, String value, IconData icon) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)), child: Row(children: [Icon(icon, color: neon, size: 19), const SizedBox(width: 8), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 9, color: Colors.white54)), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]))]));
  Widget _nav(IconData icon, String label, int index) => InkWell(onTap: () { setState(() => tab = index); if (label == 'RANK') { Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RankedPage())); } else if (index != 0) { Navigator.of(context).push(MaterialPageRoute(builder: (_) => FeatureHubPage(section: label))); } }, child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 20, color: tab == index ? neon : Colors.white54), const SizedBox(height: 3), Text(label, style: TextStyle(fontSize: 8, color: tab == index ? neon : Colors.white54, fontWeight: FontWeight.bold))]));
  void _showEmotes(BuildContext context) => showModalBottomSheet<void>(context: context, backgroundColor: panel, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('EMOTE WHEEL', style: TextStyle(fontWeight: FontWeight.w900, color: neon, letterSpacing: 1)), const SizedBox(height: 14), Wrap(spacing: 10, runSpacing: 10, children: ['Dance', 'LOL', 'Laugh', 'Clap', 'Taunt', 'Victory'].map((e) => ActionChip(avatar: const Icon(Icons.emoji_emotions_outlined, size: 18), label: Text(e), onPressed: () { Navigator.pop(context); _message('$e selected. Character animations are planned for the 3D gameplay stage.'); })).toList())]))));
}


class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  double sensitivity = 55;
  double music = 35;
  double effects = 75;
  bool vibration = true;
  bool autoReload = true;
  bool leftHanded = false;
  bool reducedMotion = false;
  String graphics = 'Balanced';
  String fps = '60 FPS';
  bool settingsLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      sensitivity = prefs.getDouble('sr_sensitivity') ?? sensitivity;
      music = prefs.getDouble('sr_music') ?? music;
      effects = prefs.getDouble('sr_effects') ?? effects;
      vibration = prefs.getBool('sr_vibration') ?? vibration;
      autoReload = prefs.getBool('sr_auto_reload') ?? autoReload;
      leftHanded = prefs.getBool('sr_left_handed') ?? leftHanded;
      reducedMotion = prefs.getBool('sr_reduced_motion') ?? reducedMotion;
      graphics = prefs.getString('sr_graphics') ?? graphics;
      fps = prefs.getString('sr_fps') ?? fps;
      settingsLoaded = true;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('sr_sensitivity', sensitivity);
    await prefs.setDouble('sr_music', music);
    await prefs.setDouble('sr_effects', effects);
    await prefs.setBool('sr_vibration', vibration);
    await prefs.setBool('sr_auto_reload', autoReload);
    await prefs.setBool('sr_left_handed', leftHanded);
    await prefs.setBool('sr_reduced_motion', reducedMotion);
    await prefs.setString('sr_graphics', graphics);
    await prefs.setString('sr_fps', fps);
  }

  Widget _section(String title, List<Widget> children) => Container(
    margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white10)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: neon, fontWeight: FontWeight.w900, letterSpacing: 1)),
      const SizedBox(height: 10), ...children,
    ]),
  );

  Widget _slider(String title, double value, ValueChanged<double> onChanged) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Expanded(child: Text(title)), Text('${value.round()}%', style: const TextStyle(color: neon, fontWeight: FontWeight.bold))]),
    Slider(value: value, min: 0, max: 100, onChanged: onChanged, activeColor: neon),
  ]);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('GAME SETTINGS')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      _section('CONTROLS', [
        _slider('Aim sensitivity', sensitivity, (v) => setState(() => sensitivity = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Auto reload'), value: autoReload, activeColor: neon, onChanged: (v) => setState(() => autoReload = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Left-handed controls'), value: leftHanded, activeColor: neon, onChanged: (v) => setState(() => leftHanded = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Vibration feedback'), value: vibration, activeColor: neon, onChanged: (v) => setState(() => vibration = v)),
      ]),
      _section('AUDIO', [
        _slider('Music volume', music, (v) => setState(() => music = v)),
        _slider('Sound effects', effects, (v) => setState(() => effects = v)),
      ]),
      _section('GRAPHICS & ACCESSIBILITY', [
        const Text('Graphics quality'), const SizedBox(height: 7),
        Wrap(spacing: 8, children: ['Battery Saver', 'Balanced', 'High'].map((v) => ChoiceChip(label: Text(v), selected: graphics == v, selectedColor: neon.withValues(alpha: .2), onSelected: (_) => setState(() => graphics = v))).toList()),
        const SizedBox(height: 14), const Text('Frame-rate preference'), const SizedBox(height: 7),
        Wrap(spacing: 8, children: ['30 FPS', '60 FPS', '90 FPS'].map((v) => ChoiceChip(label: Text(v), selected: fps == v, selectedColor: neon.withValues(alpha: .2), onSelected: (_) => setState(() => fps = v))).toList()),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Reduce motion'), subtitle: const Text('Prefer less animated interface transitions'), value: reducedMotion, activeColor: neon, onChanged: (v) => setState(() => reducedMotion = v)),
      ]),
      Text(settingsLoaded ? 'Settings are saved on this device. Engine-level graphics/audio effects depend on the final game engine.' : 'Loading saved settings…', style: const TextStyle(color: Colors.white54, fontSize: 11)),
      const SizedBox(height: 12),
      FilledButton(onPressed: () async { await _saveSettings(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved on this device.'))); }, child: const Text('SAVE SETTINGS')),
    ]),
  );
}

class FeatureHubPage extends StatelessWidget {
  const FeatureHubPage({super.key, required this.section});
  final String section;
  Widget _miniStat(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text(label, style: const TextStyle(fontSize: 9, color: Colors.white54, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(value, style: const TextStyle(color: neon, fontSize: 16, fontWeight: FontWeight.w900))]);
  @override Widget build(BuildContext context) {
    if (section == 'TEAM') return const SocialHubPage();
    final Map<String, List<Map<String, String>>> data = {
      'RANK': [ {'title':'BR RANK','detail':'Unranked • server sync not connected','icon':'🏆'}, {'title':'CLASSIC RANK','detail':'Unranked • server sync not connected','icon':'🎖️'}, {'title':'SEASON 01','detail':'Rank rules preview; live season not active','icon':'⭐'}, {'title':'LEADERBOARD','detail':'Global board requires deployed backend','icon':'📊'} ],
      'TEAM': [ {'title':'PLAYER UID','detail':'Local player identity','icon':'🆔'}, {'title':'FRIENDS','detail':'Friend requests need online services','icon':'👥'}, {'title':'SQUAD / DUO','detail':'Create a local practice party','icon':'🎮'}, {'title':'GUILD / CLAN','detail':'Guild records need backend sync','icon':'🛡️'}, {'title':'CUSTOM ROOM','detail':'Create a local room or enter a room code','icon':'🔑'} ],
      'EVENTS': [ {'title':'DAILY MISSIONS','detail':'Play matches, practice aim and survive','icon':'📅'}, {'title':'WEEKLY CHALLENGES','detail':'Local challenge track','icon':'🎯'}, {'title':'SEASON PASS','detail':'Progression UI foundation','icon':'🎟️'}, {'title':'REWARDS','detail':'Claimable rewards UI foundation','icon':'🎁'}, {'title':'LIVE EVENTS','detail':'Live schedule requires backend configuration','icon':'🌐'} ],
      'PROFILE': [ {'title':'ROOKIE_01','detail':'Player profile • Local UID','icon':'👤'}, {'title':'STATISTICS','detail':'Kills, survival time and practice matches','icon':'📈'}, {'title':'INVENTORY','detail':'Weapons, outfits and emote collection UI','icon':'🎒'}, {'title':'SHOP','detail':'Spend locally earned coins on cosmetic unlocks','icon':'🛒'}, {'title':'MISSIONS','detail':'Track offline missions and claim local rewards','icon':'🎯'}, {'title':'SETTINGS','detail':'Gameplay, audio and graphics preferences UI','icon':'⚙️'}, {'title':'PRIVACY & SUPPORT','detail':'Production account support requires backend','icon':'🔒'} ],
    };
    final items = data[section] ?? data['PROFILE']!;
    return Scaffold(appBar: AppBar(title: Text(section)), body: ListView(padding: const EdgeInsets.all(16), children: [Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: neon.withValues(alpha:.45)), gradient: const LinearGradient(colors:[Color(0xFF263B2A),Color(0xFF121B22)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text('SHADOW ROYALE / $section',style:const TextStyle(color:neon,fontWeight:FontWeight.w900,letterSpacing:1)),const SizedBox(height:8),const Text('Survive • Adapt • Dominate',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Offline profile data is local. Shared online features activate after a backend is connected.',style:TextStyle(color:Colors.white60,fontSize:12))])),const SizedBox(height:14), FutureBuilder<SharedPreferences>(future: SharedPreferences.getInstance(), builder: (context, snapshot) { final prefs = snapshot.data; if (prefs == null) return const SizedBox.shrink(); return Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white12)), child: Wrap(spacing: 18, runSpacing: 12, children: [ _miniStat('MATCHES', '${prefs.getInt('sr_matches') ?? 0}'), _miniStat('WINS', '${prefs.getInt('sr_wins') ?? 0}'), _miniStat('KILLS', '${prefs.getInt('sr_total_kills') ?? 0}'), _miniStat('COINS', '${prefs.getInt('sr_coins') ?? 0}'), _miniStat('XP', '${prefs.getInt('sr_xp') ?? 0}') ])); }), ...items.map((item)=>Card(color:panel,child:ListTile(leading:Text(item['icon']!,style:const TextStyle(fontSize:25)),title:Text(item['title']!,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(item['detail']!,style:const TextStyle(color:Colors.white60,fontSize:12)),trailing:const Icon(Icons.chevron_right,color:neon),onTap:(){if(item['title']=='CUSTOM ROOM') { Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const CustomRoomPage())); } else if(item['title']=='SHOP') { Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const LocalShopPage())); } else if(item['title']=='INVENTORY') { Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const LocalInventoryPage())); } else if(item['title']=='MISSIONS' || item['title']=='DAILY MISSIONS') { Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const LocalMissionsPage())); } else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${item['title']} is shown as local profile information. Online functions require the backend.'))); }}))),const SizedBox(height:12),const Text('Online sync, global rankings, live events and account security require a game backend.',style:TextStyle(color:Colors.white38,fontSize:11))]));
  }
}

class LocalShopPage extends StatefulWidget {
  const LocalShopPage({super.key});
  @override
  State<LocalShopPage> createState() => _LocalShopPageState();
}

class _LocalShopPageState extends State<LocalShopPage> {
  int coins = 0;
  Set<String> owned = <String>{'Rookie Outfit'};
  final items = const <String, int>{
    'Night Ops Outfit': 250,
    'Veylora Blade Skin': 180,
    'Neon Trail': 120,
    'Shadow Fox Pet': 500,
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      coins = prefs.getInt('sr_coins') ?? 0;
      owned = (prefs.getStringList('sr_owned_items') ?? <String>['Rookie Outfit']).toSet();
    });
  }

  Future<void> _buy(String name, int price) async {
    if (owned.contains(name)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Already owned.')));
      return;
    }
    if (coins < price) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Not enough coins. Earn coins by playing offline matches.')));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    coins -= price;
    owned.add(name);
    await prefs.setInt('sr_coins', coins);
    await prefs.setStringList('sr_owned_items', owned.toList());
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('LOCAL COSMETIC SHOP')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                const Icon(Icons.monetization_on, color: neon),
                const SizedBox(width: 10),
                const Text('YOUR COINS', style: TextStyle(fontWeight: FontWeight.w900)),
                const Spacer(),
                Text('$coins', style: const TextStyle(color: neon, fontSize: 20, fontWeight: FontWeight.w900)),
              ]),
            ),
            const SizedBox(height: 12),
            ...items.entries.map((entry) => Card(
                  color: panel,
                  child: ListTile(
                    leading: const Icon(Icons.checkroom, color: neon, size: 30),
                    title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(owned.contains(entry.key) ? 'Owned • stored on this device' : '${entry.value} coins'),
                    trailing: owned.contains(entry.key)
                        ? const Icon(Icons.check_circle, color: neon)
                        : FilledButton(onPressed: () => _buy(entry.key, entry.value), child: const Text('BUY')),
                  ),
                )),
            const Padding(
              padding: EdgeInsets.only(top: 12),
              child: Text('Cosmetics are local placeholders. No real-money purchases or server inventory are connected.', style: TextStyle(color: Colors.white54, fontSize: 11)),
            ),
          ],
        ),
      );
}

class LocalInventoryPage extends StatefulWidget {
  const LocalInventoryPage({super.key});
  @override
  State<LocalInventoryPage> createState() => _LocalInventoryPageState();
}

class _LocalInventoryPageState extends State<LocalInventoryPage> {
  List<String> owned = <String>['Rookie Outfit'];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      if (mounted) setState(() => owned = prefs.getStringList('sr_owned_items') ?? <String>['Rookie Outfit']);
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('INVENTORY')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('${owned.length} ITEMS OWNED', style: const TextStyle(color: neon, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            ...owned.map((name) => Card(
                  color: panel,
                  child: ListTile(leading: const Icon(Icons.inventory_2_outlined, color: neon), title: Text(name), subtitle: const Text('Local cosmetic item')),
                )),
            const SizedBox(height: 10),
            const Text('This inventory is saved on this device and is not synced to an account.', style: TextStyle(color: Colors.white54, fontSize: 11)),
          ],
        ),
      );
}

class LocalMissionsPage extends StatefulWidget {
  const LocalMissionsPage({super.key});
  @override
  State<LocalMissionsPage> createState() => _LocalMissionsPageState();
}

class _LocalMissionsPageState extends State<LocalMissionsPage> {
  int matches = 0, kills = 0, coins = 0;
  bool claimed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      matches = prefs.getInt('sr_matches') ?? 0;
      kills = prefs.getInt('sr_total_kills') ?? 0;
      coins = prefs.getInt('sr_coins') ?? 0;
      claimed = prefs.getBool('sr_mission_claimed') ?? false;
    });
  }

  Future<void> _claim() async {
    final prefs = await SharedPreferences.getInstance();
    if (claimed) return;
    coins += 100;
    claimed = true;
    await prefs.setInt('sr_coins', coins);
    await prefs.setBool('sr_mission_claimed', true);
    if (mounted) setState(() {});
  }

  Widget _mission(String title, bool done, String progress) => Card(
        color: panel,
        child: ListTile(
          leading: Icon(done ? Icons.check_circle : Icons.flag_outlined, color: done ? neon : Colors.white54),
          title: Text(title),
          subtitle: Text(progress),
          trailing: Text(done ? 'DONE' : 'IN PROGRESS', style: TextStyle(color: done ? neon : Colors.white54, fontSize: 9, fontWeight: FontWeight.bold)),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('DAILY MISSIONS')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('OFFLINE CHALLENGES', style: TextStyle(color: neon, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            _mission('Play 1 match', matches >= 1, '$matches / 1'),
            _mission('Eliminate 3 bots', kills >= 3, '$kills / 3'),
            const SizedBox(height: 12),
            Card(
              color: panel,
              child: ListTile(
                leading: const Icon(Icons.card_giftcard, color: neon),
                title: const Text('Daily login reward'),
                subtitle: const Text('One-time local reward: 100 coins'),
                trailing: FilledButton(onPressed: claimed ? null : _claim, child: Text(claimed ? 'CLAIMED' : 'CLAIM')),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 12),
              child: Text('Mission counters use local match records. Online daily resets and event rewards require backend services.', style: TextStyle(color: Colors.white54, fontSize: 11)),
            ),
          ],
        ),
      );
}

class FeatureChip extends StatelessWidget { const FeatureChip(this.text, {super.key}); final String text; @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white12)), child: Text(text, style: const TextStyle(fontSize: 10, color: Colors.white70))); }

class CustomRoomPage extends StatefulWidget {
  const CustomRoomPage({super.key});
  @override
  State<CustomRoomPage> createState() => _CustomRoomPageState();
}

class _CustomRoomPageState extends State<CustomRoomPage> {
  final codeController = TextEditingController();
  final passwordController = TextEditingController();
  final joinPasswordController = TextEditingController();
  String roomCode = 'VYL-4821';
  String roomMode = 'Battle Royale';
  String playerLimit = '8 Players';
  String roomPassword = '';
  bool created = false;

  @override
  void dispose() {
    codeController.dispose();
    passwordController.dispose();
    joinPasswordController.dispose();
    super.dispose();
  }

  Widget _field(String label, TextEditingController controller, {bool obscure = false}) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: TextField(
          controller: controller,
          obscureText: obscure,
          decoration: InputDecoration(labelText: label, filled: true, fillColor: bg, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CUSTOM ROOM')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.groups_2, color: neon, size: 38),
                  const SizedBox(height: 10),
                  const Text('CREATE A PRIVATE MATCH', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  const Text('Configure a local practice room. It does not invite remote players until the server is connected.', style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: roomMode,
                    decoration: const InputDecoration(labelText: 'Game mode', filled: true, fillColor: bg, border: OutlineInputBorder()),
                    items: const ['Battle Royale', 'Classic', 'Lone Wolf', 'Training Ground'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                    onChanged: (v) { if (v != null) setState(() => roomMode = v); },
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: playerLimit,
                    decoration: const InputDecoration(labelText: 'Room capacity', filled: true, fillColor: bg, border: OutlineInputBorder()),
                    items: const ['2 Players', '4 Players', '8 Players', '12 Players'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                    onChanged: (v) { if (v != null) setState(() => playerLimit = v); },
                  ),
                  _field('Optional room password', passwordController, obscure: true),
                  if (created) Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(top: 14),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFF25351B), borderRadius: BorderRadius.circular(12)),
                    child: Column(children: [
                      const Text('YOUR LOCAL ROOM CODE', style: TextStyle(color: neon, fontSize: 10, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 7),
                      SelectableText(roomCode, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
                      Text('$roomMode • $playerLimit', style: const TextStyle(fontSize: 11, color: Colors.white70)),
                      Text(roomPassword.isEmpty ? 'No password set' : 'Password protection enabled', style: const TextStyle(fontSize: 10, color: Colors.white60)),
                      const SizedBox(height: 5),
                      const Text('Local room only • no remote players connected', style: TextStyle(fontSize: 10, color: Colors.white60)),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => setState(() {
                        created = true;
                        roomCode = 'VYL-${1000 + math.Random().nextInt(8999)}';
                        roomPassword = passwordController.text;
                      }),
                      child: const Text('CREATE OFFLINE ROOM'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('JOIN A ROOM', style: TextStyle(fontWeight: FontWeight.w900)),
                _field('Room code', codeController),
                _field('Room password (if required)', joinPasswordController, obscure: true),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      final code = codeController.text.trim().toUpperCase();
                      if (code.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a room code first.')));
                      } else if (created && code == roomCode && joinPasswordController.text == roomPassword) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Local room verified: $roomMode • $playerLimit. Remote joining is not available yet.')));
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Room not found locally, or password does not match. Remote joining needs the backend.')));
                      }
                    },
                    child: const Text('VERIFY / JOIN ROOM'),
                  ),
                ),
              ]),
            ),
          ],
        ),
      );
}

class ArenaPage extends StatefulWidget {
  const ArenaPage({super.key, required this.mode});
  final String mode;
  @override State<ArenaPage> createState() => _ArenaPageState();
}

class _Bot {
  _Bot(this.pos, this.name);
  Offset pos;
  final String name;
  int hp = 100;
  double attackClock = 0;
  bool alive = true;
}

class _ArenaPageState extends State<ArenaPage> {
  final math.Random rng = math.Random();
  late List<_Bot> bots;
  Timer? ticker;
  Offset player = const Offset(.5, .55);
  Offset stick = Offset.zero;
  int hp = 100, armor = 0, ammo = 30, kills = 0, seconds = 0, medkits = 2;
  String weapon = 'ASSAULT RIFLE';
  int weaponIndex = 0;
  final List<String> weapons = const ['ASSAULT RIFLE', 'SHOTGUN', 'SNIPER'];
  bool running = true, paused = false, won = false, resultSaved = false;
  String status = 'Find enemies and survive';

  @override void initState() {
    super.initState();
    bots = _createArenaActors();
    ticker = Timer.periodic(const Duration(milliseconds: 250), (_) => _tick());
  }
  @override void dispose() { ticker?.cancel(); super.dispose(); }
  double _clamp(double n) => n.clamp(.04, .96).toDouble();

  List<_Bot> _createArenaActors() {
    if (widget.mode == 'TRAINING GROUND') {
      // Stationary practice targets; these are not combat bots and cannot end
      // the session. They reset after a simulated elimination.
      return List.generate(5, (i) => _Bot(
        Offset(.20 + i * .15, .28 + (i.isEven ? .0 : .08)), 'TARGET-${i + 1}'));
    }
    final count = widget.mode == 'LONE WOLF' ? 1 : 9;
    return List.generate(count, (i) => _Bot(
      Offset(.12 + rng.nextDouble() * .76, .18 + rng.nextDouble() * .62), 'BOT-${i + 1}'));
  }

  void _tick() {
    if (!mounted || !running || paused || won) return;
    setState(() {
      seconds++;
      final zoneRadius = math.max(.20, .48 - seconds * .00035);
      final zoneDistance = _distance(player, const Offset(.5, .5));
      if (widget.mode != 'TRAINING GROUND' && zoneDistance > zoneRadius && seconds % 4 == 0) {
        hp = (hp - 5).clamp(0, 100).toInt();
        status = 'OUTSIDE SAFE ZONE • RETURN NOW';
        if (hp == 0) { running = false; status = 'ELIMINATED BY THE ZONE'; }
      }
      player = Offset(_clamp(player.dx + stick.dx * .025), _clamp(player.dy + stick.dy * .025));
      if (widget.mode != 'TRAINING GROUND') {
        for (final b in bots.where((b) => b.alive)) {
          final dx = player.dx - b.pos.dx, dy = player.dy - b.pos.dy;
          final d = math.sqrt(dx * dx + dy * dy);
          if (d > .12) b.pos = Offset(_clamp(b.pos.dx + dx / (d == 0 ? 1 : d) * .009), _clamp(b.pos.dy + dy / (d == 0 ? 1 : d) * .009));
          b.attackClock += .25;
          if (d < .38 && b.attackClock > (widget.mode.contains('RANKED') ? 2.0 : 3.0)) {
            b.attackClock = 0;
            // Fair bot: damage is bounded and never an instant kill.
            final incoming = 3 + rng.nextInt(6);
            final absorbed = math.min(armor, incoming).toInt();
            armor -= absorbed;
            hp = (hp - (incoming - absorbed)).clamp(0, 100).toInt();
            if (hp == 0) { running = false; status = 'ELIMINATED • TRY AGAIN'; }
          }
        }
        if (bots.every((b) => !b.alive)) { won = true; running = false; status = 'BOOYAH! • MATCH WON'; }
      }
    });
    if (!running && !resultSaved) _recordResult();
  }

  Future<void> _recordResult() async {
    resultSaved = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('sr_matches', (prefs.getInt('sr_matches') ?? 0) + 1);
    await prefs.setInt('sr_total_kills', (prefs.getInt('sr_total_kills') ?? 0) + kills);
    await prefs.setInt('sr_total_survival_seconds', (prefs.getInt('sr_total_survival_seconds') ?? 0) + seconds ~/ 4);
    if (won) {
      await prefs.setInt('sr_wins', (prefs.getInt('sr_wins') ?? 0) + 1);
      await prefs.setInt('sr_coins', (prefs.getInt('sr_coins') ?? 0) + 100 + kills * 10);
      await prefs.setInt('sr_xp', (prefs.getInt('sr_xp') ?? 0) + 150 + kills * 20);
    } else {
      await prefs.setInt('sr_coins', (prefs.getInt('sr_coins') ?? 0) + kills * 5);
      await prefs.setInt('sr_xp', (prefs.getInt('sr_xp') ?? 0) + 25 + kills * 10);
    }
  }

  void _fire() {
    if (!running) return;
    setState(() {
      if (ammo <= 0) { ammo = weapon == 'SHOTGUN' ? 8 : (weapon == 'SNIPER' ? 5 : 30); status = 'RELOADED'; return; }
      ammo--;
      final alive = bots.where((b) => b.alive).toList();
      if (alive.isEmpty) return;
      alive.sort((a, b) => _distance(a.pos, player).compareTo(_distance(b.pos, player)));
      final target = alive.first;
      final range = weapon == 'SNIPER' ? .48 : (weapon == 'SHOTGUN' ? .20 : .34);
      final hitChance = weapon == 'SNIPER' ? .88 : (weapon == 'SHOTGUN' ? .72 : .80);
      if (_distance(target.pos, player) < range && rng.nextDouble() < hitChance) {
        final damage = weapon == 'SNIPER' ? 65 : (weapon == 'SHOTGUN' ? 42 : (rng.nextDouble() > .76 ? 48 : 28));
        target.hp -= damage;
        if (target.hp <= 0) {
          if (widget.mode == 'TRAINING GROUND') {
            target.hp = 100;
            target.alive = true;
            status = 'TARGET HIT • ${target.name} RESET • $weapon';
          } else {
            target.alive = false;
            kills++;
            status = 'ELIMINATED ${target.name} • $weapon';
          }
        } else { status = 'HIT • ${target.hp}% TARGET HP • $weapon'; }
      } else { status = 'MISS • MOVE CLOSER'; }
    });
  }
  double _distance(Offset a, Offset b) => math.sqrt(math.pow(a.dx-b.dx, 2) + math.pow(a.dy-b.dy, 2));
  void _switchWeapon() => setState(() { weaponIndex = (weaponIndex + 1) % weapons.length; weapon = weapons[weaponIndex]; ammo = weapon == 'SHOTGUN' ? 8 : (weapon == 'SNIPER' ? 5 : 30); status = 'EQUIPPED: $weapon'; });
  void _loot() => setState(() { final roll = rng.nextInt(3); if (roll == 0) { armor = (armor + 25).clamp(0, 100).toInt(); status = 'LOOT PICKED UP • ARMOR +25'; } else if (roll == 1) { ammo += weapon == 'SHOTGUN' ? 8 : (weapon == 'SNIPER' ? 5 : 30); status = 'LOOT PICKED UP • AMMO'; } else { medkits = (medkits + 1).clamp(0, 5).toInt(); status = 'LOOT PICKED UP • MEDKIT'; } });
  void _heal() => setState(() { if (medkits > 0 && hp < 100) { medkits--; hp = (hp + 35).clamp(0, 100).toInt(); status = 'MEDKIT USED'; } else { status = medkits == 0 ? 'NO MEDKITS LEFT' : 'HEALTH IS FULL'; } });
  void _restart() { setState(() { player = const Offset(.5,.55); stick = Offset.zero; hp=100; armor=0; ammo=30; kills=0; seconds=0; medkits=2; running=true; paused=false; won=false; resultSaved=false; status='Match restarted'; bots = _createArenaActors(); }); }
  void _emote() => showModalBottomSheet<void>(context: context, backgroundColor: panel, builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(18), child: Wrap(spacing: 8, runSpacing: 8, children: ['LOL 😂','Dance 💃','Laugh 😆','Taunt 😎','Clap 👏','Victory 🏆'].map((e) => ActionChip(label: Text(e), onPressed: () { Navigator.pop(ctx); setState(() => status = 'EMOTE: $e'); })).toList()))));

  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: LayoutBuilder(builder: (context, box) {
    return Stack(children: [
      Positioned.fill(child: CustomPaint(painter: ArenaPainter(player: player, bots: bots.map((b)=>ArenaBotView(b.pos,b.hp,b.alive,b.name)).toList(), zone: math.max(.20,.48-seconds*.00035).toDouble()))),
      Positioned(top: 10,left: 10,right: 10,child: Row(children:[_hud('MODE',widget.mode,Icons.public),const Spacer(),_hud('ALIVE','${bots.where((b)=>b.alive).length+1}',Icons.groups),const SizedBox(width:6),_hud('KILLS','$kills',Icons.gps_fixed)])),
      Positioned(top: 70,left: 10,child: Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:Colors.black.withValues(alpha:.65),borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('VEYLORA ISLAND',style:TextStyle(color:neon,fontWeight:FontWeight.w900,fontSize:10)),const SizedBox(height:5),Text('HP  $hp%  •  ARMOR $armor',style:const TextStyle(fontWeight:FontWeight.bold)),SizedBox(width:108,child:LinearProgressIndicator(value:hp/100,color:hp>30?neon:Colors.red,backgroundColor:Colors.white24)),const SizedBox(height:5),Text('WEAPON  $weapon',style:const TextStyle(fontSize:9,color:neon)),Text('AMMO  $ammo',style:const TextStyle(fontSize:11)),Text('TIME  ${seconds ~/ 4}s',style:const TextStyle(fontSize:10,color:Colors.white60))]))),
      Positioned(top: 133,left: 10,right: 10,child: Text(status,style:const TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.bold,shadows:[Shadow(color:Colors.black,blurRadius:6)]))),
      Positioned(left: 18,bottom: 28,child: GestureDetector(onPanUpdate:(d){setState(()=>stick=Offset((stick.dx+d.delta.dx/25).clamp(-1,1).toDouble(),(stick.dy+d.delta.dy/25).clamp(-1,1).toDouble()));},onPanEnd:(_)=>setState(()=>stick=Offset.zero),onPanCancel:()=>setState(()=>stick=Offset.zero),child:Container(width:112,height:112,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.black.withValues(alpha:.38),border:Border.all(color:Colors.white54,width:2)),child:Center(child:Container(width:48,height:48,decoration:BoxDecoration(shape:BoxShape.circle,color:neon.withValues(alpha:.8)),child:const Icon(Icons.control_camera,color:bg,size:32)))))),
      Positioned(right: 14,bottom: 26,child:Column(children:[_gameButton(Icons.flash_on,'FIRE',_fire),const SizedBox(height:9),_gameButton(Icons.medical_services,'HEAL',_heal),const SizedBox(height:9),_gameButton(Icons.refresh,'RELOAD',()=>setState(()=>ammo=weapon == 'SHOTGUN' ? 8 : (weapon == 'SNIPER' ? 5 : 30))),const SizedBox(height:9),_gameButton(Icons.backpack,'LOOT',_loot),const SizedBox(height:9),_gameButton(Icons.swap_horiz,'WEAPON',_switchWeapon),const SizedBox(height:9),_gameButton(Icons.emoji_emotions,'EMOTE',_emote)])),
      Positioned(right: 16,top: 4,child:IconButton(onPressed:()=>setState(()=>paused=!paused),icon:Icon(paused?Icons.play_circle_outline:Icons.pause_circle_outline,size:31))),
      if(!running || paused) Positioned.fill(child:Container(color:Colors.black.withValues(alpha:.82),child:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(won?Icons.emoji_events:Icons.pause_circle_filled,color:neon,size:58),const SizedBox(height:12),Text(won?'BOOYAH!':(hp==0?'ELIMINATED':(paused?'MATCH PAUSED':'MATCH OVER')),style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:neon)),const SizedBox(height:8),Text('Kills: $kills  •  Survival: ${seconds ~/ 4}s',style:const TextStyle(color:Colors.white70)),const SizedBox(height:20),if(paused && hp>0 && !won) SizedBox(width:220,child:FilledButton(onPressed:()=>setState(()=>paused=false),child:const Text('RESUME MATCH'))),SizedBox(width:220,child:FilledButton(onPressed:_restart,child:const Text('PLAY AGAIN'))),TextButton(onPressed:()=>Navigator.pop(context),child:const Text('EXIT TO LOBBY'))]))))),
    ]);
  })));

  Widget _hud(String label,String value,IconData icon)=>Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:7),decoration:BoxDecoration(color:Colors.black.withValues(alpha:.68),borderRadius:BorderRadius.circular(9),border:Border.all(color:Colors.white24)),child:Row(mainAxisSize:MainAxisSize.min,children:[Icon(icon,color:neon,size:14),const SizedBox(width:4),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontSize:7,color:Colors.white60)),Text(value,style:const TextStyle(fontSize:9,fontWeight:FontWeight.w900))])]));
  Widget _gameButton(IconData icon,String label,VoidCallback cb)=>InkWell(onTap:cb,borderRadius:BorderRadius.circular(40),child:Container(width:58,height:58,decoration:BoxDecoration(color:Colors.black.withValues(alpha:.65),shape:BoxShape.circle,border:Border.all(color:neon.withValues(alpha:.8))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:neon,size:21),Text(label,style:const TextStyle(fontSize:7,fontWeight:FontWeight.w900))])));
}

class ArenaBotView { const ArenaBotView(this.pos,this.hp,this.alive,this.name); final Offset pos; final int hp; final bool alive; final String name; }
class ArenaPainter extends CustomPainter {
  ArenaPainter({required this.player,required this.bots,required this.zone}); final Offset player; final List<ArenaBotView> bots; final double zone;
  @override void paint(Canvas canvas,Size size){
    final p=Paint()..shader=const LinearGradient(colors:[Color(0xFF1D3D32),Color(0xFF172D29),Color(0xFF101B20)],begin:Alignment.topLeft,end:Alignment.bottomRight).createShader(Offset.zero&size);canvas.drawRect(Offset.zero&size,p);p.shader=null;
    final rng=math.Random(28);for(int i=0;i<110;i++){final x=rng.nextDouble()*size.width,y=rng.nextDouble()*size.height;p.color=i%4==0?const Color(0xFF31543B):const Color(0xFF244333);canvas.drawCircle(Offset(x,y),5+rng.nextDouble()*14,p);}
    p.color=const Color(0xFF68715D);p.strokeWidth=17;p.style=PaintingStyle.stroke;final path=Path()..moveTo(-10,size.height*.62)..cubicTo(size.width*.3,size.height*.45,size.width*.4,size.height*.8,size.width+10,size.height*.54);canvas.drawPath(path,p);p.color=const Color(0xFF9A9A78);p.strokeWidth=2;canvas.drawPath(path,p);p.style=PaintingStyle.fill;
    for(final r in [Rect.fromLTWH(size.width*.15,size.height*.29,46,34),Rect.fromLTWH(size.width*.25,size.height*.34,32,27),Rect.fromLTWH(size.width*.72,size.height*.35,54,37),Rect.fromLTWH(size.width*.66,size.height*.42,35,28),Rect.fromLTWH(size.width*.39,size.height*.16,48,29)]){p.color=const Color(0xFF7B8175);canvas.drawRRect(RRect.fromRectAndRadius(r,const Radius.circular(4)),p);p.color=const Color(0xFF303A37);canvas.drawRect(Rect.fromLTWH(r.left+5,r.top+5,9,8),p);}
    final c=Offset(size.width*player.dx,size.height*player.dy);p.color=const Color(0x553DFF58);p.style=PaintingStyle.stroke;p.strokeWidth=3;canvas.drawCircle(Offset(size.width*.5,size.height*.5),math.min(size.width,size.height)*zone,p);p.style=PaintingStyle.fill;
    for(final b in bots.where((b)=>b.alive)){final pos=Offset(size.width*b.pos.dx,size.height*b.pos.dy);p.color=const Color(0xFFEF5350);canvas.drawCircle(pos,9,p);p.color=Colors.black;canvas.drawRect(Rect.fromLTWH(pos.dx-8,pos.dy-15,16,3),p);p.color=const Color(0xFF80FF80);canvas.drawRect(Rect.fromLTWH(pos.dx-8,pos.dy-15,16*(b.hp.clamp(0,100)/100),3),p);}
    p.color=neon;canvas.drawCircle(c,9,p);p.color=Colors.white;canvas.drawCircle(Offset(c.dx,c.dy-7),4,p);p.color=const Color(0xFF171F26);canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:Offset(c.dx,c.dy+5),width:16,height:20),const Radius.circular(4)),p);
  }
  @override bool shouldRepaint(covariant ArenaPainter old)=>old.player!=player||old.bots!=bots||old.zone!=zone;
}


/// Offline-only social UI foundation. Real cross-device search, invites, and team
/// codes require an authenticated online service; local demo data is never a server result.
class SocialHubPage extends StatefulWidget {
  const SocialHubPage({super.key});
  @override
  State<SocialHubPage> createState() => _SocialHubPageState();
}

class _SocialHubPageState extends State<SocialHubPage> {
  final _search = TextEditingController();
  final _teamCode = TextEditingController();
  final List<Map<String, String>> _directory = const [
    {'name': 'NightViper', 'uid': 'SR-104829'},
    {'name': 'NovaGhost', 'uid': 'SR-104830'},
    {'name': 'RiftHunter', 'uid': 'SR-104831'},
    {'name': 'VeyloraAce', 'uid': 'SR-104832'},
    {'name': 'AshenWolf', 'uid': 'SR-104833'},
  ];
  final Set<String> _friends = <String>{};
  final Set<String> _invited = <String>{};
  final List<String> _party = <String>['You'];
  String _prime = 'Prime I';
  String? _createdCode;
  String _status = 'Loading saved local social data…';
  bool _socialLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadSocial();
  }

  Future<void> _loadSocial() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _friends.addAll(prefs.getStringList('sr_social_friends') ?? const <String>[]);
      _invited.addAll(prefs.getStringList('sr_social_invited') ?? const <String>[]);
      _party
        ..clear()
        ..addAll(prefs.getStringList('sr_social_party') ?? const <String>['You']);
      if (_party.isEmpty) _party.add('You');
      _prime = prefs.getString('sr_social_prime') ?? 'Prime I';
      _createdCode = prefs.getString('sr_social_team_code');
      _status = 'Local social data restored on this device. Online service is not connected.';
      _socialLoaded = true;
    });
  }

  Future<void> _saveSocial() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('sr_social_friends', _friends.toList());
    await prefs.setStringList('sr_social_invited', _invited.toList());
    await prefs.setStringList('sr_social_party', _party.toList());
    await prefs.setString('sr_social_prime', _prime);
    if (_createdCode == null) {
      await prefs.remove('sr_social_team_code');
    } else {
      await prefs.setString('sr_social_team_code', _createdCode!);
    }
  }

  int get _friendLimit {
    const caps = {'Prime I': 100, 'Prime II': 115, 'Prime III': 130, 'Prime IV': 145, 'Prime V': 160, 'Prime VI': 175, 'Prime VII': 190, 'Prime VIII': 200};
    return caps[_prime] ?? 100;
  }

  @override
  void dispose() {
    _search.dispose();
    _teamCode.dispose();
    super.dispose();
  }

  void _toast(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  String _newCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final seed = DateTime.now().microsecondsSinceEpoch;
    return List.generate(6, (i) => chars[(seed ~/ (i + 1) + seed % (i + 7) * 3 + i * 11) % chars.length]).join();
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim().toLowerCase();
    final results = _directory.where((p) => query.isNotEmpty && ('${p['name']} ${p['uid']}'.toLowerCase().contains(query))).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('FRIENDS & TEAM')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: neon.withValues(alpha: .35))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PLAYER SEARCH', style: TextStyle(color: neon, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 8),
          TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by player name or UID', border: OutlineInputBorder(), isDense: true)),
          const SizedBox(height: 8),
          if (query.isEmpty) const Text('Type a name or UID to search the sample directory.', style: TextStyle(color: Colors.white54, fontSize: 12))
          else if (results.isEmpty) const Text('No matching sample player. Real global search requires backend.', style: TextStyle(color: Colors.white54, fontSize: 12))
          else ...results.map((p) => ListTile(contentPadding: EdgeInsets.zero, leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(p['name']!), subtitle: Text(p['uid']!), trailing: _friends.contains(p['uid']) ? const Icon(Icons.check_circle, color: neon) : TextButton(onPressed: () { if (_friends.length >= _friendLimit) { _toast('Friend limit reached for $_prime ($_friendLimit).'); return; } setState(() => _friends.add(p['uid']!)); _saveSocial(); _toast('Sample friend saved on this device. No real request was sent.'); }, child: const Text('ADD')))),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('FRIEND CAPACITY', style: TextStyle(color: neon, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 10),
          DropdownButtonFormField<String>(value: _prime, decoration: const InputDecoration(labelText: 'Preview Prime tier', border: OutlineInputBorder()), items: const ['Prime I','Prime II','Prime III','Prime IV','Prime V','Prime VI','Prime VII','Prime VIII'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { setState(() => _prime = v ?? _prime); _saveSocial(); }),
          const SizedBox(height: 10), Row(children: [const Icon(Icons.people_alt_outlined, color: neon), const SizedBox(width: 8), Expanded(child: Text('${_friends.length} / $_friendLimit friends', style: const TextStyle(fontWeight: FontWeight.w800))), Text('MAX $_friendLimit', style: const TextStyle(color: neon, fontWeight: FontWeight.w900))]),
          const SizedBox(height: 6), const Text('Proposed policy: 100 at Prime I, rising by tier to 200 at Prime VIII. This is a local preview, not a final synced account entitlement.', style: TextStyle(color: Colors.white54, fontSize: 11)),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('TEAM CODE', style: TextStyle(color: neon, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 8),
          if (_createdCode != null) SelectableText('YOUR CODE: $_createdCode', style: const TextStyle(fontSize: 22, letterSpacing: 3, fontWeight: FontWeight.w900)),
          Wrap(spacing: 8, runSpacing: 8, children: [FilledButton(onPressed: () { setState(() { _createdCode = _newCode(); _status = 'Created local demo team code $_createdCode.'; }); _saveSocial(); }, child: const Text('CREATE TEAM CODE')), OutlinedButton(onPressed: _createdCode == null ? null : () { final code = _createdCode!; _toast('Share code $code manually for this demo; online joining is not connected.'); }, child: const Text('SHARE CODE'))]),
          const SizedBox(height: 12), TextField(controller: _teamCode, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Enter team code', hintText: '6-character code', border: OutlineInputBorder(), isDense: true)),
          const SizedBox(height: 8), OutlinedButton(onPressed: () { final code = _teamCode.text.trim().toUpperCase(); if (code.length != 6) { _toast('Enter a 6-character team code.'); return; } setState(() => _status = 'Join request for $code recorded locally only; no remote team was joined.'); _toast('Code format accepted, but it is not verified against a remote server.'); }, child: const Text('JOIN TEAM CODE')),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PARTY & INVITES', style: TextStyle(color: neon, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 6),
          Text('Party size: ${_party.length} / 4 (Squad preview)', style: const TextStyle(fontWeight: FontWeight.w800)),
          ..._friends.map((id) { final player = _directory.firstWhere((p) => p['uid'] == id, orElse: () => {'uid': id, 'name': 'Unknown'}); final sent = _invited.contains(id); return ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.person_add_alt_1, color: neon), title: Text(player['name']!), subtitle: Text(id), trailing: TextButton(onPressed: sent || _party.length >= 4 ? null : () { setState(() => _invited.add(id)); _saveSocial(); _toast('Invite marker saved locally; no notification was delivered.'); }, child: Text(sent ? 'INVITED' : 'INVITE'))); }),
          if (_friends.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('Add sample friends from search to preview party invites.', style: TextStyle(color: Colors.white54, fontSize: 12))),
          const SizedBox(height: 8), Text(_socialLoaded ? _status : 'Loading saved local social data…', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF2A2117), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF6A5427))), child: const Text('OFFLINE LIMITATIONS: The directory is synthetic sample data. Friend list, tier preview and your generated code are saved only on this device; no real player search, request, notification, cross-device team join or remote party exists without an authenticated backend. Godot has an offline AI squad revive prototype, not online human revive or server authority.', style: TextStyle(color: Color(0xFFFFD98B), fontSize: 12))),
      ]),
    );
  }
}
