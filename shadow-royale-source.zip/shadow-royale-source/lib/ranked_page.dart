import 'package:flutter/material.dart';
import 'ranked_progression.dart';

const _neon = Color(0xFFB8FF39);
const _panel = Color(0xFF121B22);

/// Rank preview screen. It intentionally shows Unranked until server-synced
/// values are available; it never awards local/offline matches global points.
class RankedPage extends StatelessWidget {
  const RankedPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('RANKED • SEASON 01')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _neon.withValues(alpha: .55)),
              gradient: const LinearGradient(colors: [Color(0xFF2B3A27), _panel], begin: Alignment.topLeft, end: Alignment.bottomRight),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.workspace_premium, color: _neon, size: 36),
              SizedBox(height: 10),
              Text('GLOBAL RANK: UNRANKED', style: TextStyle(color: _neon, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              SizedBox(height: 8),
              Text('Your global rank begins after secure online ranked matches are connected. Offline practice does not add or remove global rating points.', style: TextStyle(color: Colors.white70, height: 1.45)),
            ]),
          ),
          const SizedBox(height: 16),
          _rankTrack(
            title: 'CLASSIC RANKED • STAR TRACK',
            subtitle: '5 stars per tier • 100 rating points per star',
            names: csTierNames,
            current: csRankForPoints(0),
            description: 'Match result, round difference and kills influence rating. Final awards must be confirmed by the trusted match server.',
          ),
          const SizedBox(height: 12),
          _rankTrack(
            title: 'BATTLE ROYALE RANKED',
            subtitle: 'Placement + capped kills + survival bonus',
            names: brTierNames,
            current: brRankForPoints(0),
            description: 'Higher placement earns more rating. A match can lose rating; results are separate from Classic Ranked.',
          ),
          const SizedBox(height: 14),
          const Text('BR TIER THRESHOLDS', style: TextStyle(color: _neon, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 8),
          ...List.generate(brTierNames.length, (i) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
              decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white10)),
              child: Row(children: [Expanded(child: Text(brTierNames[i], style: const TextStyle(fontWeight: FontWeight.w800))), Text('${brTierThresholds[i]} RP', style: const TextStyle(color: _neon, fontWeight: FontWeight.w900))]),
            ),
          )),
          const SizedBox(height: 8),
          const Text('Preview only • No online rating has been issued. Ranked matchmaking, match-end results, and server synchronization must be deployed and tested before this screen can display a live rank.', style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.4)),
        ]),
      );

  Widget _rankTrack({required String title, required String subtitle, required List<String> names, required RankedProgress current, required String description}) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: _neon, fontWeight: FontWeight.w900, letterSpacing: .7)),
          const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 12),
          Row(children: [const Icon(Icons.lock_outline, color: _neon, size: 28), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('UNRANKED', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), Text('Example starting tier: ${current.name}', style: const TextStyle(color: Colors.white60, fontSize: 11))]))]),
          if (current.starsPerTier > 0) ...[
            const SizedBox(height: 10),
            Row(children: List.generate(current.starsPerTier, (i) => Expanded(child: Padding(padding: const EdgeInsets.only(right: 4), child: Container(height: 5, decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(5))))))),
          ],
          const SizedBox(height: 10), Text(description, style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
          const SizedBox(height: 8), Text('Tiers: ${names.join('  ›  ')}', style: const TextStyle(color: Colors.white38, fontSize: 10, height: 1.5)),
        ]),
      );
}
