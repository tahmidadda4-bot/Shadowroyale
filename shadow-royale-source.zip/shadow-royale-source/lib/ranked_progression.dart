/// Shadow Royale's original ranked rules. These are UI/display rules only;
/// online ratings must be calculated by the trusted match backend.
class RankedProgress {
  const RankedProgress({required this.name, required this.points, required this.nextThreshold, required this.stars, required this.starsPerTier, required this.pointsPerStar});
  final String name;
  final int points;
  final int nextThreshold;
  final int stars;
  final int starsPerTier;
  final int pointsPerStar;
  int get pointsToNext => (nextThreshold - points).clamp(0, 1 << 30).toInt();
  double get progress => pointsPerStar <= 0 ? 1 : ((points % pointsPerStar) / pointsPerStar).clamp(0.0, 1.0).toDouble();
}

const csTierNames = <String>['Rookie', 'Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Elite', 'Heroic', 'Master', 'Grandmaster'];
const brTierNames = <String>['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Crown', 'Heroic', 'Master', 'Grandmaster'];
const brTierThresholds = <int>[0, 200, 450, 800, 1250, 1800, 2400, 3200, 4200];

int csRankDelta({required bool won, required int roundDifference, required int kills}) {
  final result = (won ? 25 : -15) + roundDifference.clamp(-5, 5).toInt() * 2 + kills.clamp(0, 10).toInt();
  return result.clamp(-25, 40).toInt();
}

int brRankDelta({required int placement, required int kills, required int survivalSeconds}) {
  final safePlacement = placement.clamp(1, 50).toInt();
  final place = safePlacement <= 1 ? 80 : safePlacement == 2 ? 60 : safePlacement <= 5 ? 40 : safePlacement <= 10 ? 20 : safePlacement <= 20 ? 5 : -20;
  final kill = kills.clamp(0, 5).toInt() * 8;
  final survival = (survivalSeconds.clamp(0, 86400).toInt() ~/ 120).clamp(0, 10).toInt();
  return (place + kill + survival).clamp(-30, 130).toInt();
}

RankedProgress csRankForPoints(int rawPoints) {
  final points = rawPoints.clamp(0, 1 << 30).toInt();
  final starIndex = points ~/ 100;
  final tierIndex = (starIndex ~/ 5).clamp(0, csTierNames.length - 1).toInt();
  final capped = points >= 5000;
  return RankedProgress(
    name: csTierNames[tierIndex], points: points,
    nextThreshold: capped ? 5000 : ((starIndex + 1) * 100),
    stars: capped ? 5 : starIndex % 5,
    starsPerTier: 5, pointsPerStar: 100,
  );
}

RankedProgress brRankForPoints(int rawPoints) {
  final points = rawPoints.clamp(0, 1 << 30).toInt();
  var index = 0;
  for (var i = 0; i < brTierThresholds.length; i++) {
    if (points >= brTierThresholds[i]) index = i;
  }
  final capped = index == brTierNames.length - 1;
  return RankedProgress(
    name: brTierNames[index], points: points,
    nextThreshold: capped ? 4200 : brTierThresholds[index + 1],
    stars: 0, starsPerTier: 0, pointsPerStar: 1,
  );
}
