-- Shadow Royale core Supabase schema foundation. Review/apply in a test project first.
-- Never place a service-role key in a client application.
create extension if not exists pgcrypto;

create table if not exists public.player_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 player_uid text not null unique default ('SR-' || upper(substr(encode(gen_random_bytes(8),'hex'),1,10))),
 display_name text not null default 'Rookie', avatar_key text not null default 'default',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 constraint player_uid_format check (player_uid ~ '^SR-[A-F0-9]{10}$'),
 constraint display_name_length check (char_length(display_name) between 3 and 20)
);
create table if not exists public.friendships (
 id uuid primary key default gen_random_uuid(), requester_id uuid not null references auth.users(id) on delete cascade,
 addressee_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','declined','blocked')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 check(requester_id <> addressee_id), unique(requester_id,addressee_id)
);
create index if not exists friendships_addressee_status_idx on public.friendships(addressee_id,status);
create index if not exists friendships_requester_status_idx on public.friendships(requester_id,status);

create table if not exists public.parties (
 id uuid primary key default gen_random_uuid(), party_code text not null unique,
 leader_id uuid not null references auth.users(id) on delete cascade,
 mode text not null default 'battle_royale' check(mode in ('battle_royale','classic','lone_wolf','training')),
 capacity smallint not null default 4 check(capacity between 2 and 4), is_locked boolean not null default false,
 created_at timestamptz not null default now(), expires_at timestamptz not null default(now()+interval '2 hours')
);
create index if not exists parties_expiry_idx on public.parties(expires_at);
create table if not exists public.party_members (
 party_id uuid not null references public.parties(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'member' check(role in ('leader','member')), ready boolean not null default false,
 joined_at timestamptz not null default now(), primary key(party_id,user_id)
);
create index if not exists party_members_user_idx on public.party_members(user_id);

-- Wallet changes are server-owned; clients receive read-only access to own rows.
create table if not exists public.wallet_accounts (
 user_id uuid primary key references auth.users(id) on delete cascade,
 eclipse_gems bigint not null default 0 check(eclipse_gems>=0), royale_gold bigint not null default 0 check(royale_gold>=0),
 rift_tokens bigint not null default 0 check(rift_tokens>=0), qualifying_topup_total bigint not null default 0 check(qualifying_topup_total>=0),
 prime_tier smallint generated always as (case when qualifying_topup_total>=200000 then 8 when qualifying_topup_total>=100000 then 7 when qualifying_topup_total>=60000 then 6 when qualifying_topup_total>=30000 then 5 when qualifying_topup_total>=15000 then 4 when qualifying_topup_total>=5000 then 3 when qualifying_topup_total>=1000 then 2 when qualifying_topup_total>=100 then 1 else 0 end) stored,
 updated_at timestamptz not null default now()
);
create table if not exists public.wallet_ledger (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 currency text not null check(currency in ('eclipse_gems','royale_gold','rift_tokens')), delta bigint not null check(delta<>0),
 reason text not null, idempotency_key text not null unique, external_reference text,
 actor_id uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
create index if not exists wallet_ledger_user_time_idx on public.wallet_ledger(user_id,created_at desc);
create table if not exists public.purchase_receipts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 store text not null check(store in ('google_play','app_store')), product_id text not null, transaction_id text not null,
 status text not null default 'pending' check(status in ('pending','verified','rejected','refunded','revoked')),
 qualifying_gems bigint not null default 0 check(qualifying_gems>=0), verified_at timestamptz,
 created_at timestamptz not null default now(), unique(store,transaction_id)
);
create table if not exists public.admin_roles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null check(role in ('support','moderator','economy_admin','super_admin')),
 granted_by uuid references auth.users(id) on delete set null, granted_at timestamptz not null default now()
);
create table if not exists public.admin_audit_log (
 id bigint generated always as identity primary key, actor_id uuid references auth.users(id) on delete set null,
 action text not null, target_user_id uuid references auth.users(id) on delete set null,
 details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create or replace function public.is_admin(required_roles text[] default array['super_admin'])
returns boolean language sql stable security definer set search_path=public,auth as $$
 select exists(select 1 from public.admin_roles ar where ar.user_id=auth.uid() and ar.role=any(required_roles));
$$;
revoke all on function public.is_admin(text[]) from public;
grant execute on function public.is_admin(text[]) to authenticated;

alter table public.player_profiles enable row level security;
alter table public.friendships enable row level security;
alter table public.parties enable row level security;
alter table public.party_members enable row level security;
alter table public.wallet_accounts enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.purchase_receipts enable row level security;
alter table public.admin_roles enable row level security;
alter table public.admin_audit_log enable row level security;

create policy profiles_read_authenticated on public.player_profiles for select to authenticated using(true);
create policy profiles_insert_self on public.player_profiles for insert to authenticated with check(user_id=auth.uid());
create policy profiles_update_self on public.player_profiles for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy friendships_read_participant on public.friendships for select to authenticated using(requester_id=auth.uid() or addressee_id=auth.uid());
create policy friendships_request_self on public.friendships for insert to authenticated with check(requester_id=auth.uid() and addressee_id<>auth.uid());
create policy friendships_update_participant on public.friendships for update to authenticated using(requester_id=auth.uid() or addressee_id=auth.uid()) with check(requester_id=auth.uid() or addressee_id=auth.uid());
create policy friendships_delete_participant on public.friendships for delete to authenticated using(requester_id=auth.uid() or addressee_id=auth.uid());
-- Party reads are member-only. Creation/joining must use validated server functions.
create policy parties_read_member on public.parties for select to authenticated using(leader_id=auth.uid() or exists(select 1 from public.party_members pm where pm.party_id=id and pm.user_id=auth.uid()));
create policy party_members_read_self on public.party_members for select to authenticated using(user_id=auth.uid());
create policy wallet_read_self on public.wallet_accounts for select to authenticated using(user_id=auth.uid());
create policy ledger_read_self on public.wallet_ledger for select to authenticated using(user_id=auth.uid());
create policy receipts_read_self on public.purchase_receipts for select to authenticated using(user_id=auth.uid());
create policy admin_roles_read_self_or_superadmin on public.admin_roles for select to authenticated using(user_id=auth.uid() or public.is_admin(array['super_admin']));
create policy admin_audit_read_admin on public.admin_audit_log for select to authenticated using(public.is_admin(array['super_admin','economy_admin','moderator']));
-- Intentionally no client write policies for wallet/ledger/receipts/admin roles/audit.
