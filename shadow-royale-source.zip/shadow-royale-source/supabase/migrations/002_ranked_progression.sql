-- Shadow Royale ranked progression foundation. Match results must be written by a trusted backend,
-- never directly by the mobile client. Apply after 001_core_schema.sql in a test project first.
create table if not exists public.ranked_profiles (
  user_id uuid not null references auth.users(id) on delete cascade,
  ranked_mode text not null check (ranked_mode in ('cs_ranked','br_ranked')),
  rating_points integer not null default 0 check (rating_points >= 0),
  matches_played integer not null default 0 check (matches_played >= 0),
  wins integer not null default 0 check (wins >= 0 and wins <= matches_played),
  updated_at timestamptz not null default now(),
  primary key (user_id, ranked_mode)
);

create table if not exists public.ranked_match_results (
  match_id uuid not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  ranked_mode text not null check (ranked_mode in ('cs_ranked','br_ranked')),
  placement integer not null check (placement between 1 and 50),
  kills integer not null default 0 check (kills >= 0 and kills <= 50),
  points_before integer not null check (points_before >= 0),
  points_delta integer not null check (points_delta between -30 and 130),
  points_after integer not null check (points_after >= 0),
  result_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  primary key (match_id, user_id)
);
create index if not exists ranked_match_results_user_recent_idx on public.ranked_match_results(user_id, created_at desc);

alter table public.ranked_profiles enable row level security;
alter table public.ranked_match_results enable row level security;
create policy ranked_profiles_read_self on public.ranked_profiles for select to authenticated using (user_id = auth.uid());
create policy ranked_results_read_self on public.ranked_match_results for select to authenticated using (user_id = auth.uid());
-- Intentionally no client insert/update/delete policies: trusted match service must settle results atomically.
