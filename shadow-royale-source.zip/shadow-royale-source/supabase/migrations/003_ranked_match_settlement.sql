-- Trusted, atomic ranked settlement. Apply after migrations 001 and 002.
-- Only the backend using the Supabase service_role may call this function.
create or replace function public.settle_ranked_match(
  p_match_id uuid,
  p_ranked_mode text,
  p_results jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  r jsonb;
  v_user_id uuid;
  v_placement integer;
  v_kills integer;
  v_survival integer;
  v_won boolean;
  v_round_diff integer;
  v_before integer;
  v_delta integer;
  v_after integer;
  v_base integer;
  v_tier text;
  v_stars integer;
  v_next integer;
  v_output jsonb := '[]'::jsonb;
  v_inserted integer;
begin
  if p_match_id is null then raise exception 'match_id_required'; end if;
  if p_ranked_mode is null or p_ranked_mode not in ('cs_ranked', 'br_ranked') then raise exception 'invalid_ranked_mode'; end if;
  if p_results is null or jsonb_typeof(p_results) <> 'array' or jsonb_array_length(p_results) < 1 or jsonb_array_length(p_results) > 50 then
    raise exception 'results_must_be_array_of_1_to_50';
  end if;
  if exists (select 1 from jsonb_array_elements(p_results) as entry(value) group by (value->>'user_id') having count(*) > 1) then
    raise exception 'duplicate_user_in_results';
  end if;

  for r in select value from jsonb_array_elements(p_results) loop
    v_user_id := (r->>'user_id')::uuid;
    v_placement := greatest(1, least(50, coalesce((r->>'placement')::integer, 50)));
    v_kills := greatest(0, least(50, coalesce((r->>'kills')::integer, 0)));
    v_survival := greatest(0, least(86400, coalesce((r->>'survival_seconds')::integer, 0)));
    v_won := coalesce((r->>'won')::boolean, false);
    v_round_diff := greatest(-5, least(5, coalesce((r->>'round_difference')::integer, 0)));

    -- Serialize duplicate settlement attempts for the same match/user pair.
    perform pg_advisory_xact_lock(hashtextextended(p_match_id::text || ':' || v_user_id::text, 0));
    if exists(select 1 from public.ranked_match_results where match_id = p_match_id and user_id = v_user_id) then
      continue;
    end if;

    if p_ranked_mode = 'cs_ranked' then
      v_delta := (case when v_won then 25 else -15 end) + (v_round_diff * 2) + least(v_kills, 10);
      v_delta := greatest(-25, least(40, v_delta));
      v_placement := case when v_won then 1 else 2 end;
    else
      v_base := case
        when v_placement = 1 then 80
        when v_placement = 2 then 60
        when v_placement <= 5 then 40
        when v_placement <= 10 then 20
        when v_placement <= 20 then 5
        else -20 end;
      v_delta := greatest(-30, least(130, v_base + least(v_kills, 5) * 8 + least(10, floor(v_survival::numeric / 120)::integer)));
    end if;

    insert into public.ranked_profiles(user_id, ranked_mode, rating_points, matches_played, wins)
      values(v_user_id, p_ranked_mode, 0, 0, 0)
      on conflict(user_id, ranked_mode) do nothing;
    select rating_points into v_before from public.ranked_profiles
      where user_id = v_user_id and ranked_mode = p_ranked_mode for update;
    v_after := greatest(0, v_before + v_delta);
    v_delta := v_after - v_before;

    insert into public.ranked_match_results(match_id, user_id, ranked_mode, placement, kills, points_before, points_delta, points_after, result_payload)
      values(p_match_id, v_user_id, p_ranked_mode, v_placement, v_kills, v_before, v_delta,
        v_after, jsonb_build_object('survival_seconds', v_survival, 'won', v_won, 'round_difference', v_round_diff));

    update public.ranked_profiles set rating_points = v_after,
      matches_played = matches_played + 1,
      wins = wins + case when v_won or (p_ranked_mode = 'br_ranked' and v_placement = 1) then 1 else 0 end,
      updated_at = now()
      where user_id = v_user_id and ranked_mode = p_ranked_mode;

    if p_ranked_mode = 'cs_ranked' then
      v_stars := least(5, (v_after / 100) % 5);
      if v_after >= 5000 then v_stars := 5; end if;
      v_tier := (array['Rookie','Bronze','Silver','Gold','Platinum','Diamond','Elite','Heroic','Master','Grandmaster'])[least(10, (v_after / 500) + 1)];
      v_next := least(5000, ((v_after / 100) + 1) * 100);
    else
      v_tier := case when v_after >= 4200 then 'Grandmaster' when v_after >= 3200 then 'Master' when v_after >= 2400 then 'Heroic' when v_after >= 1800 then 'Crown' when v_after >= 1250 then 'Diamond' when v_after >= 800 then 'Platinum' when v_after >= 450 then 'Gold' when v_after >= 200 then 'Silver' else 'Bronze' end;
      v_stars := 0;
      v_next := case when v_after < 200 then 200 when v_after < 450 then 450 when v_after < 800 then 800 when v_after < 1250 then 1250 when v_after < 1800 then 1800 when v_after < 2400 then 2400 when v_after < 3200 then 3200 when v_after < 4200 then 4200 else 4200 end;
    end if;
    v_output := v_output || jsonb_build_array(jsonb_build_object('user_id', v_user_id, 'mode', p_ranked_mode,
      'points_before', v_before, 'points_delta', v_delta, 'points_after', v_after, 'tier', v_tier,
      'stars', v_stars, 'next_threshold', v_next));
  end loop;
  return v_output;
end;
$$;

revoke all on function public.settle_ranked_match(uuid, text, jsonb) from public, anon, authenticated;
grant execute on function public.settle_ranked_match(uuid, text, jsonb) to service_role;
