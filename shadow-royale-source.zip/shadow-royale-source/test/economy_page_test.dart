import 'package:flutter_test/flutter_test.dart';
import 'package:shadow_royale/economy_page.dart';

void main() {
  group('Shadow Prime qualifying total mapping', () {
    test('zero and totals below Prime I do not qualify', () {
      expect(primeTierForQualifyingTotal(0), 0);
      expect(primeTierForQualifyingTotal(99), 0);
    });

    test('thresholds advance to the matching tier', () {
      expect(primeTierForQualifyingTotal(100), 1);
      expect(primeTierForQualifyingTotal(1000), 2);
      expect(primeTierForQualifyingTotal(5000), 3);
      expect(primeTierForQualifyingTotal(15000), 4);
      expect(primeTierForQualifyingTotal(30000), 5);
      expect(primeTierForQualifyingTotal(60000), 6);
      expect(primeTierForQualifyingTotal(100000), 7);
      expect(primeTierForQualifyingTotal(200000), 8);
    });

    test('Prime VIII is the permanent maximum for higher totals', () {
      expect(primeTierForQualifyingTotal(200001), 8);
      expect(primeTierForQualifyingTotal(1000000), 8);
    });
  });
}
