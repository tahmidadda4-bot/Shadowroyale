import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shadow_royale/main.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('lobby clearly keeps offline play available and online under maintenance', (tester) async {
    await tester.pumpWidget(const ShadowRoyaleApp());
    await tester.pumpAndSettle();

    expect(find.text('OFFLINE ONLY'), findsOneWidget);
    expect(find.text('START OFFLINE MATCH'), findsOneWidget);
    expect(find.textContaining('ONLINE MULTIPLAYER IS IN MAINTENANCE'), findsOneWidget);
    expect(find.text('BR RANKED'), findsOneWidget);
    expect(find.text('CLASSIC RANKED'), findsOneWidget);
  });

  testWidgets('offline match opens from the lobby', (tester) async {
    await tester.pumpWidget(const ShadowRoyaleApp());
    await tester.pumpAndSettle();
    await tester.tap(find.text('START OFFLINE MATCH'));
    await tester.pumpAndSettle();

    expect(find.text('VEYLORA ISLAND'), findsOneWidget);
    expect(find.text('FIRE'), findsOneWidget);
    expect(find.text('HEAL'), findsOneWidget);
    expect(find.text('LOOT'), findsOneWidget);
  });
}
