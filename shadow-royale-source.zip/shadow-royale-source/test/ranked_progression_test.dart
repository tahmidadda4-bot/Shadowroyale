import 'package:flutter_test/flutter_test.dart';
import 'package:shadow_royale/ranked_progression.dart';

void main() {
  group('Classic ranked points and stars', () {
    test('win and loss deltas stay within configured limits', () {
      expect(csRankDelta(won: true, roundDifference: 0, kills: 0), 25);
      expect(csRankDelta(won: false, roundDifference: 0, kills: 0), -15);
      expect(csRankDelta(won: true, roundDifference: 100, kills: 100), 40);
      expect(csRankDelta(won: false, roundDifference: -100, kills: 0), -25);
    });

    test('tier and stars change every 500 and 100 points', () {
      expect(csRankForPoints(0).name, 'Rookie');
      expect(csRankForPoints(499).stars, 4);
      expect(csRankForPoints(500).name, 'Bronze');
      expect(csRankForPoints(500).stars, 0);
      expect(csRankForPoints(5000).name, 'Grandmaster');
      expect(csRankForPoints(5000).stars, 5);
      expect(csRankForPoints(5100).points, 5100);
      expect(csRankForPoints(5100).name, 'Grandmaster');
    });
  });

  group('Battle Royale ranked points', () {
    test('placement score tiers are respected', () {
      expect(brRankDelta(placement: 1, kills: 0, survivalSeconds: 0), 80);
      expect(brRankDelta(placement: 2, kills: 0, survivalSeconds: 0), 60);
      expect(brRankDelta(placement: 5, kills: 0, survivalSeconds: 0), 40);
      expect(brRankDelta(placement: 10, kills: 0, survivalSeconds: 0), 20);
      expect(brRankDelta(placement: 20, kills: 0, survivalSeconds: 0), 5);
      expect(brRankDelta(placement: 21, kills: 0, survivalSeconds: 0), -20);
    });

    test('kills and survival are capped to prevent unbounded rewards', () {
      expect(brRankDelta(placement: 1, kills: 50, survivalSeconds: 999999), 130);
      expect(brRankDelta(placement: 50, kills: 0, survivalSeconds: 0), -20);
    });

    test('rank thresholds map to expected BR tiers', () {
      expect(brRankForPoints(199).name, 'Bronze');
      expect(brRankForPoints(200).name, 'Silver');
      expect(brRankForPoints(1800).name, 'Crown');
      expect(brRankForPoints(2400).name, 'Heroic');
      expect(brRankForPoints(4200).name, 'Grandmaster');
      expect(brRankForPoints(5000).points, 5000);
      expect(brRankForPoints(5000).name, 'Grandmaster');
    });
  });
}
